import base64
import hashlib
import hmac
import json
import time
from six.moves.urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import arrow
from slyguy import userdata, keep_alive
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.drm import is_wv_secure

from .constants import HEADERS, EDGE_URL, EDGE_CLIENT_ID, EDGE_CLIENT_SECRET, EVERGENT_URL, \
    CHANNEL_PARTNER_ID, EVERGENT_API_USER, EVERGENT_API_PASS, DATA_STORE_URL, \
    DEVICE_NAME, DEVICE_MANUFACTURER, DEVICE_MODEL, IMAGE_URL
from .language import _


class APIError(Error):
    pass



def jwt_encode(header, payload, secret_key):
    def _b64url(data):
        return base64.urlsafe_b64encode(data).decode().rstrip('=')

    h = _b64url(json.dumps(header, separators=(',', ':')).encode())
    p = _b64url(json.dumps(payload, separators=(',', ':')).encode())
    sig = hmac.new(
        base64.urlsafe_b64decode(secret_key.encode('ascii')),
        '{}.{}'.format(h, p).encode('ascii'),
        hashlib.sha256,
    ).digest()
    return '{}.{}.{}'.format(h, p, _b64url(sig))


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(HEADERS)
        self._set_authentication()
        keep_alive.register(self._refresh_token, hours=12, enable=self.logged_in)

    def _set_authentication(self):
        access_token = userdata.get('access_token')
        if not access_token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(access_token)})
        self.logged_in = True

    def _evergent(self, endpoint, payload):
        msg_key = list(payload.keys())[0]
        payload[msg_key].update({
            'apiPassword': EVERGENT_API_PASS,
            'apiUser': EVERGENT_API_USER,
            'channelPartnerID': CHANNEL_PARTNER_ID,
        })
        resp_key = msg_key.replace('RequestMessage', 'ResponseMessage')
        data = self._session.post('{}/{}'.format(EVERGENT_URL, endpoint), json=payload).json().get(resp_key, {})
        if data.get('responseCode') != '1':
            failure = (data.get('failureMessage') or [{}])[0]
            msg = failure.get('errorMessage') or data.get('errorMessage') or data.get('status') or 'Unknown error'
            raise APIError(_(_.LOGIN_ERROR, msg=msg))
        return data

    def send_otp(self, email):
        self.logout() # ensure old tokens are cleared out
        self._evergent('searchAccountV2', {'SearchAccountV2RequestMessage': {'email': email}})
        self._evergent('createOTP', {'CreateOTPRequestMessage': {'email': email}})

    def confirm_otp(self, email, otp):
        device_id = hashlib.md5(email.lower().encode()).hexdigest()[:16]
        resp = self._evergent('confirmOTP', {
            'ConfirmOTPRequestMessage': {
                'email': email,
                'otp': otp,
                'canCreateAccount': True,
                'checkDeviceLimit': True,
                'dmaId': '001',
                'isGenerateJWT': True,
                'isPrivacyPoliciesAccepted': True,
                'isTAndCAccepted': True,
                'privacyParams': [],
                'deviceDetails': {
                    'appType': 'Android TV',
                    'deviceName': DEVICE_NAME,
                    'deviceType': 'Android Tv',
                    'modelNo': DEVICE_MODEL,
                    'serialNo': device_id,
                },
            },
        })

        params = {p['paramName']: p['paramValue'] for p in resp.get('params', [])}
        userdata.set('refresh_token', params['refreshToken'])
        userdata.set('access_token', params['accessToken'])
        userdata.set('token_expires', int(params.get('expiresIn', 0)) // 1000)
        userdata.set('contact_id', resp['contactID'])
        userdata.set('device_id', device_id)
        self._set_authentication()

    def _refresh_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('token_expires', 0) > time.time()):
            return

        resp = self._evergent('refreshToken', {'RefreshTokenRequestMessage': {'refreshToken': userdata.get('refresh_token')}})
        userdata.set('access_token', resp['accessToken'])
        userdata.set('token_expires', int(resp.get('expiresIn', 0)) // 1000)

    def _fetch_ovat_token(self):
        resp = self._evergent('getEntitlements', {
            'GetEntitlementsRequestMessage': {
                'contactID': userdata.get('contact_id'),
                'returnUpgradableFlag': True,
            },
        })
        return resp['ovatToken']

    def _get_edge_token(self):
        data = self._session.post('{}/oauth2/token'.format(EDGE_URL), data={
            'audience': 'edge-service',
            'grant_type': 'client_credentials',
            'client_id': EDGE_CLIENT_ID,
            'client_secret': EDGE_CLIENT_SECRET,
            'scope': 'offline openid',
        }).json()
        return data['access_token']

    def _get_device_jwt(self, app_token, ovat_token):
        device_id = userdata.get('device_id')
        headers = {
            'authorization': 'Bearer {}'.format(app_token),
            'x-authorization': ovat_token,
        }
        data = self._session.post('{}/device/app/register'.format(EDGE_URL), json={'UniqueId': device_id}, headers=headers).json()
        secret = data['data']['secret']

        iat = int(time.time())
        return jwt_encode(
            {'alg': 'HS256'},
            {'deviceId': userdata.get('device_id'), 'aud': 'playback-auth-service', 'iat': iat - 60, 'exp': iat + 60},
            secret,
        )

    def epg(self, days=1):
        self._refresh_token()
        channels = {}
        chunk_start = arrow.utcnow()

        for _ in range(days):
            chunk_end = chunk_start.shift(days=1)

            data = self._session.get('{}/content/epg'.format(DATA_STORE_URL), params={
                'pageSize': 100, 'pageNumber': 1,
                'start': chunk_start.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                'end': chunk_end.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                'pf': 'regular',
                'reg': 'nz',
                'genre': '',
                'channel': '',
                'locale': '',
                'client': 'tvnz-tvnz-androidtv',
                'dt': 'androidtv',
            }).json()

            for ch in data.get('data', []):
                cid = ch.get('cid')
                if not cid:
                    continue

                if cid not in channels:
                    channels[cid] = {
                        'slug': ch.get('cs', ''),
                        'title': (ch.get('lon') or [{}])[0].get('n', ''),
                        'content_id': cid,
                        'programs': [],
                    }

                for airing in ch.get('airing', []):
                    start = airing.get('sc_st_dt')
                    end = airing.get('sc_ed_dt')
                    pgm = airing.get('pgm') or {}
                    title = (pgm.get('lon') or [{}])[0].get('n', '')
                    if start and title:
                        channels[cid]['programs'].append({
                            'start': start,
                            'end': end,
                            'title': title,
                            'type': pgm.get('pgm_ty'),
                            'subtitle': (pgm.get('loepn') or [{}])[0].get('n', ''),
                            'plot': (pgm.get('lod') or [{}])[0].get('n', ''),
                            'genres': (pgm.get('log') or [{}])[0].get('n', []),
                            'rating': (pgm.get('rat') or [{}])[0].get('v', ''),
                            'season': pgm.get('snum'),
                            'episode': pgm.get('epnum'),
                            'lnk_id': pgm.get('lnk_id'),
                        })

            chunk_start = chunk_end

        return list(channels.values())

    def play(self, content_id, content_type_id='vod', catalog_type='episode'):
        self._refresh_token()
        is_live = content_type_id == 'live'

        app_token = self._get_edge_token()
        ovat_token = self._fetch_ovat_token()
        device_jwt = self._get_device_jwt(app_token, ovat_token)

        headers = {
            'authorization': 'Bearer {}'.format(app_token),
            'x-authorization': ovat_token,
            'x-device-id': device_jwt,
        }

        payload = {
            'deviceName': DEVICE_NAME,
            'deviceId': userdata.get('device_id'),
            'deviceManufacturer': DEVICE_MANUFACTURER,
            'deviceModelName': DEVICE_MODEL,
            'deviceOs': 'Android',
            'deviceOsVersion': '11',
            'proxyDeviceId': '',
            'contentId': content_id,
            'mediaFormat': 'dash',
            'contentTypeId': content_type_id,
            'catalogType': catalog_type,
            'drm': 'widevine',
            'delivery': 'streaming',
            'quality': 'high',
            'disableSsai': 'true',
            'supportedResolution': 'UHD',
            'supportedAudio': '',
            'supportedAudioCodecs': 'mp4a-latm,3gpp,amr-wb,flac,g711-alaw,g711-mlaw,mpeg,opus,raw,vorbis,mpeg-L2,x-ms-wma',
            'supportedVideoCodecs': 'hevc,avc,3gpp,x-motion-jpeg,mpeg2,mp4v-es,wvc1,x-ms-wmv,x-vnd.on2.vp8,x-vnd.on2.vp9',
            'supportedMaxWVSecurityLevel': 'L1' if is_wv_secure() else 'L3',
        }
        if is_live:
            payload['playbackMode'] = 'live'
        else:
            payload['urlParameters'] = {}

        data = self._session.post('{}/media/content/authorize'.format(EDGE_URL),
            json=payload, headers=headers).json()

        if data['header']['code'] != 0:
            errors = data['header'].get('errors', [{}])
            raise APIError(errors[0].get('description', 'Authorization failed'))

        result = data['data']
        p = urlparse(result['contentUrl'])
        qs = [(k, v) for k, v in parse_qsl(p.query) if k != 'aws.manifestfilter'] # remove the 720p limit and allow 5.1 audio
        result['contentUrl'] = urlunparse(p._replace(query=urlencode(qs)))
        result['app_token'] = app_token
        return result

    def logout(self):
        userdata.delete('refresh_token')
        userdata.delete('access_token')
        userdata.delete('token_expires')
        userdata.delete('contact_id')
        userdata.delete('device_id')
        self.new_session()
