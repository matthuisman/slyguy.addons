from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    ENTER_OTP          = 30000
    LOGIN_ERROR        = 30001
    EXPIRES            = 30002
    PLAY_NEXT_EPISODE  = 30003
    LIVE               = 30004
    REPLAY             = 30005

_ = Language()
