import codecs
from xml.sax.saxutils import escape

import arrow
from kodi_six import xbmcplugin
from slyguy import plugin, gui, inputstream, signals, userdata
from slyguy.constants import ROUTE_LIVE_TAG, PLAY_FROM_TYPES, PLAY_FROM_ASK, PLAY_FROM_START, LIVE_HEAD

from .api import API
from .constants import IMAGE_URL
from .language import _
from .settings import settings


api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))
        _add_landing_tabs(folder)
        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))
        if settings.SYNC_WATCHLIST.value:
            folder.add_item(label=_(_.WATCHLIST, _bold=True), path=plugin.url_for(watchlist), bookmark=False)
        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)
        profile = userdata.get('profile', {})
        folder.add_item(label=_.SELECT_PROFILE, path=plugin.url_for(select_profile), art={'thumb': profile.get('avatar')}, info={'plot': profile.get('name')}, _kiosk=False, bookmark=False)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    email = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not email:
        return

    userdata.set('username', email)
    api.send_otp(email)

    otp = gui.numeric(_.ENTER_OTP)
    if otp is None:
        return

    api.confirm_otp(email, otp)
    _select_profile(switching=False)
    gui.refresh()


@plugin.route()
def select_profile(**kwargs):
    _select_profile()
    gui.refresh()


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return
    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    folder.add_items([_process_row(row, live_tag=False) for row in api.epg(days=1)])
    return folder


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for row in api.epg(days=1):
            f.write(u'\n#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}",{name}\n{url}'.format(
                tvg_id=row['slug'],
                logo='{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, row['content_id']),
                name=row['title'],
                url=plugin.url_for(play, content_id=row['content_id'], content_type_id='live', catalog_type='channel', _is_live=True),
            ))


@plugin.route()
@plugin.merge()
@plugin.login_required()
def epg(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'<?xml version="1.0" encoding="utf-8" ?><tv>')

        for row in api.epg(days=settings.getInt('epg_days', 3)):
            f.write(u'<channel id="{}"><display-name>{}</display-name><icon src="{}"/></channel>'.format(
                row['slug'], escape(row['title']), escape('{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, row['content_id']))))

            for program in row['programs']:
                prog_xml = u'<programme channel="{}" start="{}" stop="{}"><title>{}</title>'.format(
                    row['slug'], arrow.get(program['start']).to('utc').format('YYYYMMDDHHmmss Z'), arrow.get(program['end']).to('utc').format('YYYYMMDDHHmmss Z'),
                    escape(program['title']))

                if program.get('subtitle') and program['subtitle'] not in program['title']:
                    prog_xml += u'<sub-title>{}</sub-title>'.format(escape(program['subtitle']))

                if program.get('plot'):
                    prog_xml += u'<desc>{}</desc>'.format(escape(program['plot']))

                if program.get('season') and program.get('episode'):
                    prog_xml += u'<episode-num system="onscreen">S{:02d}E{:02d}</episode-num>'.format(
                        int(program['season']), int(program['episode']))

                if program.get('genres'):
                    for genre in program['genres']:
                        prog_xml += u'<category>{}</category>'.format(escape(genre))

                if program.get('lnk_id'):
                    prog_xml += u'<icon src="{}"/></programme>'.format(escape('{}/image/{}/0-16x9.png?width=400'.format(IMAGE_URL, program['lnk_id'])))

                prog_xml += u'</programme>'
                f.write(prog_xml)

        f.write(u'</tv>')


@plugin.route()
@plugin.login_required()
@plugin.search(history_key=lambda _: userdata.get('contact_id'))
def search(query, page, **kwargs):
    data = api.search(query, page=page)
    items = []
    for row in data.get('data', []):
        items.append(_process_row(row))
    header = data.get('header', {})
    more_pages = (header.get('start', 1) - 1) + header.get('rows', 0) < header.get('count', 0)
    return items, more_pages


@plugin.route()
@plugin.login_required()
def watchlist(**kwargs):
    folder = plugin.Folder(_(_.WATCHLIST))
    user_content = api.get_user_content(tags='favorite')
    items = []
    for row in user_content.get('favorite', []):
        items.append(_process_row(row, in_watchlist=True))
    folder.add_items(items)
    return folder


@plugin.route()
@plugin.login_required()
def add_watchlist(content_id, title=None, thumb=None, **kwargs):
    api.add_watchlist(content_id)
    gui.notification(_.WATCHLIST_ADDED, heading=title, icon=thumb)


@plugin.route()
@plugin.login_required()
def remove_watchlist(content_id, **kwargs):
    api.remove_watchlist(content_id)
    gui.refresh()


@plugin.route()
@plugin.login_required()
def series(id, **kwargs):
    show = api.series_detail(id).get('data') or {}
    season_rows = api.seasons(id, sort_order=show.get('sdo', 'asc')).get('data', [])
    sw = api.smartwatch(id)
    airing = sw if (sw and sw.get('cty') == 'airing') else None

    show_title = _localized(show.get('lon')) or (_localized(season_rows[0].get('lostl')) if season_rows else '')
    show_art = _art(show) if show.get('id') else {}
    airing_item = _process_row(airing, show=show) if airing else None

    if len(season_rows) == 1:
        # Single-season show: flatten into the season's episode list, with the
        # airing prepended on page 1 when present.
        edo = show.get('edo', 'asc')
        season_id = season_rows[0]['id']
        data = api.episodes(id, season_id, page=1, sort_order=edo)
        show_fanart = _image(show['id'], show.get('ia', []), 'fanart') if show.get('id') else None
        sort_methods = None
        if edo == 'desc':
            sort_methods = [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_EPISODE,
                            xbmcplugin.SORT_METHOD_LABEL, xbmcplugin.SORT_METHOD_DATEADDED]
        folder = plugin.Folder(_localized(show.get('lon')), fanart=show_fanart, sort_methods=sort_methods)
        if airing_item:
            folder.add_items([airing_item])
        folder.add_items([_process_row(row, show=show) for row in data.get('data', [])])
        return folder

    sort_methods = None
    if show.get('sdo') == 'desc':
        sort_methods = [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL]
    folder = plugin.Folder(show_title, sort_methods=sort_methods)

    if airing_item:
        folder.add_items([airing_item])

    for s in season_rows:
        snum = s.get('snum')
        folder.add_item(
            label=_(_.SEASON, number=snum),
            info={
                'mediatype': 'season',
                'season': snum,
                'tvshowtitle': show_title,
                'plot': _plot(s, fallback=show),
            },
            art=show_art,
            path=plugin.url_for(season, series_id=id, season_id=s['id']),
        )
    return folder


@plugin.route()
@plugin.login_required()
@plugin.pagination()
def season(series_id, season_id, page=1, **kwargs):
    show = api.series_detail(series_id).get('data') or {}
    edo = show.get('edo', 'asc')
    data = api.episodes(series_id, season_id, page=page, sort_order=edo)
    show_fanart = _image(show['id'], show.get('ia', []), 'fanart') if show.get('id') else None
    # When episodes come back in desc order, default Kodi sort would re-order by SxxExx ascending - keep API order.
    sort_methods = None
    if edo == 'desc':
        sort_methods = [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_EPISODE, xbmcplugin.SORT_METHOD_LABEL, xbmcplugin.SORT_METHOD_DATEADDED]
    folder = plugin.Folder(_localized(show.get('lon')), fanart=show_fanart, sort_methods=sort_methods)
    folder.add_items([_process_row(row, show=show) for row in data.get('data', [])])
    header = data.get('header', {})
    more_pages = (header.get('start', 1) - 1) + header.get('rows', 0) < header.get('count', 0)
    return folder, more_pages


@plugin.route()
@plugin.login_required()
def tab(tab_id, tab_index, **kwargs):
    data = api.landingscreen(tab_id=tab_id, tab_index=int(tab_index))
    target = next((t for t in data['data'].get('t', []) if t.get('id') == tab_id), None)
    if not target:
        return
    is_categories_tab = _localized(target.get('lon')).lower() == 'categories'
    folder = plugin.Folder(_localized(target.get('lon')))
    for c in target.get('c', []):
        if c.get('lo') == 'banner':
            continue  # skip hero/banner carousels
        if not c.get('cd'):
            continue
        name = _localized(c.get('lon'))
        if not name:
            continue
        # On the Categories tab, drop the redundant "list of categories" carousel -
        # each category already appears as its own sibling carousel.
        if is_categories_tab and (c.get('cd') or [{}])[0].get('cty') == 'category':
            continue
        # Grid-style carousels (e.g. "All Movies") have a paginated lookup behind them.
        is_grid = (c.get('con_sa') or {}).get('ty') == 'grid' and c.get('click_action') == 'detail'
        first_cty = (c.get('cd') or [{}])[0].get('cty')
        if is_grid and first_cty in ('movie', 'tvseries'):
            path = plugin.url_for(lookup_section, cty=first_cty, name=name)
        else:
            path = plugin.url_for(carousel, tab_id=tab_id, tab_index=tab_index, carousel_id=c['id'])
        folder.add_item(label=name, path=path)
    return folder


@plugin.route()
@plugin.login_required()
def carousel(tab_id, tab_index, carousel_id, **kwargs):
    data = api.landingscreen(tab_id=tab_id, tab_index=int(tab_index))
    target = next((t for t in data['data'].get('t', []) if t.get('id') == tab_id), None)
    if not target:
        return
    car = next((c for c in target.get('c', []) if c.get('id') == carousel_id), None)
    if not car:
        return
    folder = plugin.Folder(_localized(car.get('lon')))
    items = []
    for row in car.get('cd', []):
        items.append(_process_row(row))
    folder.add_items(items)
    return folder


@plugin.route()
@plugin.login_required()
def category(catc, **kwargs):
    sf = api.landingscreen()['data']
    cat_tab = None
    cat_index = 0
    for i, t in enumerate(sf.get('t', [])):
        if _localized(t.get('lon')).lower() == 'categories':
            cat_tab = t
            cat_index = i
            break
    if not cat_tab:
        return
    data = api.landingscreen(tab_id=cat_tab['id'], tab_index=cat_index)
    target = next((t for t in data['data'].get('t', []) if t.get('id') == cat_tab['id']), None)
    if not target:
        return
    catc_lower = (catc or '').lower()
    catc_spaces = catc_lower.replace('-', ' ')
    car = None
    for c in target.get('c', []):
        name = _localized(c.get('lon')).lower()
        normalized = name.replace(' & ', ' ').replace('&', '').replace('  ', ' ')
        if name == catc_lower or name == catc_spaces or normalized == catc_spaces:
            car = c
            break
    if not car:
        return
    folder = plugin.Folder(_localized(car.get('lon')))
    items = []
    for row in car.get('cd', []):
        items.append(_process_row(row))
    folder.add_items(items)
    return folder


@plugin.route()
@plugin.login_required()
@plugin.pagination()
def lookup_section(cty, name=None, page=1, **kwargs):
    data = api.lookup(cty, page=page)
    folder = plugin.Folder(name or '')
    items = []
    for row in data.get('data', []):
        items.append(_process_row(row))
    folder.add_items(items)
    header = data.get('header', {})
    more_pages = (header.get('start', 1) - 1) + header.get('rows', 0) < header.get('count', 0)
    return folder, more_pages


@plugin.route()
@plugin.login_required()
def play(content_id, content_type_id='vod', catalog_type='episode', start_time=None, end_time=None, **kwargs):
    playback_mode = None
    api_catalog_type = catalog_type

    resume_from = None
    if catalog_type == 'airing':
        api_catalog_type = 'channel'
        play_type = int(settings.getEnum('live_play_type', PLAY_FROM_TYPES, PLAY_FROM_ASK))

        if play_type == PLAY_FROM_START:
            playback_mode = 'restart'
            resume_from = 1
        elif play_type == PLAY_FROM_ASK:
            resume_from = plugin.live_or_start()
            if resume_from == -1:
                return
            playback_mode = 'restart' if resume_from == 1 else 'live'
        else:
            playback_mode = 'live'

        # Live mode doesn't need (or want) the time window — it plays the live edge.
        if playback_mode == 'live':
            start_time = end_time = None

    elif catalog_type == 'catchup':
        api_catalog_type = 'channel'
        playback_mode = 'catchup'

    data = api.play(content_id, content_type_id=content_type_id,
                    catalog_type=api_catalog_type, playback_mode=playback_mode,
                    start_time=start_time, end_time=end_time)

    if data['drm'] == 'widevine':
        ia = inputstream.Widevine(
            license_key=data['licenseUrl'], # license url lasts 2mins
            license_headers={'authorization': 'Bearer {}'.format(data['app_token'])},
            manifest_type = 'hls' if data['mediaFormat'] == 'hls' else 'mpd',
        )
    elif data['mediaFormat'] == 'hls':
        ia = inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs)
    elif data['mediaFormat'] == 'dash':
        ia = inputstream.MPD()
    else:
        raise Exception('Unsupported media format: {}'.format(data['mediaFormat']))

    item = plugin.Item(
        path=data['contentUrl'],
        inputstream=ia,
    )

    if ROUTE_LIVE_TAG in kwargs and catalog_type not in ('channel', 'airing', 'catchup'):
        play_type = int(settings.getEnum('live_play_type', PLAY_FROM_TYPES, PLAY_FROM_ASK))
        if play_type == PLAY_FROM_START:
            resume_from = 1
        elif play_type == PLAY_FROM_ASK:
            resume_from = plugin.live_or_start()
            if resume_from == -1:
                return

    if resume_from is not None:
        item.resume_from = resume_from

    if catalog_type == 'tvepisode':
        ep = api.episode_detail(content_id)
        if ep.get('id'):
            # Populate listitem metadata so playback display is correct
            # even when invoked via play_next (no parent listitem context).
            item.label, item.info, item.art = _episode_meta(ep)
            if settings.PLAY_NEXT_EPISODE.value and ep.get('stl_id') and ep.get('snum') and ep.get('epnum'):
                nxt = api.up_next(ep['stl_id'], ep['snum'], ep['epnum'])
                if nxt:
                    item.play_next = {'next_file': plugin.url_for(
                        play, content_id=nxt['id'], content_type_id='vod', catalog_type='tvepisode',
                    )}

    return item


_THUMB_VARIANTS = ('0-2x3', '0-16x9', '2-16x9', '2-1x1')
_FANART_VARIANTS = ('2-16x9', '0-16x9', '2-16x7')
_NO_EXPIRES_CTY = {'newsclip', 'sportclip', 'sporthighlight', 'liveevent'}


_HIDDEN_TAB_SLUGS = {'myhub'}


def _add_landing_tabs(folder):
    """Add the storefront tab list to the home folder, fetched dynamically."""
    for index, t in enumerate(api.landingscreen()['data'].get('t', [])):
        if t.get('nu') in _HIDDEN_TAB_SLUGS:
            continue
        name = _localized(t.get('lon'))
        if not name:
            continue
        folder.add_item(
            label=_(name, _bold=True),
            path=plugin.url_for(tab, tab_id=t['id'], tab_index=index),
        )


def _localized(field):
    """Extract first localized string. TVNZ returns [{'lang':'en', 'n':'value'}]."""
    if not field:
        return ''
    return (field[0] or {}).get('n', '') if isinstance(field, list) else ''


def _image(content_id, ia, kind='thumb'):
    """Build image URL. Thumb prefers portrait (0-2x3) then landscape; fanart is landscape only."""
    if not content_id or not ia:
        return None
    prefer = _FANART_VARIANTS if kind == 'fanart' else _THUMB_VARIANTS
    width = 1920 if kind == 'fanart' else 400
    for variant in prefer:
        if variant in ia:
            return '{}/image/{}/{}.png?width={}'.format(IMAGE_URL, content_id, variant, width)
    return None


def _art(row):
    return {
        'thumb': _image(row['id'], row.get('ia', []), 'thumb'),
        'fanart': _image(row['id'], row.get('ia', []), 'fanart'),
    }


def _expires(row):
    # lwe is the license window end. 2100-01-01 is the sentinel for "no expiry".
    lwe = row.get('lwe')
    if not lwe:
        return None
    end = arrow.get(lwe)
    if end.year >= 2099:
        return None
    end = end.to('local')
    days_left = (end - arrow.now()).days
    style = {'_bold': True}
    if days_left < 1:
        style['_color'] = 'red'
    elif days_left < 30:
        style['_color'] = 'yellow'
    return _(_.EXPIRES, date=end.format('DD/MM/YY'), **style)


def _plot(row, fallback=None):
    fb = fallback or {}
    parts = [_localized(row.get('lod')) or _localized(fb.get('lod'))]
    if (row.get('cty') or fb.get('cty')) not in _NO_EXPIRES_CTY:
        parts.append(_expires(row) or _expires(fb))
    return u'\n\n'.join(p for p in parts if p)


def _epg_plot(programs, count=5):
    """Build a 'next up' plot list from upcoming/airing programs."""
    if not programs:
        return None
    now = arrow.now()
    lines = []
    for program in programs:
        start = arrow.get(program['start'])
        end = arrow.get(program['end'])
        if (now > start and now < end) or start > now:
            lines.append(u'[{}] {}'.format(start.to('local').format('h:mma'), program['title']))
            if len(lines) == count:
                break
    return u'\n'.join(lines) or None


def _process_row(row, live_tag=True, in_watchlist=False, show=None):
    cty = row.get('cty')
    content_id = row['id']
    title = _localized(row.get('lon'))
    live_label = u'{} {}'.format(title, _(_.LIVE, _bold=True)) if live_tag else title
    info = {
        'plot': _plot(row),
        'genre': (row.get('log') or [{}])[0].get('n'),
        'mpaa': (row.get('rat') or [{}])[0].get('v'),
        'year': row.get('r'),
        'studio': ((row.get('ph') or [{}])[0].get('n') or [None])[0],
        'duration': row.get('rt'),
    }

    if cty == 'tvepisode':
        label, info, art = _episode_meta(row, show=show)
        item = plugin.Item(
            label=label, info=info, art=art,
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type='tvepisode'),
            playable=True,
        )
    elif cty == 'movie':
        info['mediatype'] = 'movie'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type=cty),
            playable=True,
        )
    elif cty == 'tvseries':
        info['mediatype'] = 'tvshow'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(series, id=content_id),
        )
    elif cty == 'newsclip':
        info['mediatype'] = 'video'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type=cty),
            playable=True,
        )
    elif cty == 'sportclip':
        info['mediatype'] = 'video'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type=cty),
            playable=True,
        )
    elif cty == 'sporthighlight':
        info['mediatype'] = 'video'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type=cty),
            playable=True,
        )
    elif cty == 'event':
        info['mediatype'] = 'video'
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='vod', catalog_type=cty),
            playable=True,
        )
    elif cty == 'liveevent':
        info['mediatype'] = 'video'
        info.pop('duration', None)
        thumb = _image(row['id'], row.get('ia', []), 'thumb')
        item = plugin.Item(
            label=live_label, info=info, art=_art(row),
            path=plugin.url_for(play, content_id=content_id, content_type_id='live', catalog_type=cty, _is_live=True),
            playable=True,
        )
    elif cty == 'channel':
        info['mediatype'] = 'video'
        info.pop('duration', None)
        epg_plot = _epg_plot(row.get('programs'))
        if epg_plot:
            info['plot'] = epg_plot
        item = plugin.Item(
            label=live_label, info=info,
            art={'thumb': '{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, content_id)},
            path=plugin.url_for(play, content_id=content_id, content_type_id='live', catalog_type=cty, _is_live=True),
            playable=True,
        )
    elif cty == 'airing':
        # A live channel currently airing a program.
        pgm = row.get('pgm') or {}
        content_id = row.get('cid')
        sc_st = row.get('sc_st_dt')
        sc_ed = row.get('sc_ed_dt')
        is_live = bool(sc_st and sc_ed and arrow.get(sc_st) <= arrow.utcnow() <= arrow.get(sc_ed))

        # pgm['id'] is a synthetic "program-..." id with no image asset; swap to the show
        # id (lnk_id) so _episode_meta's _image(row['id'], ...) lookup resolves.
        ep_row = dict(pgm)
        if pgm.get('lnk_id'):
            ep_row['id'] = pgm['lnk_id']
        label, info, art = _episode_meta(ep_row, show=show)
        # For airings, show date instead of season/episode number
        date_str = arrow.get(sc_st).to('local').format('dddd D MMMM YYYY')
        label = u'{} {}'.format(date_str, _(_.LIVE if is_live else _.REPLAY, _bold=True))
        # Calculate duration from start and end times
        if sc_st and sc_ed:
            sc_ed = arrow.get(sc_ed).shift(minutes=5).format('YYYY-MM-DDTHH:mm:ss') + 'Z'
            info['duration'] = int((arrow.get(sc_ed) - arrow.get(sc_st)).total_seconds())
        if show and show.get('id'):
            show_fanart = _image(show['id'], show.get('ia', []), 'fanart')
            if show_fanart:
                art = dict(art)
                art.setdefault('fanart', show_fanart)
        item = plugin.Item(
            label=label, info=info, art=art,
            path=plugin.url_for(
                play, content_id=content_id, content_type_id='live',
                catalog_type='airing' if is_live else 'catchup',
                start_time=sc_st, end_time=sc_ed, _is_live=is_live,
            ),
            playable=True,
        )
    elif cty == 'category':
        info['mediatype'] = 'video'
        item = plugin.Item(
            label=title, info=info, art=_art(row),
            path=plugin.url_for(category, catc=row.get('catc', '')),
        )
    elif cty == 'competition':
        # TODO: implement when an events-listing endpoint for competitions is identified
        return None
    else:
        return None

    if settings.SYNC_WATCHLIST.value:
        if in_watchlist:
            item.context.append((_(_.REMOVE_WATCHLIST), 'RunPlugin({})'.format(
                plugin.url_for(remove_watchlist, content_id=content_id))))
        elif cty in ('movie', 'tvseries'):
            item.context.append((_(_.ADD_WATCHLIST), 'RunPlugin({})'.format(
                plugin.url_for(add_watchlist, content_id=content_id, title=title, thumb=thumb))))

    return item


def _episode_meta(row, show=None):
    """Build (label, info, art) for an episode row. Used by both list parsing and play()."""
    snum = row.get('snum')
    epnum = row.get('epnum')
    show_title = _localized(row.get('lostl'))
    ep_title = _localized(row.get('lon'))
    default_label = u'Season {}, Episode {}'.format(snum, epnum)
    if (show or {}).get('cust_ep_losn') == 'original-air-date':
        label = _localized(row.get('losn')) or default_label
    elif ep_title and ep_title.strip() != show_title.strip():
        label = ep_title
    else:
        label = default_label
    pdt = row.get('pdt') or ''
    info = {
        'mediatype': 'episode',
        'season': snum,
        'episode': epnum,
        'tvshowtitle': _localized(row.get('lostl')),
        'plot': _plot(row),
        'duration': row.get('rt'),
        'aired': row.get('oadt', '')[:10] if row.get('oadt') else '',
        'dateadded': pdt[:19].replace('T', ' ') if len(pdt) >= 19 else None,
        'mpaa': (row.get('rat') or [{}])[0].get('v'),
        'genre': (row.get('stl_log') or [{}])[0].get('n'),
        'studio': ((row.get('ph') or [{}])[0].get('n') or [None])[0],
        'tag': (row.get('lok') or [{}])[0].get('n'),
    }
    art = {'thumb': _image(row['id'], row.get('ia', []), 'thumb')}
    return label, info, art


def _select_profile(switching=True):
    profiles = api.profiles()
    if not profiles:
        return

    options = []
    values = []
    default = -1

    for index, profile in enumerate(profiles):
        values.append(profile)
        options.append(plugin.Item(label=profile['firstName'], art={'thumb': profile.get('picUrl')}))
        if profile['contactID'] == userdata.get('contact_id'):
            default = index

    if len(profiles) == 1 and not switching:
        _set_profile(profiles[0], switching=False)
        return

    index = gui.select(_.SELECT_PROFILE, options=options, preselect=default, useDetails=True)
    if index < 0:
        return

    _set_profile(values[index], switching=switching)


def _set_profile(profile, switching=True):
    name = profile['firstName']
    avatar = profile.get('picUrl')
    api.set_profile(profile['contactID'])
    userdata.set('profile', {'name': name, 'avatar': avatar})
    if switching:
        gui.notification(_.PROFILE_ACTIVATED, heading=name, icon=avatar)
