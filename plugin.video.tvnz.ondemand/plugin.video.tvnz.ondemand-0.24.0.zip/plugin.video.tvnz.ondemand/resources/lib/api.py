import base64
import hashlib
import hmac
import json
import arrow
import time
from six.moves.urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import arrow
from slyguy import userdata, keep_alive
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.drm import is_wv_secure

from .constants import HEADERS, EDGE_URL, EDGE_CLIENT_ID, EDGE_CLIENT_SECRET, EVERGENT_URL, \
    CHANNEL_PARTNER_ID, EVERGENT_API_USER, EVERGENT_API_PASS, DATA_STORE_URL, \
    DEVICE_NAME, DEVICE_MANUFACTURER, DEVICE_MODEL, IMAGE_URL, SEARCH_URL, CATALOG_URL, \
    API_DT, API_CLIENT, API_POLICY_EVALUATE, API_REG, API_PF
from .language import _
from .settings import settings


class APIError(Error):
    pass



def jwt_encode(header, payload, secret_key):
    def _b64url(data):
        return base64.urlsafe_b64encode(data).decode().rstrip('=')

    h = _b64url(json.dumps(header, separators=(',', ':')).encode())
    p = _b64url(json.dumps(payload, separators=(',', ':')).encode())
    sig = hmac.new(
        base64.urlsafe_b64decode(secret_key.encode('ascii')),
        '{}.{}'.format(h, p).encode('ascii'),
        hashlib.sha256,
    ).digest()
    return '{}.{}.{}'.format(h, p, _b64url(sig))


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(HEADERS)
        self._set_authentication()
        keep_alive.register(self._refresh_user_token, hours=12, enable=self.logged_in)

    def _set_authentication(self):
        if not userdata.get('user_token'):
            return

        self._session.headers.update({
            'authorization': 'Bearer {}'.format(userdata.get('app_token')),
            'x-authorization': userdata.get('ovat_token'),
        })
        self.logged_in = True

    def _evergent(self, endpoint, payload):
        msg_key = list(payload.keys())[0]
        payload[msg_key].update({
            'apiPassword': EVERGENT_API_PASS,
            'apiUser': EVERGENT_API_USER,
            'channelPartnerID': CHANNEL_PARTNER_ID,
        })

        headers = {}
        if self.logged_in:
            headers['authorization'] = 'Bearer {}'.format(userdata.get('user_token'))

        resp_key = msg_key.replace('RequestMessage', 'ResponseMessage')
        data = self._session.post('{}/{}'.format(EVERGENT_URL, endpoint), json=payload, headers=headers).json().get(resp_key, {})
        if data.get('responseCode') != '1':
            failure = (data.get('failureMessage') or [{}])[0]
            msg = failure.get('errorMessage') or data.get('errorMessage') or data.get('status') or 'Unknown error'
            raise APIError(_(_.LOGIN_ERROR, msg=msg))
        return data

    def send_otp(self, email):
        self.logout() # ensure old tokens are cleared out
        self._evergent('searchAccountV2', {'SearchAccountV2RequestMessage': {'email': email}})
        self._evergent('createOTP', {'CreateOTPRequestMessage': {'email': email}})

    def confirm_otp(self, email, otp):
        device_id = settings.DEVICE_ID.value
        resp = self._evergent('confirmOTP', {
            'ConfirmOTPRequestMessage': {
                'email': email,
                'otp': otp,
                'canCreateAccount': True,
                'checkDeviceLimit': True,
                'dmaId': '001',
                'isGenerateJWT': True,
                'isPrivacyPoliciesAccepted': True,
                'isTAndCAccepted': True,
                'privacyParams': [],
                'deviceDetails': {
                    'appType': 'Android TV',
                    'deviceName': DEVICE_NAME,
                    'deviceType': 'Android Tv',
                    'modelNo': DEVICE_MODEL,
                    'serialNo': device_id,
                },
            },
        })

        params = {p['paramName']: p['paramValue'] for p in resp.get('params', [])}
        userdata.set('user_token', params['accessToken'])
        userdata.set('user_refresh_token', params['refreshToken'])
        userdata.set('user_token_expires', int(int(params['expiresIn']) / 1000) - 60)
        userdata.set('device_id', device_id)
        self.set_profile(resp['contactID'])
        self._refresh_tokens()

    def epg(self, days=1):
        channels = {}
        chunk_start = arrow.utcnow()

        for _ in range(days):
            chunk_end = chunk_start.shift(days=1)

            data = self._session.get('{}/content/epg'.format(DATA_STORE_URL), params={
                'pageSize': 100, 'pageNumber': 1,
                'start': chunk_start.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                'end': chunk_end.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                'pf': API_PF,
                'reg': API_REG,
                'genre': '',
                'channel': '',
                'locale': '',
                'client': API_CLIENT,
                'dt': API_DT,
            }).json()

            for ch in data.get('data', []):
                cid = ch.get('cid')
                if not cid:
                    continue

                if cid not in channels:
                    channels[cid] = {
                        # search-row-style fields so _process_row can consume this directly
                        'id': cid,
                        'cty': 'channel',
                        'lon': ch.get('lon', []),
                        'ia': ch.get('ia', []),
                        # legacy fields used by playlist/epg writers
                        'slug': ch.get('cs', ''),
                        'title': (ch.get('lon') or [{}])[0].get('n', ''),
                        'content_id': cid,
                        'programs': [],
                    }

                for airing in ch.get('airing', []):
                    start = airing.get('sc_st_dt')
                    end = airing.get('sc_ed_dt')
                    pgm = airing.get('pgm') or {}
                    title = (pgm.get('lon') or [{}])[0].get('n', '')
                    if start and title:
                        channels[cid]['programs'].append({
                            'start': start,
                            'end': end,
                            'title': title,
                            'type': pgm.get('pgm_ty'),
                            'subtitle': (pgm.get('loepn') or [{}])[0].get('n', ''),
                            'plot': (pgm.get('lod') or [{}])[0].get('n', ''),
                            'genres': (pgm.get('log') or [{}])[0].get('n', []),
                            'rating': (pgm.get('rat') or [{}])[0].get('v', ''),
                            'season': pgm.get('snum'),
                            'episode': pgm.get('epnum'),
                            'lnk_id': pgm.get('lnk_id'),
                        })

            chunk_start = chunk_end

        return list(channels.values())

    def _refresh_app_token(self, force=False):
        # app token is anonymous and lasts days
        if not force and userdata.get('app_token_expires', 0) > time.time():
            return

        data = self._session.post('{}/oauth2/token'.format(EDGE_URL), data={
            'audience': 'edge-service',
            'grant_type': 'client_credentials',
            'client_id': EDGE_CLIENT_ID,
            'client_secret': EDGE_CLIENT_SECRET,
            'scope': 'offline openid',
        }).json()
        userdata.set('app_token', data['access_token'])
        userdata.set('app_token_expires', int((time.time() + data['expires_in']) - 60))
        self._set_authentication()

    def _refresh_user_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('user_token_expires', 0) > time.time()):
            return

        data = self._evergent('refreshToken', {'RefreshTokenRequestMessage': {'refreshToken': userdata.get('user_refresh_token')}})
        userdata.set('user_token', data['accessToken'])
        # expiresIn is epoch timestamp in ms
        userdata.set('user_token_expires', int(int(data['expiresIn']) / 1000) - 60)

    def _refresh_ovat_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('ovat_token_expires', 0) > time.time()):
            return

        data = self._evergent('getEntitlements', {
            'GetEntitlementsRequestMessage': {
                'contactID': userdata.get('contact_id'),
                'returnUpgradableFlag': True,
            },
        })
        userdata.set('ovat_token', data['ovatToken'])
        userdata.set('ovat_token_expires', int((time.time() + data['ovatTokenExpiry']) - 60))
        self._set_authentication()

    def _refresh_tokens(self, force=False):
        self._refresh_app_token(force=force)
        self._refresh_user_token(force=force)
        self._refresh_ovat_token(force=force)

    def _get_device_jwt(self):
        device_id = userdata.get('device_id')

        resp = self._session.post('{}/device/app/register'.format(EDGE_URL), json={'UniqueId': device_id})
        secret = resp.json()['data']['secret']
        # remove the need for accurate local clock by using the server time for token generation
        epoch = arrow.get(resp.headers['Date'], "ddd, DD MMM YYYY HH:mm:ss [GMT]").replace(tzinfo="UTC").timestamp

        # account for DST switch
        # note: app calls use 30secs between iat and exp
        device_jwt = jwt_encode(
            header = {'alg': 'HS256'},
            payload = {'deviceId': device_id, 'aud': 'playback-auth-service', 'iat': epoch - 4000, 'exp': epoch + 4000},
            secret_key= secret,
        )

        return device_jwt

    def profiles(self):
        self._refresh_tokens()
        data = self._evergent('getContact', {'GetContactRequestMessage': {}})
        return data.get('contactMessage', [])

    def set_profile(self, contact_id):
        userdata.set('contact_id', contact_id)
        self._refresh_tokens(force=True)

    def play(self, content_id, content_type_id='vod', catalog_type='episode', playback_mode=None, start_time=None, end_time=None):
        self._refresh_tokens(force=True)
        device_jwt = self._get_device_jwt()

        payload = {
            'deviceName': DEVICE_NAME,
            'deviceId': userdata.get('device_id'),
            'deviceManufacturer': DEVICE_MANUFACTURER,
            'deviceModelName': DEVICE_MODEL,
            'deviceOs': 'Android',
            'deviceOsVersion': '11',
            'proxyDeviceId': '',
            'contentId': content_id,
            'mediaFormat': 'dash',
            'contentTypeId': content_type_id,
            'catalogType': catalog_type,
            'drm': 'widevine',
            'delivery': 'streaming',
            'quality': 'high',
            'disableSsai': 'true',
            'supportedResolution': 'UHD',
            'supportedAudio': '',
            'supportedAudioCodecs': 'mp4a-latm,3gpp,amr-wb,flac,g711-alaw,g711-mlaw,mpeg,opus,raw,vorbis,mpeg-L2,x-ms-wma',
            'supportedVideoCodecs': 'hevc,avc,3gpp,x-motion-jpeg,mpeg2,mp4v-es,wvc1,x-ms-wmv,x-vnd.on2.vp8,x-vnd.on2.vp9',
            'supportedMaxWVSecurityLevel': 'L1' if is_wv_secure() else 'L3',
        }
        if content_type_id == 'live':
            payload['playbackMode'] = playback_mode or 'live'
            if start_time:
                payload['startTime'] = start_time
            if end_time:
                payload['endTime'] = end_time
        else:
            payload['urlParameters'] = {}

        data = self._session.post('{}/media/content/authorize'.format(EDGE_URL), json=payload, headers={'x-device-id': device_jwt}).json()

        if data['header']['code'] != 0:
            errors = data['header'].get('errors', [{}])
            raise APIError(errors[0].get('description', 'Authorization failed'))

        result = data['data']
        p = urlparse(result['contentUrl'])
        qs = [(k, v) for k, v in parse_qsl(p.query) if k not in ('aws.manifestfilter', 'filter')] # remove the 720p limit and allow 5.1 audio
        result['contentUrl'] = urlunparse(p._replace(query=urlencode(qs)))
        result['app_token'] = userdata.get('app_token')
        return result

    def search(self, query, page=1):
        return self._session.get('{}/content/search'.format(SEARCH_URL), params={
            'term': query,
            'mode': 'details',
            'st': 'published',
            'cust_sc': '',
            'pageSize': 30,
            'pageNumber': page,
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json()

    def series_detail(self, series_id):
        return self._session.get('{}/content/urn/resource/catalog/tvseries/{}'.format(DATA_STORE_URL, series_id), params={
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json()

    def seasons(self, series_id, sort_order='asc'):
        return self._session.get('{}/content/series/{}/seasons'.format(DATA_STORE_URL, series_id), params={
            'pageNumber': 1,
            'pageSize': 100,
            'sortOrder': sort_order,
            'sortBy': 'snum',
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json()

    def episode_detail(self, episode_id):
        return self._session.get('{}/content/urn/resource/catalog/tvepisode/{}'.format(DATA_STORE_URL, episode_id), params={
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json().get('data') or {}

    def smartwatch(self, series_id):
        self._refresh_tokens()
        data = self._session.get('{}/user/smartwatch/tvseries/{}'.format(EDGE_URL, series_id), params={
            'dt': API_DT,
            'client': API_CLIENT,
            'policy_evaluate': API_POLICY_EVALUATE,
            'reg': API_REG,
            'pf': API_PF,
        }).json()
        items = data.get('data') or []
        return items[0] if items else None

    def up_next(self, series_id, snum, epnum):
        data = self._session.get('{}/content/upnext'.format(DATA_STORE_URL), params={
            'g': '',
            'cty': 'tvepisode',
            'id': series_id,
            'pn': 'tvnz-provider',
            'snum': snum,
            'epnum': epnum,
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json()
        items = data.get('data') or []
        return items[0] if items else None

    def episodes(self, series_id, season_id, page=1, sort_order='asc'):
        return self._session.get('{}/content/series/{}/episodes'.format(DATA_STORE_URL, series_id), params={
            'seasonId': season_id,
            'pageNumber': page,
            'pageSize': 25,
            'sortOrder': sort_order,
            'sortBy': 'epnum',
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }).json()

    def lookup(self, cty, page=1, page_size=40, sort_by='lon.n', sort_order='asc'):
        """Browse all items of a given cty. Returns header + data list, paginated."""
        filter_obj = {
            'filter': [
                {'field': 'st', 'term': 'published', 'operator': 'equals'},
                {'field': 'cty', 'term': cty, 'operator': 'equals'},
            ],
            'match': 'ALL',
        }
        query = base64.b64encode(json.dumps(filter_obj, separators=(',', ':')).encode()).decode()
        return self._session.get('{}/content/lookup'.format(DATA_STORE_URL), params={
            'info': 'detail',
            'mode': 'detail',
            'query': query,
            'sortBy': sort_by,
            'sortOrder': sort_order,
            'pageSize': page_size,
            'pageNumber': page,
            'reg': API_REG,
            'dt': API_DT,
            'client': API_CLIENT,
            'pf': API_PF,
            'allowpg': 'true',
        }).json()

    def landingscreen(self, tab_id=None, tab_index=0):
        params = {
            'cPageNumber': 1,
            'client': API_CLIENT,
            'dt': API_DT,
            'reg': API_REG,
            'pf': API_PF,
        }
        if tab_id:
            sfid = self.landingscreen()['data']['id']  # cached no-arg call
            params.update({'cPageSize': 50, 'sfid': sfid, 'tid': tab_id, 'tabIndex': tab_index})
        else:
            params['cPageSize'] = 1
        return self._session.get('{}/catalog/storefront/landingscreen'.format(CATALOG_URL), params=params).json()

    def get_user_content(self, tags='continue_watching,recommended_for_you,favorite,because_you_watched_1'):
        self._refresh_tokens()
        data = self._session.get('{}/catalog/user/content'.format(EDGE_URL), params={
            'tags': tags,
            'dt': API_DT,
            'client': API_CLIENT,
            'policy_evaluate': API_POLICY_EVALUATE,
            'reg': API_REG,
            'pf': API_PF,
        }).json()

        result = {}
        for section in data.get('data', []):
            tag = section.get('tag')
            if tag:
                items = section.get('data', [])
                result[tag] = [item.get('info', {}) for item in items if item.get('info')]
        return result

    def add_watchlist(self, content_id):
        self._refresh_tokens()
        data = self._session.put('{}/user/favorite/create'.format(EDGE_URL), json={'itemId': content_id}, params={
            'err_on_maxlimit': 'true',
            'dt': API_DT,
            'client': API_CLIENT,
            'policy_evaluate': API_POLICY_EVALUATE,
            'reg': API_REG,
            'pf': API_PF,
        }).json()
        if data.get('header', {}).get('code') != 0:
            raise APIError('Failed to add to watchlist')

    def remove_watchlist(self, content_id):
        self._refresh_tokens()
        data = self._session.delete('{}/user/favorite/delete/{}'.format(EDGE_URL, content_id), params={
            'dt': API_DT,
            'client': API_CLIENT,
            'policy_evaluate': API_POLICY_EVALUATE,
            'reg': API_REG,
            'pf': API_PF,
        }).json()
        if data.get('header', {}).get('code') != 0:
            raise APIError('Failed to remove from watchlist')

    def remove_device(self):
        self._evergent('removeDeviceForAccount', {'RemoveDeviceReqMessage': {'serialNo': userdata.get('device_id')}})

    def logout(self):
        if userdata.get('device_id'):
            try:
                self.remove_device()
            except:
                pass

        userdata.delete('app_token')
        userdata.delete('app_token_expires')
        userdata.delete('user_token')
        userdata.delete('user_token_expires')
        userdata.delete('user_refresh_token')
        userdata.delete('ovat_token')
        userdata.delete('ovat_token_expires')
        userdata.delete('contact_id')
        userdata.delete('device_id')
        userdata.delete('profile')

        userdata.delete('refresh_token') # legacy
        userdata.delete('access_token') # legacy
        userdata.delete('token_expires') # legacy
        self.new_session()
