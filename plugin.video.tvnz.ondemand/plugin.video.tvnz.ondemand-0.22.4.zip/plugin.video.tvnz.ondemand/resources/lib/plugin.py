import codecs
from xml.sax.saxutils import escape

import arrow
from slyguy import plugin, gui, inputstream, signals, userdata
from slyguy.constants import ROUTE_LIVE_TAG, PLAY_FROM_TYPES, PLAY_FROM_ASK, PLAY_FROM_START, LIVE_HEAD

from .api import API
from .constants import IMAGE_URL
from .language import _
from .settings import settings


api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))
        folder.add_item(label="[TVNZ have made big changes. VOD returning soon]", path=plugin.url_for(home), bookmark=False)
        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    email = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not email:
        return

    api.send_otp(email)

    otp = gui.numeric(_.ENTER_OTP)
    if otp is None:
        return

    api.confirm_otp(email, otp)
    gui.refresh()


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return
    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    now = arrow.now()
    epg_count = 5

    for row in api.epg(days=1):
        plot = u''
        count = 0
        for program in row['programs']:
            start = arrow.get(program['start'])
            end = arrow.get(program['end'])
            if (now > start and now < end) or start > now:
                plot += u'[{}] {}\n'.format(start.to('local').format('h:mma'), program['title'])
                count += 1
                if count == epg_count:
                    break

        folder.add_item(
            label=row['title'],
            info={'plot': plot.strip() or None},
            art={'thumb': '{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, row['content_id'])},
            path=plugin.url_for(play, content_id=row['content_id'], content_type_id='live', catalog_type='channel', _is_live=True),
            playable=True,
        )

    return folder


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for row in api.epg(days=1):
            f.write(u'\n#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}",{name}\n{url}'.format(
                tvg_id=row['slug'],
                logo='{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, row['content_id']),
                name=row['title'],
                url=plugin.url_for(play, content_id=row['content_id'], content_type_id='live', catalog_type='channel', _is_live=True),
            ))


@plugin.route()
@plugin.merge()
@plugin.login_required()
def epg(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'<?xml version="1.0" encoding="utf-8" ?><tv>')

        for row in api.epg(days=settings.getInt('epg_days', 3)):
            f.write(u'<channel id="{}"><display-name>{}</display-name><icon src="{}"/></channel>'.format(
                row['slug'], escape(row['title']), escape('{}/image/{}/3-16x9.png?width=400'.format(IMAGE_URL, row['content_id']))))
    
            for program in row['programs']:
                prog_xml = u'<programme channel="{}" start="{}" stop="{}"><title>{}</title>'.format(
                    row['slug'], arrow.get(program['start']).to('utc').format('YYYYMMDDHHmmss Z'), arrow.get(program['end']).to('utc').format('YYYYMMDDHHmmss Z'),
                    escape(program['title']))

                if program.get('subtitle') and program['subtitle'] not in program['title']:
                    prog_xml += u'<sub-title>{}</sub-title>'.format(escape(program['subtitle']))

                if program.get('plot'):
                    prog_xml += u'<desc>{}</desc>'.format(escape(program['plot']))

                if program.get('season') and program.get('episode'):
                    prog_xml += u'<episode-num system="onscreen">S{:02d}E{:02d}</episode-num>'.format(
                        int(program['season']), int(program['episode']))

                if program.get('genres'):
                    for genre in program['genres']:
                        prog_xml += u'<category>{}</category>'.format(escape(genre))

                if program.get('lnk_id'):
                    prog_xml += u'<icon src="{}"/></programme>'.format(escape('{}/image/{}/0-16x9.png?width=400'.format(IMAGE_URL, program['lnk_id'])))

                prog_xml += u'</programme>'
                f.write(prog_xml)

        f.write(u'</tv>')


@plugin.route()
@plugin.login_required()
def play(content_id, content_type_id='vod', catalog_type='episode', **kwargs):
    data = api.play(content_id, content_type_id=content_type_id, catalog_type=catalog_type)

    if data['drm'] == 'widevine':
        ia = inputstream.Widevine(
            license_key=data['licenseUrl'],
            license_headers={'authorization': 'Bearer {}'.format(data['app_token'])},
            manifest_type = 'hls' if data['mediaFormat'] == 'hls' else 'mpd',
        )
    elif data['mediaFormat'] == 'hls':
        ia = inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs)
    elif data['mediaFormat'] == 'dash':
        ia = inputstream.MPD()
    else:
        raise Exception('Unsupported media format: {}'.format(data['mediaFormat']))

    item = plugin.Item(
        path=data['contentUrl'],
        inputstream=ia,
    )

    if ROUTE_LIVE_TAG in kwargs and catalog_type != 'channel':
        play_type = int(settings.getEnum('live_play_type', PLAY_FROM_TYPES, PLAY_FROM_ASK))
        if play_type == PLAY_FROM_START:
            item.resume_from = 1
        elif play_type == PLAY_FROM_ASK:
            item.resume_from = plugin.live_or_start()
            if item.resume_from == -1:
                return
        if not item.resume_from:
            item.resume_from = LIVE_HEAD

    return item
