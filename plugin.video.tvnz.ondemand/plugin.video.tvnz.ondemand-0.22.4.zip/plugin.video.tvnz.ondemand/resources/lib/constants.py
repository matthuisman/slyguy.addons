HEADERS = {
    'x-device-type': 'androidtv',
    'x-app-store-type': 'androidtv',
    'x-client-id': 'tvnz-tvnz-androidtv',
    'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 11; SHIELD Android TV Build/RQ1A.210105.003)',
}

DATA_STORE_URL = 'https://data-store-cdn.cms-api.tvnz.co.nz'
EDGE_URL = 'https://watch-cdn.edge-api.tvnz.co.nz'
EVERGENT_URL = 'https://rest-prod-tvnz.evergentpd.com/tvnz'
IMAGE_URL = 'https://image-resizer-cloud-cdn.cms-api.tvnz.co.nz'

EDGE_CLIENT_ID = 'android-ui-app'
EDGE_CLIENT_SECRET = 'dcb2b779-1cf8-4672-81ed-8ee1a8345389'

CHANNEL_PARTNER_ID = 'TVNZ_NZ'
EVERGENT_API_USER = 'qpapiuser'
EVERGENT_API_PASS = 'Tv9z@pi2026$'

DEVICE_NAME = 'androidtv'
DEVICE_MANUFACTURER = 'Nvidia'
DEVICE_MODEL = 'SHIELD Android TV'
