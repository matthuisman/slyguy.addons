from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    ENTER_OTP    = 30000
    LOGIN_ERROR  = 30001


_ = Language()
