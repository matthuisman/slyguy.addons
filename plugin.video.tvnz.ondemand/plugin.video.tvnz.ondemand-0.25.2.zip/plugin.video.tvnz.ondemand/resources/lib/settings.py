import uuid

from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool, AutoText

from .language import _


class Settings(CommonSettings):
    PLAY_NEXT_EPISODE = Bool('play_next_episode', _.PLAY_NEXT_EPISODE, default=True)
    SYNC_WATCHLIST = Bool('sync_watchlist', _.SYNC_WATCHLIST, default=True)
    HIDE_LOCKED = Bool('hide_locked', _.HIDE_LOCKED, default=False)
    REPAIR_MANIFESTS = Bool('repair_manifests', _.REPAIR_MANIFESTS, default=True, description=_.REPAIR_MANIFESTS_DESC)
    DEVICE_ID = AutoText('device_id', _.DEVICE_ID, generator=uuid.uuid4, confirm_clear=_.CLEAR_DEVICE_ID)


settings = Settings()
