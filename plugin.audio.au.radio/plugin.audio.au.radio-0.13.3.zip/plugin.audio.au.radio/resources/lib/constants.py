ALL = 'all'
REGIONS  = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra', ALL]
DATA_URL = 'https://i.mjh.nz/au/{region}/radio.json.gz'
