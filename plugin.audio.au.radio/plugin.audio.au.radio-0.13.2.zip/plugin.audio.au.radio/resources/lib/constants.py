REGIONS  = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra']
DATA_URL = 'https://i.mjh.nz/au/{region}/radio.json.gz'