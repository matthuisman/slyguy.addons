import sys

# when running as script, we want to capture the listitem as quick as possible before user navigates away
if sys.argv[0].lower().endswith('.py'):
    from resources.lib.util import info_to_data, busy
    data = info_to_data()
    if not data:
        sys.exit(0)

    # only enable this script if the context menu item would be shown
    from kodi_six import xbmcgui
    prop = xbmcgui.Window(10000).getProperty('_slyguy_trailer_script')
    match = (
        (data['mediatype'] == 'movie'  and "1" in prop) or
        (data['mediatype'] == 'tvshow' and "2" in prop) or
        (data['mediatype'] == 'season' and data['season_number'] < 0 and "2" in prop) or
        (data['mediatype'] == 'season' and "3" in prop)
    )
    if not match:
        sys.exit(0)

    with busy():
        sys.slyguy_extra = data
        from resources.lib.plugin import plugin
        plugin.dispatch()
else:
    from resources.lib.plugin import plugin
    plugin.dispatch()
