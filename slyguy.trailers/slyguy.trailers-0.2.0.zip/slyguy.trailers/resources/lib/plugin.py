import os
import time
import datetime
from difflib import SequenceMatcher

from kodi_six import xbmc, xbmcvfs
from six.moves.urllib_parse import urlparse, parse_qsl

from slyguy import plugin, gui, monitor, keep_alive
from slyguy.constants import ROUTE_CONTEXT, ROUTE_SETTINGS, ROUTE_SCRIPT, KODI_VERSION, ADDON_ID
from slyguy.log import log
from slyguy.util import get_addon, kodi_rpc, remove_kodi_formatting, async_tasks

from .settings import settings
from .youtube import play_youtube, get_youtube_id
from .mdblist import API
from .imdb import play_imdb
from .language import _
from .constants import SEARCH_MATCH_RATIO, TrailerItem

mdblist_api = API()


@plugin.route('/')
def home(**kwargs):
    return plugin.url_for(ROUTE_SETTINGS)


def _get_trailer_path(path):
    if not path:
        return ''

    video_id = get_youtube_id(path)
    if video_id:
        return plugin.url_for(play_yt, video_id=video_id, busy=0)
    else:
        return path


def _fetch_movie_info(movieid):
    try:
        return kodi_rpc('VideoLibrary.GetMovieDetails', {'movieid': int(movieid), 'properties': ['title', 'year', 'imdbnumber', 'uniqueid', 'file', 'trailer']})['moviedetails']
    except KeyError:
        log.warning("RPC failed to find movieid: {}".format(movieid))
        return

def _fetch_show_info(seasonid=None, tvshowid=None):
    if not seasonid and not tvshowid:
        return

    if not tvshowid:
        try:
            tvshowid = kodi_rpc('VideoLibrary.GetSeasonDetails', {'seasonid': int(seasonid), 'properties': ['tvshowid']})['seasondetails']['tvshowid']
        except KeyError:
            log.warning("RPC failed to find seasonid: {}".format(seasonid))
            return

    properties = ['title', 'year', 'imdbnumber', 'uniqueid', 'file']
    if KODI_VERSION >= 22:
        # Kodi 22 can also have trailer property
        properties.append('trailer')

    try:
        return kodi_rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': int(tvshowid), 'properties': properties})['tvshowdetails']
    except KeyError:
        log.warning("RPC failed to find tvshowid: {}".format(tvshowid))
        return


def _extract_trailer_path(path):
    if not path:
        return ''

    if ADDON_ID in path:
        parsed = urlparse(path)
        params = dict(parse_qsl(parsed.query, keep_blank_values=True))
        if '_trailer' in params:
            path = params['_trailer'].strip()
            # in case of multiple nested
            return _extract_trailer_path(path)

    return path


def _rpc_to_data(mediatype, dbid):
    dbid = int(dbid)
    if dbid < 0 or mediatype not in ('movie', 'tvshow'):
        return {}

    if mediatype == 'movie':
        rpc_data = _fetch_movie_info(movieid=dbid)
    else:
        rpc_data = _fetch_show_info(tvshowid=dbid)

    data = {
        'title': rpc_data.get('title') or rpc_data.get('label'),
        'mediatype': 'movie' if 'movieid' in rpc_data else 'tvshow',
        'dbid': rpc_data['movieid'] if 'movieid' in rpc_data else rpc_data['tvshowid'],
        'file': rpc_data['file'],
        'trailer': _extract_trailer_path(rpc_data.get('trailer')),
        'year': rpc_data['year'],
        'unique_ids': rpc_data.get('uniqueid', {}),
    }
    if not data['unique_ids'].get('imdb'):
        id = rpc_data.get('imdbnumber') or ''
        if id.lower().startswith('tt'):
            data['unique_ids']['imdb'] = id

    return data


def _li_to_data(li):
    vid_tag = li.getVideoInfoTag()
    media_type = vid_tag.getMediaType()
    data = {
        'mediatype': media_type,
        'dbid': vid_tag.getDbId(),
        'title': vid_tag.getTitle() or li.getLabel(),
        'tvshowtitle': vid_tag.getTVShowTitle(),
        'tvshowdbid': xbmc.getInfoLabel('ListItem.TvShowDBID'), # get from vid_tag?
        'file': vid_tag.getFilenameAndPath() if media_type == 'movie' else vid_tag.getPath(),
        'trailer': _extract_trailer_path(vid_tag.getTrailer()),
        'plot': vid_tag.getPlot(),
        'tagline': vid_tag.getTagLine(),
        'year': vid_tag.getYear(),
        'season_number': vid_tag.getSeason(),
        'art': {},
        'unique_ids': {},
    }

    for key in ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']:
        data['art'][key] = li.getArt(key)

    if KODI_VERSION >= 20:
        data['genre'] = vid_tag.getGenres()
        for id_type in ('imdb', 'tvdb', 'tmdb'):
            uid = vid_tag.getUniqueID(id_type)
            if uid:
                data['unique_ids'][id_type] = uid
    else:
        data['genre'] = vid_tag.getGenre()

    return data


def _build_item(info):
    mediatype = info.get('mediatype')
    dbid = int(info.get('dbid') or -1)

    if not info.get('unique_ids', {}).get('imdb') and mediatype and dbid >= 0:
        rpc_data = _rpc_to_data(mediatype, dbid)
        if rpc_data.get('unique_ids', {}):
            info['unique_ids'] = rpc_data['unique_ids']

    clean_title = title = info.get('title')
    if mediatype == 'season':
        title = info.get('tvshowtitle')

    if title:
        clean_title = remove_kodi_formatting(title)
        title = u"{} ({})".format(clean_title, _.TRAILER)

    item = TrailerItem()
    item.label = title
    item.info = {
        'dbid': dbid,
        'mediatype': mediatype,
        'title': title,
        'season_number': int(info.get('season_number') or -1),
        'plot': info.get('plot'),
        'tagline': info.get('tagline'),
        'trailer': info.get('trailer'),
        'year': int(info.get('year') or 0),
        'genre': info.get('genre'),
    }
    item.data = {
        'fallback': None,
        'dir': None,
        'filename': None,
        'clean_title': clean_title,
        'unique_id': {}
    }
    item.art = info.get('art', {})

    if mediatype == 'season':
        item.info['mediatype'] = 'tvshow'
        show_data = None

        # season often has the year of the season which causes search to fail
        # grab the year and show title of our show if we are DB media
        if item.info['season_number'] < 0:
            # All seasons - cant query season. Kodi 19 allows getting TvShowDBID info label
            if KODI_VERSION >= 19:
                show_data = _fetch_show_info(tvshowid=info.get('tvshowdbid'))
                if show_data and show_data.get('trailer'):
                    # no season so use our shows trailer as our own if available
                    item.info['trailer'] = show_data['trailer']
        else:
            show_data = _fetch_show_info(seasonid=dbid)

        if show_data:
            item.info['title'] = show_data['title']
            item.info['year'] = show_data['year']
            item.data['fallback'] = show_data.get('trailer') # TODO: support fallback

    if item.info['mediatype'] == 'movie' and info.get('file'):
        item.data['dir'] = os.path.dirname(info['file'])
        item.data['filename'] = os.path.basename(info['file'])
    elif item.info['mediatype'] == 'tvshow' and info.get('file'):
        item.data['dir'] = os.path.dirname(info['file'])

    for id_type in ('imdb', 'tmdb', 'tvdb', None):
        if id_type in info.get('unique_ids', {}):
            item.data['unique_id'] = {'type': id_type, 'id': info['unique_ids'][id_type]}
            break

    # check local trailer first
    if settings.PREFER_LOCAL.value:
        item.path = _get_local_trailer(
            mediatype = item.info['mediatype'],
            dir = item.data['dir'],
            filename = item.data['filename'],
        )

    # TODO: we should detect if yt-dl fails and then fallback to these as well
    if not item.path and (not item.info['trailer'] or not settings.PREFER_SCRAPED.value) and any((settings.SEARCH_YOUTUBE.value, settings.SEARCH_IMDB.value)):
        # if no unique id, try mdblist search by title/year
        if not item.data['unique_id'].get('id') and settings.MDBLIST_SEARCH.value:
            item.data['unique_id'] = _search_mdblist_for_id(
                mediatype = item.info['mediatype'],
                title = item.data['clean_title'],
                year = item.info['year'],
            ) or {}

        # mdblist YouTube trailer
        if settings.SEARCH_YOUTUBE.value:
            item.path = _get_mdblist_trailer(
                mediatype = item.info['mediatype'],
                id = item.data['unique_id'].get('id'),
                id_type = item.data['unique_id'].get('type'),
            )

        # IMDB trailer
        if not item.path and settings.SEARCH_IMDB.value:
            item.path = _get_imdb_trailer(
                mediatype = item.info['mediatype'],
                id = item.data['unique_id'].get('id'),
                id_type = item.data['unique_id'].get('type'),
                season_number = item.info['season_number'],
            )

    # fallback to the actal trailer
    item.path = item.path or _get_trailer_path(path=item.info['trailer'])

    if item.path:
        _require_addon(item.path)
    else:
        gui.notification(_.TRAILER_NOT_FOUND)
        item.path = ''

    return item


@plugin.route(ROUTE_SCRIPT)
def script(slyguy_extra, **kwargs):
    # busy is done in default.py earlier
    return _build_item(slyguy_extra)


@plugin.route(ROUTE_CONTEXT)
def context_trailer(listitem, **kwargs):
    with gui.busy():
        data = _li_to_data(listitem)
        return _build_item(data)


def _require_addon(url):
    parsed = urlparse(url)
    if parsed.scheme.lower() == 'plugin' and parsed.netloc != ADDON_ID:
        get_addon(parsed.netloc, install=True, required=True)


def _get_local_trailer(mediatype, dir, filename):
    if mediatype == 'movie' and filename:
        filename = os.path.splitext(filename)[0].lower()
        files = xbmcvfs.listdir(dir)[1]
        for file in files:
            name, ext = os.path.splitext(file.lower())
            if name in ('movie-trailer', "{}-trailer".format(filename)):
                path = os.path.join(dir, file)
                if ext == '.txt':
                    with xbmcvfs.File(path) as f:
                        path = _get_trailer_path(f.read().strip())
                return path

    elif mediatype == 'tvshow' and dir:
        folder_name = os.path.basename(dir).lower()
        files = xbmcvfs.listdir(dir)[1]
        for file in files:
            name, ext = os.path.splitext(file.lower())
            if name in ('tvshow-trailer', "{}-trailer".format(folder_name)):
                path = os.path.join(dir, file)
                if ext == '.txt':
                    with xbmcvfs.File(path) as f:
                        path = _get_trailer_path(f.read().strip())
                return path


def _get_imdb_trailer(mediatype, id, id_type, season_number):
    if not mediatype or not id:
        return

    if id_type != 'imdb':
        try:
            imdb_id = mdblist_api.get_media(mediatype, id, id_type)['ids']['imdb']
        except KeyError:
            return
    else:
        imdb_id = id

    return plugin.url_for(imdb, video_id=imdb_id, season_number=season_number, busy=0)


def _search_mdblist_for_id(mediatype, title, year):
    if not mediatype or not title or not year:
        return

    log.debug("mdblist search for: {} '{}' ({})".format(mediatype, title, year))
    results = mdblist_api.search_media(mediatype, title, year, limit=10)
    title = "{} {}".format(title.lower().strip().replace(' ', ''), year)
    for result in results:
        result['ratio'] = SequenceMatcher(None, title, "{} {}".format(result['title'].lower().strip().replace(' ', ''), result['year'])).ratio()
    results = sorted(results, key=lambda x: x['ratio'], reverse=True)
    log.debug("mdblist search results: {}".format(results))

    results = [x for x in results if x['ratio'] >= SEARCH_MATCH_RATIO]
    if not results:
        return

    log.info("mdblist search result: {}".format(results[0]))
    if not results[0].get('ids'):
        return

    for id_type in ('imdb', 'tvdb', 'tmdb'):
        id = results[0]['ids'].get(id_type) or results[0]['ids'].get(id_type+'id')
        if id:
            return {'type': id_type, 'id': id}


def _get_mdblist_trailer(mediatype, id, id_type):
    if not mediatype or not id:
        return

    data = mdblist_api.get_media(mediatype, id, id_type=id_type)
    trailer = _get_trailer_path(data.get('trailer'))
    if ADDON_ID in trailer:
        log.info("mdblist trailer: {}".format(trailer))
        return trailer


@plugin.route('/by_dbid')
def by_dbid(mediatype, dbid, fallback='', **kwargs):
    with gui.busy():
        data = _rpc_to_data(mediatype, dbid)
        if fallback and not data['trailer']:
            data['trailer'] = fallback
        return _build_item(data)


@plugin.route('/by_unique_id')
def by_unique_id(mediatype, id, id_type=None, **kwargs):
    data = {
        'mediatype': mediatype,
        'unique_ids': {id_type: id},
    }
    with gui.busy():
        return _build_item(data)


@plugin.route('/by_title_year')
def by_title_year(mediatype, title, year, **kwargs):
    data = {
        'mediatype': mediatype,
        'title': title,
        'year': year,
    }
    with gui.busy():
        return _build_item(data)


@plugin.route('/play')
def play_yt(video_id, busy=1, **kwargs):
    with gui.busy(busy):
        return play_youtube(video_id)


@plugin.route('/imdb')
def imdb(video_id, season_number=-1, busy=1, **kwargs):
    with gui.busy(busy):
        return play_imdb(video_id, season_number=season_number)


@plugin.route('/update_db_trailers')
def update_db_trailers(revert=0, show_progress=0, **kwargs):
    revert = bool(int(revert))
    show_progress = bool(int(show_progress))
    heading = "Restoring Trailers" if revert else "Updating Trailers"

    # do newest movies first as likrly to have trailer watched (recently added)
    params = {
        'properties': ['trailer'],
        'sort': {
            'method': 'dateadded',
            'order': 'descending'
        }
    }
    if revert or not settings.DB_TRAILERS_NO_TRAILERS.value:
        params['filter'] = {'field': 'hastrailer', 'operator': 'true', 'value': '1'}

    def process(method, params):
        if progress.iscanceled() or monitor.abortRequested():
            raise StopIteration()

        kodi_rpc(method, params)

        if 'movieid' in params:
            counts['completed_movies'] += 1
        else:
            counts['completed_shows'] += 1

        elapsed = time.monotonic() - started
        total = counts['movies'] + counts['shows']
        completed = counts['completed_movies'] + counts['completed_shows']
        rate = completed / elapsed if elapsed else 0
        remaining = (total - completed) / rate if rate else 0

        label = []
        if counts['movies']:
            label.append('Movies: {} / {}'.format(counts['completed_movies'], counts['movies']))
        if counts['shows']:
            label.append('TV Shows: {} / {}'.format(counts['completed_shows'], counts['shows']))
        label = ', '.join(label)
        progress.update(completed / total * 100, message="{}\nSpeed: {:.1f}/sec\nETA: {}".format(label, rate, str(datetime.timedelta(seconds=int(remaining)))))

    with gui.progress(heading=heading, enabled=show_progress) as progress:
        tasks = []
        counts = {'total_movies': 0, 'total_shows': 0, 'movies': 0, 'shows': 0, 'completed_movies': 0, 'completed_shows': 0}

        if settings.DB_TRAILERS_MOVIES.value or revert:
            progress.update(0, "Retrieving Movies...")
            rows = kodi_rpc('VideoLibrary.GetMovies', params)['movies']
            counts['total_movies'] = len(rows)
            progress.update(0, "Checking {} Movies...".format(counts['total_movies']))
            for row in rows:
                trailer = _extract_trailer_path(row['trailer'])
                if not revert:
                    trailer = plugin.url_for(by_dbid, mediatype='movie', dbid=row['movieid'], _trailer=trailer)

                if row['trailer'] != trailer:
                    counts['movies'] += 1
                    tasks.append(lambda movieid=row['movieid'], trailer=trailer: process(
                        'VideoLibrary.SetMovieDetails', {'movieid': movieid, 'trailer': trailer}
                    ))

        if settings.DB_TRAILERS_TV.value or (settings.DB_TRAILERS_TV.is_enabled and revert):
            progress.update(0, "Retrieving TV Shows...")
            rows = kodi_rpc('VideoLibrary.GetTvShows', params)['tvshows']
            counts['total_shows'] = len(rows)
            progress.update(0, "Checking {} TV Shows...".format(counts['total_shows']))
            for row in rows:
                trailer = _extract_trailer_path(row['trailer'])
                if not revert:
                    trailer = plugin.url_for(by_dbid, mediatype='tvshow', dbid=row['tvshowid'], _trailer=trailer)

                if row['trailer'] != trailer:
                    counts['shows'] += 1
                    tasks.append(lambda tvshowid=row['tvshowid'], trailer=trailer: process(
                        'VideoLibrary.SetTVShowDetails', {'tvshowid': tvshowid, 'trailer': trailer}
                    ))

        started = time.monotonic()
        try:
            async_tasks(tasks)
        except StopIteration:
            log.info("update db trailers aborted")
            return

    log.info("Succesfully updated DB trailers")
    return True

@plugin.route('/test_streams')
def test_streams(**kwargs):
    STREAMS = [
        ['YouTube 4K', plugin.url_for(play_yt, video_id='Q82tQJyJwgk')],
        ['YouTube 4K HDR', plugin.url_for(play_yt, video_id='tO01J-M3g0U')],
        ['YouTube Live Stream', plugin.url_for(play_yt, video_id='mKCieTImjvU')],
        ['IMDB', plugin.url_for(imdb, video_id='tt10548174')],
        ['Movie imdb id -> mdblist', plugin.url_for(by_unique_id, mediatype='movie', id='tt0133093', id_type='imdb')],
        ['Movie Title / Year -> mdblist', plugin.url_for(by_title_year, mediatype='movie', title='The Matrix', year='1999')],
        ['Show tvdb id -> mdblist', plugin.url_for(by_unique_id, mediatype='tvshow', id='392256', id_type='tvdb')],
        ['Show Title / Year -> mdblist', plugin.url_for(by_title_year, mediatype='tvshow', title='The Last of Us', year='2023')],
        ['YouTube Plugin Path', 'plugin://plugin.video.youtube/play/?video_id=Q82tQJyJwgk'],
        ['Tubed Plugin Path', 'plugin://plugin.video.tubed/play/?video_id=Q82tQJyJwgk'],
    ]

    try:
        last_movies = kodi_rpc('VideoLibrary.GetMovies', {'sort': {'order': 'descending', 'method': 'dateadded'}, 'limits': {'start': 0, 'end': 1}})['movies']
        if last_movies:
            dbid = last_movies[0]['movieid']
            STREAMS.append(['Last movie DBID', plugin.url_for(by_dbid, mediatype='movie', dbid=dbid)])
    except KeyError:
        pass

    try:
        last_shows = kodi_rpc('VideoLibrary.GetTVShows', {'sort': {'order': 'descending', 'method': 'dateadded'}, 'limits': {'start': 0, 'end': 1}})['tvshows']
        if last_shows:
            dbid = last_shows[0]['tvshowid']
            STREAMS.append(['Last tvshow DBID', plugin.url_for(by_dbid, mediatype='tvshow', dbid=dbid)])
    except KeyError:
        pass

    folder = plugin.Folder(_.TEST_STREAMS, content=None)
    for stream in STREAMS:
        folder.add_item(label=stream[0], is_folder=False, path=stream[1])
    return folder


keep_alive.register(update_db_trailers, hours=1, enable=settings.DB_TRAILERS_AUTO_UPDATE.value, user_option=False)
