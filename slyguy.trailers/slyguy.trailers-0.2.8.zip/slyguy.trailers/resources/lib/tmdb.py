from slyguy.session import Session
from slyguy.log import log

from .constants import TMDB_API_KEY, TMDB_API_URL

VIDEO_PARAMS = {'include_video_language': 'en,null'}
VIDEO_TYPES = ('Trailer', 'Teaser')


def _is_youtube(video):
    return (video.get('site') or '').lower() == 'youtube' and video.get('key')


def _auth(token):
    token = (token or '').strip()
    if token.count('.') == 2:
        # v4 read access token (JWT)
        return {'headers': {'Authorization': 'Bearer {}'.format(token)}}
    # v3 api key
    return {'params': {'api_key': token}}


def _to_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def find_best_video(videos):
    candidates = [x for x in videos or [] if _is_youtube(x) and x.get('type') in VIDEO_TYPES]
    if not candidates:
        return

    def score(video):
        return (
            video.get('type') == 'Trailer',
            bool(video.get('official')),
            (video.get('iso_639_1') or '').lower().startswith('en'),
            _to_int(video.get('size')),  # up to 2160, higher is better
        )

    # earliest published first so among equally ranked videos the original wins
    candidates.sort(key=lambda x: x.get('published_at') or '')
    candidates.sort(key=score, reverse=True)

    best = candidates[0]
    log.debug("TMDB video: '{}' ({} {}p)".format(best.get('name'), best.get('type'), best.get('size')))
    return best['key']


class API(object):
    def __init__(self):
        self._session = Session(base_url=TMDB_API_URL)

    def _get(self, path, **params):
        auth = _auth(TMDB_API_KEY)
        params.update(auth.get('params') or {})
        data = self._session.get(path, params=params, headers=auth.get('headers')).json()
        if not isinstance(data, dict) or data.get('success') is False:
            # 404s come back as {"success": False, "status_code": 34, ...}
            log.warning("TMDB error for '{}': {}".format(path, data))
            return {}
        return data

    def _get_media_type(self, mediatype):
        mediatype = (mediatype or '').lower()
        if mediatype in ('tvshow', 'show', 'tv'):
            return 'tv'
        elif mediatype == 'movie':
            return 'movie'

    def _get_tmdb_id(self, mediatype, id, id_type):
        mediatype = self._get_media_type(mediatype)
        if not mediatype or not id:
            return

        id_type = (id_type or '').lower()
        if id_type.endswith('id'):
            id_type = id_type[:-2]

        if not id_type or id_type == 'tmdb':
            return id

        if id_type == 'imdb':
            data = self._get('/find/{}'.format(id), external_source='imdb_id')
            results = data.get('movie_results' if mediatype == 'movie' else 'tv_results') or []
        elif id_type == 'tvdb' and mediatype == 'tv':
            results = self._get('/find/{}'.format(id), external_source='tvdb_id').get('tv_results') or []
        else:
            return

        if results and results[0].get('id'):
            return results[0]['id']

    def get_ids(self, mediatype, id, id_type):
        tmdb_id = self._get_tmdb_id(mediatype, id, id_type)
        if not tmdb_id:
            return {}

        data = self._get('/{}/{}/external_ids'.format(self._get_media_type(mediatype), tmdb_id))
        ids = {'tmdb': tmdb_id}
        for key in ('imdb', 'tvdb'):
            if data.get(key + '_id'):
                ids[key] = str(data[key + '_id'])
        return ids

    def get_trailer(self, mediatype, id, id_type, season_number=-1):
        mediatype = self._get_media_type(mediatype)
        tmdb_id = self._get_tmdb_id(mediatype, id, id_type)
        if not tmdb_id:
            return

        season_number = int(season_number if season_number is not None else -1)
        videos = []
        if mediatype == 'tv' and season_number >= 0:
            videos = self._get('/tv/{}/season/{}/videos'.format(tmdb_id, season_number), **VIDEO_PARAMS).get('results') or []

        if not videos and mediatype == 'tv' and season_number >= 0:
            # season has no videos of its own, prefer show videos naming the season
            show_videos = self._get('/tv/{}/videos'.format(tmdb_id), **VIDEO_PARAMS).get('results') or []
            season = 'season {}'.format(season_number)
            videos = [x for x in show_videos if season in (x.get('name') or '').lower()]

        if not videos:
            videos = self._get('/{}/{}/videos'.format(mediatype, tmdb_id), **VIDEO_PARAMS).get('results') or []

        video_id = find_best_video(videos)
        log.debug("TMDB trailer for {}/{} (season {}): {}".format(mediatype, tmdb_id, season_number, video_id))
        return video_id

    def search_media(self, mediatype, title, year):
        mediatype = self._get_media_type(mediatype)
        if not mediatype:
            return []

        params = {'query': title}
        if year:
            params['year' if mediatype == 'movie' else 'first_air_date_year'] = year

        results = []
        for row in self._get('/search/{}'.format(mediatype), **params).get('results') or []:
            date = row.get('release_date' if mediatype == 'movie' else 'first_air_date') or ''
            results.append({
                'id': row.get('id'),
                'title': row.get('title') or row.get('name') or '',
                'year': date[:4],
            })

        return results
