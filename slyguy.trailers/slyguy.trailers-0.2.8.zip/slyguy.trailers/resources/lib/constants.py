from slyguy import plugin

from .settings import settings


class TrailerItem(plugin.Item):
    def __init__(self, *args, **kwargs):
        kwargs['properties'] = kwargs.get('properties') or {}
        kwargs['properties']['script.trakt.exclude'] = '1'
        kwargs['no_resume'] = True
        kwargs['windowed'] = settings.TRAILER_BACKGROUND.value
        super(TrailerItem, self).__init__(*args, **kwargs)


YOTUBE_PLUGIN_ID = 'plugin.video.youtube'
TUBED_PLUGIN_ID = 'plugin.video.tubed'

TMDB_API_URL = 'https://api.themoviedb.org/3{}'
TMDB_API_KEY = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJiYjVhMTdlZjEwMmJkNGMwMDM3MzRkMmViYmFiNjczNCIsIm5iZiI6MTI3NTU3NDYwOC4wLCJzdWIiOiI0YzA4MGRiMDAxN2EzYzdlODYwMDA3NjUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.Lh0qsM9eCoyf7x6-CGzFxobplhuyJnC491ZfDpAPzA0'
SEARCH_MATCH_RATIO = 0.75

IMDB_API_URL = 'https://graphql.prod.api.imdb.a2z.com/'
IMDB_VIDEO_URL = 'https://www.imdb.com/video/{}/'
IMDB_API_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en',
    'Accept-Encoding': 'gzip',
    'Referer': 'https://www.imdb.com/',
    'Origin': 'https://www.imdb.com',
    'x-imdb-client-name': 'imdb-web-next-localized',
}
IMDB_QUALITY_MAP = {
    'DEF_1080p': '1920x1080',
    'DEF_720p': '1280x720',
    'DEF_480p': '864x480',
    'DEF_SD': '480x272',
}
