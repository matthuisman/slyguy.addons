import yt_dlp_ejs

available_dependencies = {'yt_dlp_ejs': yt_dlp_ejs}
