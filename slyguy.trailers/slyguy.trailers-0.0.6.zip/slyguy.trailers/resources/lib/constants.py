YOTUBE_PLUGIN_ID = 'plugin.video.youtube'
TUBED_PLUGIN_ID = 'plugin.video.tubed'

MDBLIST_API_KEY = 'tliqxfv0tg537ff7xyqkv7tug'
MDBLIST_API_URL = 'https://api.mdblist.com{}'
