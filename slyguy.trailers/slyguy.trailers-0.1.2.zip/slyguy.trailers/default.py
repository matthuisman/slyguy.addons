import sys

# when running as script, we want to capture the listitem as quick as possible before user navigates away
if sys.argv[0].lower().endswith('.py'):
    trailer = None
    if len(sys.argv) > 1:
        # come here from redirect script but not via information dialog
        trailer = sys.argv[1]

    from resources.lib.util import info_to_data, busy
    data = info_to_data(trailer=trailer)
    if not data:
        # if we not on media, check if clicked our addon and load into the plugin (settings), otherwise ignore
        from kodi_six import xbmc, xbmcaddon
        addon_id = xbmcaddon.Addon().getAddonInfo('id')
        if addon_id in xbmc.getInfoLabel('ListItem.FolderPath'):
            xbmc.executebuiltin('ActivateWindow(Programs,{},return)'.format('plugin://{}'.format(addon_id)))
        sys.exit(0)

    if not trailer:
        # only play if the context menu item would be shown and not coming from redirect plugin
        # eg. a keyboard shortcut
        from kodi_six import xbmcgui
        prop = xbmcgui.Window(10000).getProperty('_slyguy_trailer_script')
        match = (
            (data['mediatype'] == 'movie'  and "1" in prop) or
            (data['mediatype'] == 'tvshow' and "2" in prop) or
            (data['mediatype'] == 'season' and data['season_number'] < 0 and "2" in prop) or
            (data['mediatype'] == 'season' and "3" in prop)
        )
        if not match:
            sys.exit(0)

    with busy():
        sys.slyguy_extra = data
        from resources.lib.plugin import plugin
        plugin.dispatch()
else:
    from resources.lib.plugin import plugin
    plugin.dispatch()
