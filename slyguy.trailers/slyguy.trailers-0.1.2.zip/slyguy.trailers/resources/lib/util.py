from kodi_six import xbmc
from contextlib import contextmanager


def info_to_data(trailer=None):
    media_type = xbmc.getInfoLabel('ListItem.DBTYPE')
    if not media_type:
        return {'trailer': trailer} if trailer else {}

    data = {
        'mediatype': media_type,
        'dbid': xbmc.getInfoLabel('ListItem.DBID') or -1,
        'title': xbmc.getInfoLabel('ListItem.Title'),
        'tvshowtitle': xbmc.getInfoLabel('ListItem.TvShowTitle'),
        'tvshowdbid': xbmc.getInfoLabel('ListItem.TvShowDBID'),
        'file': xbmc.getInfoLabel('ListItem.FilenameAndPath') if media_type == 'movie' else xbmc.getInfoLabel('ListItem.Path'),
        'trailer': trailer or xbmc.getInfoLabel('ListItem.Trailer'),
        'plot': xbmc.getInfoLabel('ListItem.Plot'),
        'tagline': xbmc.getInfoLabel('ListItem.TagLine'),
        'year': xbmc.getInfoLabel('ListItem.Year'),
        'season_number': int(xbmc.getInfoLabel('ListItem.Season') or -1),
        'genre': xbmc.getInfoLabel('ListItem.Genre'),
        'art': {},
        'unique_ids': {},
    }

    for key in ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']:
        data['art'][key] = xbmc.getInfoLabel('ListItem.Art({})'.format(key))

    if int(xbmc.getInfoLabel("System.BuildVersion").split('.')[0]) >= 20:
        for id_type in ('imdb', 'tvdb', 'tmdb'):
            uid = xbmc.getInfoLabel('ListItem.UniqueID({})'.format(id_type))
            if uid:
                data['unique_ids'][id_type] = uid

    if not data['unique_ids'].get('imdb'):
        id = xbmc.getInfoLabel('ListItem.IMDBNumber') or ''
        if id.lower().startswith('tt'):
            data['unique_ids']['imdb'] = id

    return data


@contextmanager
def busy(show=1):
    if int(show):
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        yield
    finally:
        if int(show):
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
