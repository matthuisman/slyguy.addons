from yt_dlp.globals import Indirect

_jsc_providers = Indirect({})
_jsc_preferences = Indirect(set())
