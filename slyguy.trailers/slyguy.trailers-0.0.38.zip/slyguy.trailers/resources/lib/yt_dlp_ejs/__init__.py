from yt_dlp_ejs._version import version

__all__ = ["version"]
