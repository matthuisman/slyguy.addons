from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    LIVE_CHANNELS = 30000
    INVALID_TOKEN = 30001

_ = Language()
