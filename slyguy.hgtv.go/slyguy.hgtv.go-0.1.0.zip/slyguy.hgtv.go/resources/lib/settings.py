from slyguy.settings import CommonSettings

from .language import _


class Settings(CommonSettings):
    pass


settings = Settings()
