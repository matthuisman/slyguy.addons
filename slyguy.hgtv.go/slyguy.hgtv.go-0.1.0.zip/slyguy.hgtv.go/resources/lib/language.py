from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    INVALID_TOKEN = 30001


_ = Language()
