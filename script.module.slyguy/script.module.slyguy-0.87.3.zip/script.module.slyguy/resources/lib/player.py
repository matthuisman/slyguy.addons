import json
import time

from kodi_six import xbmc
from threading import Thread

from slyguy import monitor, log
from slyguy.constants import LIVE_HEAD
from slyguy.util import get_kodi_string, set_kodi_string
from slyguy.router import add_url_args


class Player(xbmc.Player):
    def playback(self, playing_file, callback, play_skips, start_pos=0):
        play_time = 0
        last_play_time = int(self.getTime())
        last_callback = None
        last_callback_ts = int(time.time())

        # a stream reports 0 until it has opened and the pre-seek position until a resume seek lands,
        # so hold the first callback back until it is playing from where we asked it to start.
        # under 10s is start from the beginning (intro skips become a resume point too) and LIVE_HEAD
        # is the live edge, neither has a seek to wait on so just report the first position we get
        expect_start = int(start_pos or 0)
        if not 10 < expect_start < LIVE_HEAD:
            expect_start = 0

        while not monitor.waitForAbort(1) and self.isPlaying() and self.getPlayingFile() == playing_file:
            if callback and callback['type'] == 'interval_ts' and int(time.time()) - last_callback_ts >= callback['interval']:
                plugin_url = add_url_args(callback['callback'], _time=play_time)
                log.debug("Player callback: {}".format(plugin_url))
                xbmc.executebuiltin('RunPlugin({})'.format(plugin_url))
                last_callback_ts = int(time.time())

            play_time = int(self.getTime())

            skipped = abs(play_time - last_play_time) > 5
            last_play_time = play_time

            if not skipped:
                new_play_skips = []
                for row in play_skips:
                    if play_time >= row['to']:
                        continue

                    diff = play_time - row['from']
                    if diff < 0:
                        new_play_skips.append(row)
                    elif diff <= 5:
                        self.seek(row['to'])
                play_skips = new_play_skips

            diff = abs(play_time - last_callback) if last_callback is not None else 0

            due = False
            if callback and callback['type'] == 'interval' and last_callback != play_time:
                if last_callback is None:
                    due = play_time > 0 and (not expect_start or skipped or abs(play_time - expect_start) <= 5)
                else:
                    # also report on a jump, a stop can follow before the next sample
                    due = skipped or diff >= callback['interval']

            if due:
                plugin_url = add_url_args(callback['callback'], _time=play_time)
                log.debug("Player callback: {}".format(plugin_url))
                xbmc.executebuiltin('RunPlugin({})'.format(plugin_url))
                last_callback = play_time

        if getattr(self, '_stop_time', 0):
            play_time = self._stop_time
        self._stop_time = None

        log.debug("Playback finished at {}s".format(play_time))
        if callback and last_callback != play_time:
            # Stop playback callback
            plugin_url = add_url_args(callback['callback'], _time=play_time)
            log.debug("Player callback: {}".format(plugin_url))
            xbmc.executebuiltin('RunPlugin({})'.format(plugin_url))

    def onPlayBackStopped(self):
        self._save_stop_time()

    def onPlayBackEnded(self):
        self._save_stop_time()

    def _save_stop_time(self):
        # getTime() still reports the final position here, so a seek just before stop isn't lost
        try:
            self._stop_time = int(self.getTime())
        except Exception:
            pass

    def seek(self, seconds):
        # TODO: doesnt seem to mark as watched. try using API seek instead
        log.debug("Seeking to: {}".format(seconds))
        self.seekTime(seconds)

    def onAVStarted(self):
        self._stop_time = None

        try:
            play_data = json.loads(get_kodi_string('_slyguy_play_data'))
        except:
            return

        set_kodi_string('_slyguy_play_data')
        playing_file = self.getPlayingFile()
        if play_data['playing_file'] != playing_file:
            return

        if self.isPlayingVideo():
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        else:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)

        if play_data['next']['next_file']:
            pos = playlist.getposition()+1
            if playlist.size() > pos and playlist[pos].getPath() == play_data['next']['next_file']:
                log.debug('Up next already correct: {}'.format(play_data['next']['next_file']))
            else:
                playlist.remove(play_data['next']['next_file'])
                playlist.add(play_data['next']['next_file'], index=playlist.getposition()+1)
                log.debug('Up next added: {}'.format(play_data['next']['next_file']))

        play_skips = []
        for skip in play_data['skips']:
            if not skip.get('to'):
                skip['to'] = int(self.getTotalTime())+1
            else:
                if skip['to'] < 0:
                    self.seek(self.getTotalTime() + skip['to'] - 3)
                    continue

                skip['to'] -= 3

            if not skip.get('from'):
                continue

            play_skips.append(skip)

        callback = None
        if play_data['callback']['callback']:
            callback = play_data['callback']

        if callback or play_skips:
            self._thread = Thread(target=self.playback,
                args=(playing_file, callback, play_skips, play_data.get('start') or 0), daemon=True)
            self._thread.start()
