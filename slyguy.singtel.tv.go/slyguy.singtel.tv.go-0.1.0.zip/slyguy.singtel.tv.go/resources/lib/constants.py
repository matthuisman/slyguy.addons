HEADERS = {
    'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 8.1.0; MI 5 Build/OPM7.181005.003)',
    'x-forwarded-for': '219.75.27.16',
}

API_URL = 'https://miotvapp.singtel.com/mioTVGO6.0{}'
DATA_URL = 'https://sifvideostore.s3.amazonaws.com/mioTVGO/JsonData/Common/common.json.gz'
APP_KEY = 'gF0f9mwL3Tyyn8oqeJypDTQ6vA4='
EPG_URL = 'https://i.mjh.nz/Singtel/epg.xml.gz'

APP_DEVICE = 'Mob'
APP_MODE = 'wifi'
APP_VER  = '5.7'
APP_ID_TYPE = '2'
APP_ID = 'AND'
