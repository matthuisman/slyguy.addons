HEADERS = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
    'referer': 'https://www.shinetv.co.nz',
}

BASE_URL  = 'https://www.shinetv.co.nz{}'
LIVESTREAM_URL = 'https://player-api.new.livestream.com/accounts/29901189/events/{event_id}/stream_info'
