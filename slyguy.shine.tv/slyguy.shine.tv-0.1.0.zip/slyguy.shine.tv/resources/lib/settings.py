from slyguy.settings import CommonSettings


class Settings(CommonSettings):
    pass


settings = Settings()
