DATA_URL = 'https://i.mjh.nz/PlutoTV/.channels.json.gz'
ALL = 'all'
MY_CHANNELS = 'my_channels'
UUID_NAMESPACE = '122e1611-0232-4336-bf43-e054c8ecd0d5'
ALT_USER_AGENT = 'otg/1.5.1 (AppleTv Apple TV 4; tvOS16.0; appletv.client) libcurl/7.58.0 OpenSSL/1.0.2o zlib/1.2.11 clib/1.8.56'
# inputstream.adaptive can only compare subtitle PTS against A/V packet PTS from 22.2.6 onwards
# (xbmc/inputstream.adaptive#1831, fixed by #1890). Older versions freeze when subs are enabled.
IA_SUBS_FIX_VERSION = '22.2.6'
URL = 'https://ipv4.pluto.tv/api/tn/video/playout/v2/stitch/hls/channel/{id}/master.m3u8?jwt={token}&includeExtendedEvents=true'
