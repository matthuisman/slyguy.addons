#!/bin/bash
/bin/bash /media/SHARE/system/custom.sh