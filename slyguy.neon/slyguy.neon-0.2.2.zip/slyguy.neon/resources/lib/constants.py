HEADERS = {
    'User-Agent': 'XDKAndroidWebView/2.5.3/XDKWebView|NVIDIA',
    'X-Forwarded-For' : '202.89.4.222',
}

API_URL = 'https://api.neontv.co.nz/api/client/gql'

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/ref:{}?jwtauth={}'
BRIGHTCOVE_ACCOUNT = '5449166731001'
BRIGHTCOVE_KEY = 'BCpkADawqM31jJSqDf-CU0kRN8vMu46gUZEzcsZuB6MCCF3tx37IuORLwSj3IGTghvxSyTplhz9kRrSCm3zBR1S2UExgefbeYzdgIpcoEmU3VV-loNsg_BV7pdsVMz6_Am0cz_sS6mOG2jeT'

TV_ID = '/tv-series/all'
MOVIES_ID = '/browse-movies/all-movies'
