import arrow
from slyguy import plugin, gui, userdata, signals, inputstream
from slyguy.constants import ROUTE_LIVE_TAG

from .api import API
from .language import _
from .settings import settings

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.FEATURED, _bold=True), path=plugin.url_for(featured))
        folder.add_item(label=_(_.VIDEOS, _bold=True), path=plugin.url_for(videos))
        folder.add_item(label=_(_.CREATORS, _bold=True), path=plugin.url_for(creators))
        folder.add_item(label=_(_.PODCASTS, _bold=True), path=plugin.url_for(podcast_creators))
        folder.add_item(label=_(_.MY_VIDEOS, _bold=True), path=plugin.url_for(my_videos))
        folder.add_item(label=_(_.MY_CREATORS, _bold=True), path=plugin.url_for(my_creators))
        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))

        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True),  path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)

    return folder


@plugin.route()
def featured(id=None, **kwargs):
    folder = plugin.Folder(_.FEATURED)

    for row in api.featured()['rails']:
        if id is None and row.get('collection'):
            folder.add_item(
                label = row['title'],
                path = plugin.url_for(featured, id=row['id']),
            )

        elif id == row['id']:
            data = api.url(row['collection'])
            items = _parse_rows(data)
            folder.add_items(items)

    return folder


@plugin.route()
@plugin.pagination()
def videos(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.VIDEOS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(videos, category='', title=_.EVERYTHING),
        )

        for row in api.categories():
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(videos, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.videos(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def podcast_creators(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.PODCASTS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(podcast_creators, category='', title=_.EVERYTHING),
        )

        for row in api.podcast_categories():
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(podcast_creators, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.podcast_creators(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def creators(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.CREATORS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(creators, category='', title=_.EVERYTHING),
        )

        for row in api.categories():
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(creators, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.creators(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


def _parse_rows(rows, creator_page=False, following=False):
    items = []
    for row in rows:
        if row['type'] == 'video_channel':
            item = _parse_channel(row, following=following)
        elif row['type'] == 'podcast_channel':
            item = _parse_podcast_channel(row)
        elif row['type'] == 'video_episode':
            item = _parse_episode(row, creator_page=creator_page, following=following)
        elif row['type'] == 'podcast_episode':
            item = _parse_podcast_episode(row)
        elif row['type'] == 'class':
            item = _parse_class(row)
        else:
            continue
        items.append(item)
    return items


def _parse_channel(row, following=False):
    thumb = None
    fanart = None

    if 'images' in row:
        thumb = row['images']['avatar']['src'] + '?format=jpeg&width=512'
        fanart = row['images']['featured']['src'] + '?format=jpeg&width=1920'
    elif 'assets'in row:
        thumb = row['assets']['avatar']['512']['original']
        fanart = row['assets']['banner']['1920']['original']

    item = plugin.Item(
        label = row['title'],
        info = {'plot': row.get('description')},
        art = {'thumb': thumb, 'fanart': fanart},
        path = plugin.url_for(creator_videos, slug=row['slug']),
    )

    if following:
        item.context.append((_(_.UNFOLLOW_CREATOR, creator=row['title']), 'RunPlugin({})'.format(plugin.url_for(unfollow_creator, slug=row['slug'], title=row['title'], icon=thumb))))
    else:
        item.context.append((_(_.FOLLOW_CREATOR, creator=row['title']), 'RunPlugin({})'.format(plugin.url_for(follow_creator, slug=row['slug'], title=row['title'], icon=thumb))))

    return item


def _parse_podcast_channel(row):
    item = plugin.Item(
        label = row['title'],
        info = {'plot': _(_.POCAST_CREATOR, creator=row['creator'], description=row.get('description', '')).strip()},
        art = {'thumb': row['assets']['regular']},
        path = plugin.url_for(podcasts, slug=row['slug']),
    )
    return item


def _parse_episode(row, creator_page=False, following=False):
    published = arrow.get(row['published_at'])
    channel_avatar = None
    thumb = None

    if 'images' in row:
        thumb = row['images']['thumbnail']['src'] + '?format=jpeg&width=512'
        channel_avatar = row['images']['channel_avatar']['src'] + '?format=jpeg&width=400'
    elif 'assets'in row:
        channel_avatar = row['assets']['channel_avatar']['512']['original']
        try:
            thumb = row['assets']['thumbnail']['720']['original']
        except:
            thumb = row['assets']['thumbnail']['720']

    item = plugin.Item(
        label = row['title'],
        info = {
            'duration': row['duration'],
            'plot': _(_.VIDE_PLOT, creator=row['channel_title'], published=published.humanize(), description=row['short_description'] or row['description']).strip(),
            #'season': row.get('season'),
            #'episode': row.get('episode'),
            'tvshowtitle': row['channel_title'],
            'aired': str(published),
            'mediatype': 'episode',
        },
        art = {'thumb': thumb, 'fanart': channel_avatar},
        path = plugin.url_for(play, slug=row['slug']),
        playable = True,
    )

    if following:
        item.context.append((_(_.UNFOLLOW_CREATOR, creator=row['channel_title']), 'RunPlugin({})'.format(plugin.url_for(unfollow_creator, slug=row['channel_slug'], title=row['channel_title'], icon=channel_avatar))))
    else:
        item.context.append((_(_.FOLLOW_CREATOR, creator=row['channel_title']), 'RunPlugin({})'.format(plugin.url_for(follow_creator, slug=row['channel_slug'], title=row['channel_title'], icon=channel_avatar))))

    if not creator_page:
        item.context.append((_(_.CREATOR_CHANNEL, creator=row['channel_title']), 'Container.Update({})'.format(plugin.url_for(creator_videos, slug=row['channel_slug'], title=row['channel_title'], icon=channel_avatar))))

    return item

def _parse_podcast_episode(row):
    published = arrow.get(row['published_at'])

    item = plugin.Item(
        label = row['title'],
        info = {
            'duration': row['duration'],
            'plot': row['description'].strip(),
            'aired': str(published),
        },
        art = {'thumb': row['assets']['regular']},
        path = plugin.url_for(play_podcast, channel=row['channel_slug'], episode=row['slug']),
        playable = True,
    )
    return item


def _parse_class(row):
    thumb = row['images']['featured']['src'] + '?format=jpeg&width=512'
    fanart = row['images']['banner']['src'] + '?format=jpeg&width=1920'
    item = plugin.Item(
        label = row['title'],
        info = {'plot': row.get('description')},
        art = {'thumb': thumb, 'fanart': fanart},
        path = plugin.url_for(lessons, slug=row['id']),
    )
    return item


@plugin.route()
@plugin.pagination()
def my_videos(page=1, **kwargs):
    data = api.my_videos(page=page)

    folder = plugin.Folder(_.MY_VIDEOS)
    items = _parse_rows(data['results'], following=True)
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def my_creators(page=1, **kwargs):
    data = api.my_creators(page=page)

    folder = plugin.Folder(_.MY_CREATORS)
    items = _parse_rows(data['results'], following=True)
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def podcasts(slug, page=1, **kwargs):
    data = api.podcasts(slug, page=page)
    folder = plugin.Folder(data['details']['title'])
    items = _parse_rows(data['episodes']['results'])
    folder.add_items(items)
    return folder, data['episodes']['next']


@plugin.route()
@plugin.pagination()
def lessons(slug, page=1, **kwargs):
    class_info = api.class_info(slug)
    folder = plugin.Folder(class_info['title'])

    data = api.lessons(slug, page=page)
    for row in data['results']:
        item = plugin.Item(
            label = row['title'],
            info = {
                'duration': row['duration'],
                'episode': row.get('order'),
                'season': 1,
                'mediatype': 'episode',
                'tvshowtitle': class_info['title'],
                'plot': class_info.get('description'),
            },
            art = {'thumb': row['assets']['thumbnail']['720']['original']},
            path = plugin.url_for(play_lesson, id=row['id']),
            playable = True,
        )
        folder.add_items([item])

    return folder, data['next']


@plugin.route()
@plugin.pagination()
def creator_videos(slug, page=1, **kwargs):
    data = api.creator(slug, page=page)

    folder = plugin.Folder(data['details']['title'], fanart=data['details']['assets']['avatar']['512']['original'])
    items = _parse_rows(data['episodes']['results'], creator_page=True)
    folder.add_items(items)
    return folder, data['episodes']['next']


@plugin.route()
def follow_creator(slug, title, icon, **kwargs):
    api.follow_creator(slug)
    gui.notification(_(_.FOLLOWED_CREATOR, creator=title), icon=icon)


@plugin.route()
def unfollow_creator(slug, title, icon, **kwargs):
    api.unfollow_creator(slug)
    gui.notification(_(_.UNFOLLOWED_CREATOR, creator=title), icon=icon)
    gui.refresh()


@plugin.route()
@plugin.search()
def search(query, page, **kwargs):
    rows = []
    if page == 1:
        rows.extend(api.search_creators(query=query)['results'])
        rows.extend(api.search_podcasts(query=query)['results'])

    data = api.search_videos(query=query, page=page)
    rows.extend(data['results'])
    items = _parse_rows(rows)
    return items, data['next']


@plugin.route()
def login(**kwargs):
    username = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not username:
        return

    userdata.set('username', username)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login(username, password)
    gui.refresh()


@plugin.route()
@plugin.login_required()
def play(slug, **kwargs):
    data = api.play(slug)

    item = plugin.Item(
        path = data['manifest'],
        inputstream = inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs, force=True),
    )
    ## subs seem to be included in manifest now
    # for idx, row in enumerate(data.get('subtitles', [])):
    #     item.subtitles.append([row['url'], row['language_code']])
    return item


@plugin.route()
@plugin.login_required()
def play_podcast(channel, episode, **kwargs):
    data = api.play_podcast(channel, episode)

    item = plugin.Item(
        label = data['title'],
        info = {
            'plot': data['description'],
        },
        art = {'thumb': data['assets']['regular']},
        path = data['episode_url'],
    )

    return item


@plugin.route()
@plugin.login_required()
def play_lesson(id, **kwargs):
    url = api.play_lesson(id)
    item = plugin.Item(
        path = url,
        inputstream = inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs, force=True),
    )
    return item


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()
