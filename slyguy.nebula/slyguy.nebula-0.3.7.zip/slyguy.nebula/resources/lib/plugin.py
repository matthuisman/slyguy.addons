import arrow
from slyguy import plugin, gui, userdata, signals, inputstream
from slyguy.constants import ROUTE_LIVE_TAG

from .api import API
from .language import _
from .settings import settings

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.FEATURED, _bold=True), path=plugin.url_for(featured))
        folder.add_item(label=_(_.LIBRARY, _bold=True), path=plugin.url_for(library))
        folder.add_item(label=_(_.EXPLORE, _bold=True), path=plugin.url_for(explore))
        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))

        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True),  path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)

    return folder


@plugin.route()
def featured(id=None, **kwargs):
    folder = plugin.Folder(_.FEATURED)

    for row in api.featured()['rails']:
        if id is None and row.get('collection'):
            folder.add_item(
                label = row['title'],
                path = plugin.url_for(featured, id=row['id']),
            )

        elif id == row['id']:
            data = api.url(row['collection'])
            items = _parse_rows(data)
            folder.add_items(items)

    return folder


@plugin.route()
def library(**kwargs):
    folder = plugin.Folder(_.LIBRARY)
    folder.add_item(label=_(_.LATEST_VIDEOS, _bold=True), path=plugin.url_for(latest_videos))
    folder.add_item(label=_(_.MY_CREATORS, _bold=True), path=plugin.url_for(my_creators))
    folder.add_item(label=_(_.WATCH_LATER, _bold=True), path=plugin.url_for(watch_later))
    folder.add_item(label=_(_.WATCH_HISTORY, _bold=True), path=plugin.url_for(watch_history))
    return folder


@plugin.route()
def explore(**kwargs):
    folder = plugin.Folder(_.EXPLORE)
    folder.add_item(label=_(_.VIDEOS, _bold=True), path=plugin.url_for(videos))
    folder.add_item(label=_(_.CREATORS, _bold=True), path=plugin.url_for(creators))
    folder.add_item(label=_(_.PODCASTS, _bold=True), path=plugin.url_for(podcast_creators))
    folder.add_item(label=_(_.EPISODES, _bold=True), path=plugin.url_for(podcast_episodes))
    return folder


@plugin.route()
@plugin.pagination()
def creators(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.CREATORS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(creators, category='', title=_.EVERYTHING),
        )

        for row in api.categories(content_type='video_channel'):
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(creators, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.creators(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def videos(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.VIDEOS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(videos, category='', title=_.EVERYTHING),
        )

        for row in api.categories(content_type='video_channel'):
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(videos, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.videos(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def podcast_creators(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.PODCASTS)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(podcast_creators, category='', title=_.EVERYTHING),
        )

        for row in api.categories(content_type='podcast_channel'):
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(podcast_creators, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.podcast_creators(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def podcast_episodes(category=None, title=None, page=1, **kwargs):
    if category is None:
        folder = plugin.Folder(_.EPISODES)

        folder.add_item(
            label = _.EVERYTHING,
            path = plugin.url_for(podcast_episodes, category='', title=_.EVERYTHING),
        )

        for row in api.categories(content_type='podcast_channel'):
            folder.add_item(
                label = row['title'],
                art = {'thumb': row['assets']['avatar-big-light']},
                path = plugin.url_for(podcast_episodes, category=row['slug'], title=row['title']),
            )

        return folder, False

    folder = plugin.Folder(title)
    data = api.podcast_episodes(category=category, page=page)
    items = _parse_rows(data['results'])
    folder.add_items(items)
    return folder, data['next']


def _parse_rows(rows, creator_page=False, following=False):
    items = []
    for row in rows:
        if row['type'] == 'video_channel':
            item = _parse_channel(row, following=following)
        elif row['type'] == 'podcast_channel':
            item = _parse_podcast_channel(row)
        elif row['type'] == 'video_episode':
            item = _parse_episode(row, creator_page=creator_page, following=following)
        elif row['type'] == 'podcast_episode':
            item = _parse_podcast_episode(row)
        elif row['type'] == 'class':
            item = _parse_class(row)
        else:
            continue
        items.append(item)
    return items


def _parse_channel(row, following=False):
    thumb = None
    fanart = None

    if 'images' in row:
        thumb = row['images']['avatar']['src'] + '?format=jpeg&width=512'
        fanart = row['images']['featured']['src'] + '?format=jpeg&width=1920'
    elif 'assets'in row:
        thumb = row['assets']['avatar']['512']['original']
        fanart = row['assets']['banner']['1920']['original']

    item = plugin.Item(
        label = row['title'],
        info = {'plot': row.get('description')},
        art = {'thumb': thumb, 'fanart': fanart},
        path = plugin.url_for(creator_videos, id=row['id']),
    )

    if following:
        item.context.append((_(_.UNFOLLOW_CREATOR, creator=row['title']), 'RunPlugin({})'.format(plugin.url_for(unfollow_creator, slug=row['slug'], title=row['title'], icon=thumb))))
    else:
        item.context.append((_(_.FOLLOW_CREATOR, creator=row['title']), 'RunPlugin({})'.format(plugin.url_for(follow_creator, slug=row['slug'], title=row['title'], icon=thumb))))

    return item


def _parse_podcast_channel(row):
    item = plugin.Item(
        label = row['title'],
        info = {'plot': _(_.POCAST_CREATOR, creator=row['creator'], description=row.get('description', '')).strip()},
        art = {'thumb': row['assets']['regular']},
        path = plugin.url_for(podcasts, id=row['id']),
    )
    return item


def _parse_episode(row, creator_page=False, following=False):
    published = arrow.get(row['published_at'])
    channel_avatar = None
    thumb = None

    if 'images' in row:
        thumb = row['images']['thumbnail']['src'] + '?format=jpeg&width=512'
        channel_avatar = row['images']['channel_avatar']['src'] + '?format=jpeg&width=400'
    elif 'assets'in row:
        channel_avatar = row['assets']['channel_avatar']['512']['original']
        try:
            thumb = row['assets']['thumbnail']['720']['original']
        except:
            thumb = row['assets']['thumbnail']['720']

    item = plugin.Item(
        label = row['title'],
        info = {
            'duration': row['duration'],
            'plot': _(_.VIDE_PLOT, creator=row['channel_title'], published=published.humanize(), description=row['short_description'] or row['description']).strip(),
            #'season': row.get('season'),
            #'episode': row.get('episode'),
            'tvshowtitle': row['channel_title'],
            'aired': str(published),
            'mediatype': 'episode',
        },
        art = {'thumb': thumb, 'fanart': None if creator_page else channel_avatar},
        path = plugin.url_for(play, id=row['id']),
        playable = True,
    )

    if following:
        item.context.append((_(_.UNFOLLOW_CREATOR, creator=row['channel_title']), 'RunPlugin({})'.format(plugin.url_for(unfollow_creator, slug=row['channel_slug'], title=row['channel_title'], icon=channel_avatar))))
    else:
        item.context.append((_(_.FOLLOW_CREATOR, creator=row['channel_title']), 'RunPlugin({})'.format(plugin.url_for(follow_creator, slug=row['channel_slug'], title=row['channel_title'], icon=channel_avatar))))

    if not creator_page:
        item.context.append((_(_.CREATOR_CHANNEL, creator=row['channel_title']), 'Container.Update({})'.format(plugin.url_for(creator_videos, id=row['id']))))

    return item


def _parse_podcast_episode(row):
    published = arrow.get(row['published_at'])

    item = plugin.Item(
        label = row['title'],
        info = {
            'duration': row['duration'],
            'plot': row['description'].strip().replace('\n\n', '\n'),
            'aired': str(published),
        },
        art = {'thumb': row['assets']['regular']},
        path = plugin.url_for(play_podcast, channel=row['channel_slug'], episode=row['slug']),
        playable = True,
    )
    return item


def _parse_class(row):
    thumb = row['images']['featured']['src'] + '?format=jpeg&width=512'
    fanart = row['images']['banner']['src'] + '?format=jpeg&width=1920'
    item = plugin.Item(
        label = row['title'],
        info = {'plot': row.get('description')},
        art = {'thumb': thumb, 'fanart': fanart},
        path = plugin.url_for(lessons, id=row['id']),
    )
    return item


@plugin.route()
@plugin.pagination()
def watch_later(page=1, **kwargs):
    data = api.watch_later(page=page)

    folder = plugin.Folder(_.WATCH_LATER)
    items = _parse_rows(data['results'], following=False)
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def latest_videos(page=1, **kwargs):
    data = api.latest_videos(page=page)

    folder = plugin.Folder(_.LATEST_VIDEOS)
    items = _parse_rows(data['results'], following=True)
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def my_creators(page=1, **kwargs):
    data = api.my_creators(page=page)

    folder = plugin.Folder(_.MY_CREATORS)
    items = _parse_rows(data['results'], following=True)
    folder.add_items(items)
    return folder, data['next']

@plugin.route()
@plugin.pagination()
def watch_history(page=1, **kwargs):
    data = api.watch_history(page=page)

    folder = plugin.Folder(_.WATCH_HISTORY)
    items = _parse_rows(data['results'], following=False)
    folder.add_items(items)
    return folder, data['next']


@plugin.route()
@plugin.pagination()
def podcasts(id, page=1, **kwargs):
    details = api.podcast_creator(id)
    episodes = api.podcast_creator_episodes(id, page=page)

    folder = plugin.Folder(details['title'])
    items = _parse_rows(episodes['results'])
    folder.add_items(items)
    return folder, episodes['next']


@plugin.route()
@plugin.pagination()
def lessons(id, page=1, **kwargs):
    class_info = api.class_info(id)
    folder = plugin.Folder(class_info['title'])

    data = api.lessons(id, page=page)
    for row in data['results']:
        item = plugin.Item(
            label = row['title'],
            info = {
                'duration': row['duration'],
                'episode': row.get('order'),
                'season': 1,
                'mediatype': 'episode',
                'tvshowtitle': class_info['title'],
                'plot': class_info.get('description'),
            },
            art = {'thumb': row['assets']['thumbnail']['720']['original']},
            path = plugin.url_for(play, id=row['id']),
            playable = True,
        )
        folder.add_items([item])

    return folder, data['next']


@plugin.route()
@plugin.pagination()
def creator_videos(id, page=1, **kwargs):
    details = api.creator(id)
    videos = api.creator_videos(id, page=page)

    if 'images' in details:
        thumb = details['images']['avatar']['src'] + '?format=jpeg&width=512'
        fanart = details['images']['featured']['src'] + '?format=jpeg&width=1920'
    elif 'assets' in details:
        thumb = details['assets']['avatar']['512']['original']
        fanart = details['assets']['banner']['1920']['original']
    else:
        fanart = None

    folder = plugin.Folder(details['title'], thumb=thumb, fanart=fanart)
    items = _parse_rows(videos['results'], creator_page=True)
    folder.add_items(items)
    return folder, videos['next']


@plugin.route()
def follow_creator(slug, title, icon, **kwargs):
    api.follow_creator(slug)
    gui.notification(_(_.FOLLOWED_CREATOR, creator=title), icon=icon)


@plugin.route()
def unfollow_creator(slug, title, icon, **kwargs):
    api.unfollow_creator(slug)
    gui.notification(_(_.UNFOLLOWED_CREATOR, creator=title), icon=icon)
    gui.refresh()


@plugin.route()
@plugin.search()
def search(query, page, **kwargs):
    rows, next = api.search(query, page=page)
    items = _parse_rows(rows)
    return items, next


@plugin.route()
def login(**kwargs):
    username = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not username:
        return

    userdata.set('username', username)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login(username, password)
    gui.refresh()


@plugin.route()
@plugin.login_required()
def play(id, **kwargs):
    if id.startswith('video_episode'):
        content_type = 'video_episodes'
    elif id.startswith('lesson'):
        content_type = 'lessons'
    else:
        raise Exception("Could not obtain content_type from id: {}".format(id))

    url = api.play(content_type, id)
    item = plugin.Item(
        path = url,
        inputstream = inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs, force=True),
    )
    return item


@plugin.route()
@plugin.login_required()
def play_podcast(channel, episode, **kwargs):
    data = api.play_podcast(channel, episode)

    item = plugin.Item(
        label = data['title'],
        info = {
            'plot': data['description'],
        },
        art = {'thumb': data['assets']['regular']},
        path = data['episode_url'],
    )

    return item


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()
