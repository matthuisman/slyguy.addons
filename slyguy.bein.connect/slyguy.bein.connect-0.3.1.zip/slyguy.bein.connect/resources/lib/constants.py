HEADERS = {
    'user-agent': 'okhttp/3.12.1',
}

APP_DATA_URL = 'https://d3ruzby390gxsc.cloudfront.net/init/bein_connect.json'
SECRET_KEY = '2H6kATruFruW&&e5_u4u'
REGION = 'mena'
PLAYER_NAME = 'androiddashapp'
APP_VERSION_URL = 'https://i.mjh.nz/.apk/mena.version'

LOGIN_CONNECT = 0
LOGIN_SATELLITE = 1
