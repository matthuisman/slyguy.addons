from slyguy.settings import CommonSettings


DATA_URL = 'https://i.mjh.nz/nz/radio.json.gz'


class Settings(CommonSettings):
    pass


settings = Settings()
