from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    POLL_TIME = 30000


_ = Language()
