from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    MY_LIBRARY = 30003


_ = Language()
