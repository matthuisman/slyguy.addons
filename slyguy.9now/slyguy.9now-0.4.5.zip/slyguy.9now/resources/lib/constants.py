HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}

AUTH_URL = 'https://login.nine.com.au/api/device{}'
LIVESTREAM_URL = 'https://api.9now.com.au/ctv/livestreams'
API_URL = 'https://tv-api.9now.com.au/v2/pages{}'
ACTIVATE_URL = '9now.com.au/activate'

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM17uNt4BA9TibECIvv8vBVypgHHIgThenKM55b88yzwUAmQ5hHbEfpsaQCimxMfcJglqzWqPTc21Mbnt4H-49t8_htP91BPml8bDw7AjWou9m_avlno4V7DBRsuLWdpLOoUMziK'
BRIGHTCOVE_ACCOUNT = '4460760524001'
