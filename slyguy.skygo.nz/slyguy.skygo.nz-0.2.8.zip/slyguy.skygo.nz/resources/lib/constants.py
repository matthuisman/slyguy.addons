HEADERS = {
    'User-Agent': 'okhttp/4.9.3',
}

CLIENT_ID = 'kOBPdd3dPUvJJz96QdaJdrqZZD7kWmI4'
GRAPH_URL = 'https://api.skyone.co.nz/exp/graph'
EPG_URL = 'https://i.mjh.nz/SkyGo/epg.xml.gz'
