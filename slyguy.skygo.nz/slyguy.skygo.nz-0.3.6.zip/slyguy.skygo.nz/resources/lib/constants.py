HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 9; Mi 5 Build/RQ3A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/131.0.6778.135 Mobile Safari/537.36',
    'x-product-id': 'skyGo',
    'x-sky-app-id': 'skyGo-Android',
}

CLIENT_ID = 'kOBPdd3dPUvJJz96QdaJdrqZZD7kWmI4'
GRAPH_URL = 'https://api.skyone.co.nz/exp/graph'
EPG_URL = 'https://i.mjh.nz/SkyGo/epg.xml.gz'
