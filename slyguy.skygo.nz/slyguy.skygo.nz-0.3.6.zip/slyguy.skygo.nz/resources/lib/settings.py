from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool

from .language import _


class Settings(CommonSettings):
    SUBSCRIBED_ONLY = Bool('subscribed_only', _.SUBSCRIBED_ONLY, default=False)
    FLATTEN_SINGLE_SEASON = Bool('flatten_single_season', _.FLATTEN_SEASONS, default=True)


settings = Settings()
