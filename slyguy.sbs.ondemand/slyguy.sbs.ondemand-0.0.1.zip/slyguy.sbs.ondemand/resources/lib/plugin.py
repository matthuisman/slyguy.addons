import codecs

import arrow
from slyguy import plugin, gui, signals, monitor, userdata, inputstream
from slyguy.constants import ROUTE_LIVE_TAG

from .api import API
from .constants import IMAGE_URL
from .language import _
from .settings import settings


api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    options = [
        [_.DEVICE_CODE, _device_code],
        [_.EMAIL_PASSWORD, _email_password],
    ]

    index = gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    gui.refresh()


def _device_code():
    data = api.device_code()
    device_code = data['deviceCode']
    user_code = data['userCode']
    interval = data['interval']
    expires_in = data['expiresIn']
    verify_url = 'https://' + data['verifyURI']
    qr_url = data['qrCodeURI']

    with gui.progress_qr(qr_url, _(_.DEVICE_LINK_STEPS, code=user_code, url=verify_url), heading=_.DEVICE_CODE) as progress:
        for i in range(expires_in):
            if progress.iscanceled() or monitor.waitForAbort(1):
                return

            progress.update(int((i / float(expires_in)) * 100))
            if i % interval == 0 and api.device_login(device_code):
                return True


def _email_password():
    username = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not username:
        return

    userdata.set('username', username)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login(username, password)
    return True


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    now = arrow.now()

    for item in api.live_channels():
        ch = item['channel']

        plot = u''
        for entry in item.get('entries', []):
            prog = entry['program']
            start = arrow.get(entry['availability']['start'])
            if now < start or now < arrow.get(entry['availability']['end']):
                title = prog.get('seriesTitle') or prog['title']
                plot += u'[{}] {}\n'.format(start.to('local').format('h:mma'), title)

        thumb = _image(ch['images'], 'CHANNEL_LOGO_IOS_1', 'CHANNEL_LOGO_WEB_1')

        folder.add_item(
            label=ch['title'],
            info={'plot': plot.strip() or None},
            art={'thumb': thumb},
            path=plugin.url_for(play, media_id=ch['mpxMediaID'], _is_live=True),
            playable=True,
        )

    return folder


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for item in api.live_channels():
            ch = item['channel']
            thumb = _image(ch['images'], 'CHANNEL_LOGO_IOS_1', 'CHANNEL_LOGO_WEB_1') or ''
            f.write(u'\n#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}",{name}\n{url}'.format(
                tvg_id='mjh-sbs-{}'.format(ch['ibmsChannelCode'].lower()),
                logo=thumb,
                name=ch['title'],
                url=plugin.url_for(play, media_id=ch['mpxMediaID'], _is_live=True),
            ))



@plugin.route()
@plugin.login_required()
def play(media_id, **kwargs):
    url = api.play(media_id)
    return plugin.Item(
        path=url,
        inputstream=inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs),
    )


def _image(images, *categories):
    for category in categories:
        for img in images:
            if img.get('category') == category:
                return IMAGE_URL + '/' + img['id']
    return None


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()
