from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool

from .language import _


class Settings(CommonSettings):
    PREFER_DAI_STREAMS = Bool(_.PREFER_DAI_STREAMS, default=True)


settings = Settings()
