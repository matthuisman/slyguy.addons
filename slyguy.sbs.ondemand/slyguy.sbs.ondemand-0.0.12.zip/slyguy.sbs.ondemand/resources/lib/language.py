from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    TV_SHOWS = 30000
    NEWS = 30001
    SPORT = 30002
    EXPIRES = 30003
    LIVE = 30004
    LIVE_IN = 30005
    PREFER_DAI_STREAMS = 30006


_ = Language()
