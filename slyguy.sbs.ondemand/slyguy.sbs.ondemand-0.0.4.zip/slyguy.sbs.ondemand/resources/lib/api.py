import time
import uuid

from slyguy import userdata, keep_alive
from slyguy.util import jwt_data
from slyguy.session import Session
from slyguy.exceptions import Error

from .constants import HEADERS, AUTH_URL, CATALOGUE_URL, SEARCH_URL, EPG_URL, PLAYBACK_URL, USER_ACTIVITY_URL, DEVICE_NAME, DEVICE_CLASS
from .language import _


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(HEADERS)
        self._set_authentication()
        keep_alive.register(self._refresh_token, hours=12, enable=self.logged_in)

    def _set_authentication(self):
        access_token = userdata.get('access_token')
        if not access_token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(access_token)})
        self.logged_in = True

    def device_code(self):
        payload = {'deviceName': DEVICE_NAME}
        return self._session.post(AUTH_URL + '/device/link', json=payload).json()

    def device_login(self, device_code):
        payload = {
            'deviceCode': device_code,
            'refreshTokenInBody': True,
        }
        data = self._session.post(AUTH_URL + '/device/poll', json=payload).json()
        if data.get('accessToken'):
            return self._parse_auth(data)
        return False

    def login(self, username, password):
        self.logout()

        payload = {
            'deviceName': DEVICE_NAME,
            'email': username,
            'password': password,
            'refreshTokenInBody': True,
        }

        data = self._session.post(AUTH_URL + '/login', json=payload).json()
        if not self._parse_auth(data):
            raise APIError(_.LOGIN_ERROR)

    def _parse_auth(self, data):
        if not data.get('accessToken'):
            return False

        access_token = data['accessToken']
        jwt = jwt_data(access_token)

        userdata.set('access_token', access_token)
        userdata.set('token_expires', jwt['exp'] - 30)
        if data.get('refreshToken'):
            userdata.set('refresh_token', data['refreshToken'])

        self._set_authentication()
        return True

    def _refresh_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('token_expires', 0) > time.time()):
            return

        refresh_token = userdata.get('refresh_token')
        if not refresh_token:
            self.logout()
            return

        payload = {
            'deviceName': DEVICE_NAME,
            'refreshToken': refresh_token,
            'refreshTokenInBody': True,
        }

        try:
            data = self._session.post(AUTH_URL + '/refresh', json=payload).json()
            if not self._parse_auth(data):
                self.logout()
        except Exception:
            self.logout()

    def page(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/pages/{}'.format(slug)).json()

    def collection(self, slug, cursor=None):
        self._refresh_token()
        params = {}
        if cursor:
            params['cursor'] = cursor
        return self._session.get(CATALOGUE_URL + '/collections/{}'.format(slug), params=params).json()

    def tv_series(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/tv-series/{}'.format(slug)).json()

    def movie(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/movies/{}'.format(slug)).json()

    def tv_program(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/tv-programs/{}'.format(slug)).json()

    def search(self, query, cursor=None):
        self._refresh_token()
        params = {'q': query, 'limit': 24}
        if cursor:
            params['cursor'] = cursor
        return self._session.get(SEARCH_URL + '/catalogue', params=params).json()

    def get_watchlist(self):
        self._refresh_token()
        data = self._session.get(CATALOGUE_URL + '/favourite').json()
        return data if isinstance(data, list) else []

    def add_watchlist(self, entity_id, entity_type):
        self._refresh_token()
        payload = [{'entityID': entity_id, 'entityType': entity_type.lower().replace('_', '-')}]
        self._session.post(USER_ACTIVITY_URL + '/favourite', json=payload)

    def remove_watchlist(self, entity_id):
        self._refresh_token()
        self._session.delete(USER_ACTIVITY_URL + '/favourite/{}'.format(entity_id))

    def live_channels(self):
        self._refresh_token()
        return self._session.get(EPG_URL + '/guides-v2', params={'limit': 0}).json()['items']

    def play(self, media_id):
        self._refresh_token()
        device_id = userdata.get('device_id')
        if not device_id:
            device_id = str(uuid.uuid4())
            userdata.set('device_id', device_id)

        payload = {
            'advertising': {
                'deviceID': device_id,
                'deviceTargetingOptOut': True,
                'sbsTargetingOptOut': True,
                'subtitle': 'en',
                'resume': False,
            },
            'deviceClass': DEVICE_CLASS,
            'streamOptions': {'audio': 'demuxed'},
        }

        data = self._session.post(PLAYBACK_URL + '/stream/{}'.format(media_id), json=payload).json()
        for provider in data.get('streamProviders', []):
            if provider['type'] == 'HLS':
                return provider['url'].replace('master_720.m3u8', 'master.m3u8')

        raise APIError('No HLS stream found')

    def logout(self):
        refresh_token = userdata.get('refresh_token')
        if refresh_token:
            try:
                payload = {'refreshToken': refresh_token, 'refreshTokenInBody': True}
                self._session.delete(AUTH_URL + '/refresh', json=payload)
            except Exception:
                pass

        userdata.delete('access_token')
        userdata.delete('refresh_token')
        userdata.delete('token_expires')
        self.new_session()
