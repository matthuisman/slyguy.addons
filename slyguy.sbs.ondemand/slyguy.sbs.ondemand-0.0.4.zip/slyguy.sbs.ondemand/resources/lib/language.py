from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    TV_SHOWS = 30000
    NEWS = 30001
    SPORT = 30002


_ = Language()
