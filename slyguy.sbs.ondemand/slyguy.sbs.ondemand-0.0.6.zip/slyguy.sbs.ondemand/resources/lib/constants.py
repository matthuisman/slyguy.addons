HEADERS = {
    'x-api-key': 'ce3f270a-31fb-486e-855e-4f608a62640e',
    'accept-language': 'en',
    'user-agent': 'okhttp/4.10.0',
}

AUTH_URL = 'https://auth.sbs.com.au'
CATALOGUE_URL = 'https://catalogue.pr.sbsod.com'
EPG_URL = 'https://tv-epg.pr.sbsod.com'
SEARCH_URL = 'https://content-search.pr.sbsod.com'
PLAYBACK_URL = 'https://playback.pr.sbsod.com'
IMAGE_URL = 'https://image.pr.sbsod.com'
DEVICE_NAME = 'NVIDIA SHIELD Android TV - SBS On Demand'
DEVICE_CLASS = 'androidtv'
USER_ACTIVITY_URL = 'https://user-activity.pr.sbsod.com'