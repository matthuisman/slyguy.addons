from resources.lib import gpio

gpio.service()
