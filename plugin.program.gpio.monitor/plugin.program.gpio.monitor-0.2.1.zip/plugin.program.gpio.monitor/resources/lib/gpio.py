import os
import sys
import subprocess
import shutil

from six import PY3
from kodi_six import xbmc

from slyguy import gui, database, dialog
from slyguy.constants import ADDON_PATH, ADDON_ID
from slyguy.session import Session
from slyguy.log import log
from slyguy.exceptions import Error
from slyguy.util import set_kodi_string, get_kodi_string, remove_file, get_system_arch, xz_extract

from .constants import *
from .language import _
from .models import Button


GPIO_SOURCES = {
    "Linuxarmv7-py2": "https://f.mjh.nz/rpi/_GPIO.arm-linux-gnueabihf.so.xz",
    "Linuxarm64-py2": "https://f.mjh.nz/rpi/_GPIO.aarch64-linux-gnu.so.xz",
    "Linuxarmv7-py3": "https://f.mjh.nz/rpi/_GPIO.cpython-37m-arm-linux-gnueabihf.so.xz",
    "Linuxarm64-py3": "https://f.mjh.nz/rpi/_GPIO.cpython-37m-aarch64-linux-gnu.so.xz",
}
SO_DST = os.path.join(ADDON_PATH, 'resources', 'lib', 'RPi', '_GPIO.so')

if os.path.exists('/storage/.kodi'):
    SYSTEM = 'libreelec'
elif os.path.exists('/home/osmc'):
    SYSTEM = 'osmc'
elif os.path.exists('/home/pi'):
    SYSTEM = 'raspbian'
elif os.path.exists('/home/xbian'):
    SYSTEM = 'xbian'
else:
    SYSTEM = 'mock'

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import gpiozero

INSTALLED = False
if SYSTEM == 'mock':
    from gpiozero.pins.mock import MockFactory as Factory
    gpiozero.Device.pin_factory = Factory()
    log.debug('System not supported. Using mock factory')
    INSTALLED = True
elif os.path.exists(SO_DST):
    try:
        from gpiozero.pins.rpigpio import RPiGPIOFactory as Factory
        gpiozero.Device.pin_factory = Factory()
        gpiozero.Device.pin_factory.pin(BCM_PINS[0]).state
        INSTALLED = True
    except Exception as e:
        log.exception(e)

def install():
    if SYSTEM != "mock":
        remove_file(SO_DST)

        system, arch = get_system_arch()
        key = "{}{}-py{}".format(system, arch, "3" if PY3 else "2")

        url = GPIO_SOURCES.get(key)
        if not url:
            gui.ok(_.SYSTEM_UNSUPPORTED)
            return

        with dialog.progress(_(_.IA_DOWNLOADING_FILE, url=url), percent=50):
            Session().chunked_dl(url, SO_DST)
        xz_extract(SO_DST)

    if SYSTEM == 'libreelec':
        install_libreelec()
    elif SYSTEM == 'raspbian':
        install_raspbian()
    elif SYSTEM == 'osmc':
        install_osmc()
        return True
    elif SYSTEM == 'xbian':
        install_xbian()
        return True
    elif SYSTEM == 'mock':
        gui.ok(_.SYSTEM_UNSUPPORTED)

def install_libreelec():
    return

def install_raspbian():
    return

def install_osmc():
    sudo_cmd = 'sudo su -c "{}"'
    install_debian(sudo_cmd, 'osmc')

def install_xbian():
    password = gui.input(_.XBIAN_PASSWORD, default='raspberry')
    sudo_cmd = 'echo "{}" | sudo -S su -c "{{}}"'.format(password)

    try:
        install_debian(sudo_cmd, 'xbian')
    except Exception as e:
        log.exception(e)
        raise Error(_.XBIAN_ERROR)

def install_debian(sudo_cmd, user):
    def cmd(cmd):
        return subprocess.check_output(sudo_cmd.format(cmd), shell=True).strip()

    src_path = os.path.join(ADDON_PATH, 'resources', 'files', '99-gpio.rules')
    dst_path = '/etc/udev/rules.d/99-{}.GPIO.rules'.format(ADDON_ID)
    cmd('groupadd -f -r gpio && adduser {0} gpio && adduser root gpio && rm -f "{2}" && cp "{1}" "{2}"'.format(user, src_path, dst_path))

def set_state(pin, state):
    if not INSTALLED:
        return

    log.debug('Set pin {} to {}'.format(pin, state))
    out_pin = gpiozero.Device.pin_factory.pin(int(pin))
    out_pin.output_with_state(int(state))

def callback(function):
    log.debug('Callback: {}'.format(function))

    for function in function.split(FUNCTION_DELIMETER):
        xbmc.executebuiltin(function.strip(), True)


def service():
    if not INSTALLED:
        return

    def setup_buttons():
        log.debug('Setting up buttons')

        try:
            database.connect()

            Button.update(status=Button.Status.INACTIVE, error=None).where(Button.enabled == True).execute()
            Button.update(status=Button.Status.DISABLED, error=None).where(Button.enabled == False).execute()
            btns = list(Button.select().where(Button.enabled == True))

            buttons = []
            for btn in btns:
                if not btn.has_callbacks():
                    continue

                try:
                    button = gpiozero.Button(btn.pin, pull_up=btn.pull_up,
                        bounce_time=btn.bounce_time or None, hold_time=btn.hold_time, hold_repeat=btn.hold_repeat)

                    if btn.when_pressed:
                        button.when_pressed = lambda function=btn.when_pressed: callback(function)

                    if btn.when_released:
                        button.when_released = lambda function=btn.when_released: callback(function)

                    if btn.when_held:
                        button.when_held = lambda function=btn.when_held: callback(function)
                except Exception as e:
                    log.exception(e)
                    btn.status = Button.Status.ERROR
                    btn.error  = e
                else:
                    btn.status = Button.Status.ACTIVE
                    buttons.append(button)

                btn.save()

            return buttons
        except Exception as e:
            log.debug(e)
            return []
        finally:
            database.close()

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        buttons = setup_buttons()

        set_kodi_string('_gpio_reload')
        while not monitor.abortRequested():
            if not monitor.waitForAbort(1) and get_kodi_string('_gpio_reload'):
                break

        for button in buttons:
            button.close()

    gpiozero.Device.pin_factory.close()
