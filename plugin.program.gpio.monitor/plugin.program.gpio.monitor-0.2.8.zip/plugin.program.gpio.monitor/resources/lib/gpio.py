import os
import sys
import subprocess

from kodi_six import xbmc

from slyguy import gui, database
from slyguy.constants import ADDON_PATH, ADDON_ID
from slyguy.log import log
from slyguy.exceptions import Error
from slyguy.util import set_kodi_string, get_kodi_string, get_addon

from .constants import *
from .language import _
from .models import Button


os.environ['LG_WD'] = '/tmp'


if os.path.exists('/storage/.kodi'):
    SYSTEM = 'libreelec'
    sys.path.insert(0, '/storage/.kodi/addons/virtual.rpi-tools/lib')
elif os.path.exists('/home/osmc'):
    SYSTEM = 'osmc'
elif os.path.exists('/home/pi'):
    SYSTEM = 'raspbian'
elif os.path.exists('/home/xbian'):
    SYSTEM = 'xbian'
else:
    SYSTEM = 'mock'

# user our gpiozero 2.0.1 version
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import gpiozero


def install():
    if SYSTEM == 'libreelec':
        install_libreelec()
    elif SYSTEM == 'raspbian':
        install_raspbian()
    elif SYSTEM == 'osmc':
        install_osmc()
    elif SYSTEM == 'xbian':
        install_xbian()
    else:
        gui.ok(_.SYSTEM_UNSUPPORTED)


def install_libreelec():
    get_addon('virtual.rpi-tools', required=True, install=True)


def install_raspbian():
    sudo_cmd = 'sudo su -c "{}"'
    try:
        subprocess.check_output(sudo_cmd.format("apt-get update && apt-get install python3-gpiozero -y"), shell=True).strip()
    except:
        subprocess.check_output(sudo_cmd.format("apt-get update && apt-get install python-gpiozero -y"), shell=True).strip()


def install_osmc():
    sudo_cmd = 'sudo su -c "{}"'
    try:
        subprocess.check_output(sudo_cmd.format("apt-get update && apt-get install python3-gpiozero -y"), shell=True).strip()
    except:
        subprocess.check_output(sudo_cmd.format("apt-get update && apt-get install python-gpiozero -y"), shell=True).strip()
    install_debian(sudo_cmd, 'osmc')


def install_xbian():
    password = gui.input(_.XBIAN_PASSWORD, default='raspberry')
    sudo_cmd = 'echo "{}" | sudo -S su -c "{{}}"'.format(password)

    try:
        try:
            subprocess.check_output(sudo_cmd.format("apt-get update && install python3-gpiozero -y"), shell=True).strip()
        except:
            subprocess.check_output(sudo_cmd.format("apt-get update && install python-gpiozero -y"), shell=True).strip()
        install_debian(sudo_cmd, 'xbian')
    except Exception as e:
        log.exception(e)
        raise Error(_.XBIAN_ERROR)


def install_debian(sudo_cmd, user):
    def cmd(cmd):
        return subprocess.check_output(sudo_cmd.format(cmd), shell=True).strip()

    src_path = os.path.join(ADDON_PATH, 'resources', 'files', '99-gpio.rules')
    dst_path = '/etc/udev/rules.d/99-{}.GPIO.rules'.format(ADDON_ID)
    cmd('groupadd -f -r gpio && adduser {0} gpio && adduser root gpio && rm -f "{2}" && cp "{1}" "{2}"'.format(user, src_path, dst_path))


def set_state(pin, state):
    log.debug('Set pin {} to {}'.format(pin, state))
    out_pin = gpiozero.Device.pin_factory.pin(int(pin))
    out_pin.output_with_state(int(state))


def callback(function):
    log.debug('Callback: {}'.format(function))

    for function in function.split(FUNCTION_DELIMETER):
        xbmc.executebuiltin(function.strip(), True)



def reset_buttons():
    try:
        database.connect()
        Button.update(status=Button.Status.INACTIVE, error=None).where(Button.enabled == True).execute()
        Button.update(status=Button.Status.DISABLED, error=None).where(Button.enabled == False).execute()
    finally:
        database.close()


def service():
    reset_buttons()

    if SYSTEM == 'mock':
        from gpiozero.pins.mock import MockFactory as Factory
        gpiozero.Device.pin_factory = Factory()
        log.debug('System not supported. Using mock factory')
    else:
        try:
            # can only do once, doing at import time has "busy"
            gpiozero.Device.ensure_pin_factory()
            gpiozero.Device.pin_factory.pin(BCM_PINS[0]).close()
        except Exception as e:
            log.exception(e)
            set_kodi_string('_service_installed', '')
            return

    set_kodi_string('_service_installed', '1')
    def setup_buttons():
        log.debug('Setting up buttons')

        try:
            reset_buttons()
            btns = list(Button.select().where(Button.enabled == True))

            buttons = []
            for btn in btns:
                if not btn.has_callbacks():
                    continue

                try:
                    button = gpiozero.Button(btn.pin, pull_up=btn.pull_up,
                        bounce_time=btn.bounce_time or None, hold_time=btn.hold_time, hold_repeat=btn.hold_repeat)

                    if btn.when_pressed:
                        button.when_pressed = lambda function=btn.when_pressed: callback(function)

                    if btn.when_released:
                        button.when_released = lambda function=btn.when_released: callback(function)

                    if btn.when_held:
                        button.when_held = lambda function=btn.when_held: callback(function)
                except Exception as e:
                    log.exception(e)
                    btn.status = Button.Status.ERROR
                    btn.error  = e
                else:
                    btn.status = Button.Status.ACTIVE
                    buttons.append(button)

                btn.save()

            return buttons
        except Exception as e:
            log.debug(e)
            return []
        finally:
            database.close()

    try:
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            buttons = setup_buttons()

            set_kodi_string('_gpio_reload')
            while not monitor.abortRequested():
                if not monitor.waitForAbort(1) and get_kodi_string('_gpio_reload'):
                    break

            for button in buttons:
                button.close()
    finally:
        gpiozero.Device.pin_factory.close()
