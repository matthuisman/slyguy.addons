import os
import sys
import subprocess
import zipfile

from six import PY3
from kodi_six import xbmc

from slyguy import gui, database, dialog
from slyguy.constants import ADDON_PATH, ADDON_PROFILE, ADDON_ID
from slyguy.session import Session
from slyguy.log import log
from slyguy.util import set_kodi_string, get_kodi_string, get_addon, remove_dir, get_system_arch, makedirs, remove_file

from .constants import *
from .language import _
from .models import Button


if os.path.exists('/storage/.kodi'):
    SYSTEM = 'libreelec'
elif os.path.exists('/home/osmc'):
    SYSTEM = 'osmc'
elif os.path.exists('/home/pi'):
    SYSTEM = 'raspbian'
elif os.path.exists('/home/xbian'):
    SYSTEM = 'xbian'
else:
    SYSTEM = 'mock'

os.environ['LG_WD'] = '/tmp'

LGPIO_SOURCES = {
    "Linuxarmv7-py3": "https://f.mjh.nz/rpi/lgpio-armv7-py3.zip",
    "Linuxarm64-py3": "https://f.mjh.nz/rpi/lgpio-arm64-py3.zip",
}
LGPIO_DST = os.path.join(ADDON_PROFILE, 'lgpio')

# user our gpiozero 2.0.1 version
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
sys.path.insert(0, LGPIO_DST)
import gpiozero


def install():
    if SYSTEM != "mock":
        remove_dir(LGPIO_DST)

        system, arch = get_system_arch()
        system = 'Linux'
        arch = 'arm64'
        key = "{}{}-py{}".format(system, arch, "3" if PY3 else "2")

        url = LGPIO_SOURCES.get(key)
        if not url:
            log.error("No LGPIO source for {}".format(key))
            gui.ok(_.SYSTEM_UNSUPPORTED)
            return

        makedirs(LGPIO_DST)
        dst = os.path.join(LGPIO_DST, os.path.basename(url))
        with dialog.progress(_(_.IA_DOWNLOADING_FILE, url=url), percent=50):
            Session().chunked_dl(url, dst)
        with zipfile.ZipFile(dst, "r") as z:
            z.extractall(LGPIO_DST)
        remove_file(dst)

    if SYSTEM == 'libreelec':
        return install_libreelec()
    elif SYSTEM == 'raspbian':
        return install_raspbian()
    elif SYSTEM == 'osmc':
        return install_osmc()
    elif SYSTEM == 'xbian':
        return install_xbian()
    else:
        gui.ok(_.SYSTEM_UNSUPPORTED)
        return False


def install_libreelec():
    return True


def install_raspbian():
    return True


def install_osmc():
    sudo_cmd = 'sudo su -c "{}"'
    _install_udev_rules(sudo_cmd, 'osmc')
    return True


def install_xbian():
    password = gui.input(_.XBIAN_PASSWORD, default='raspberry')
    sudo_cmd = 'echo "{}" | sudo -S su -c "{{}}"'.format(password)
    _install_udev_rules(sudo_cmd, 'xbian')
    return True


def _install_udev_rules(sudo_cmd, user):
    def cmd(cmd):
        return subprocess.check_output(sudo_cmd.format(cmd), shell=True).strip()

    src_path = os.path.join(ADDON_PATH, 'resources', 'files', '99-gpio.rules')
    dst_path = '/etc/udev/rules.d/99-{}.GPIO.rules'.format(ADDON_ID)
    cmd('groupadd -f -r gpio && adduser {0} gpio && adduser root gpio && rm -f "{2}" && cp "{1}" "{2}"'.format(user, src_path, dst_path))


def set_state(pin, state):
    log.debug('Set pin {} to {}'.format(pin, state))
    out_pin = gpiozero.Device.pin_factory.pin(int(pin))
    out_pin.output_with_state(int(state))


def callback(function):
    log.debug('Callback: {}'.format(function))

    for function in function.split(FUNCTION_DELIMETER):
        xbmc.executebuiltin(function.strip(), True)



def reset_buttons():
    try:
        database.connect()
        Button.update(status=Button.Status.INACTIVE, error=None).where(Button.enabled == True).execute()
        Button.update(status=Button.Status.DISABLED, error=None).where(Button.enabled == False).execute()
    finally:
        database.close()


def service():
    reset_buttons()

    if SYSTEM == 'mock':
        from gpiozero.pins.mock import MockFactory as Factory
        gpiozero.Device.pin_factory = Factory()
        log.debug('System not supported. Using mock factory')
    else:
        try:
            # can only do once, doing at import time has "busy"
            gpiozero.Device.ensure_pin_factory()
            gpiozero.Device.pin_factory.pin(BCM_PINS[0]).close()
        except Exception as e:
            log.exception(e)
            set_kodi_string('_service_installed', '')
            return

    set_kodi_string('_service_installed', '1')
    def setup_buttons():
        log.debug('Setting up buttons')

        try:
            reset_buttons()
            btns = list(Button.select().where(Button.enabled == True))

            buttons = []
            for btn in btns:
                if not btn.has_callbacks():
                    continue

                try:
                    button = gpiozero.Button(btn.pin, pull_up=btn.pull_up,
                        bounce_time=btn.bounce_time or None, hold_time=btn.hold_time, hold_repeat=btn.hold_repeat)

                    if btn.when_pressed:
                        button.when_pressed = lambda function=btn.when_pressed: callback(function)

                    if btn.when_released:
                        button.when_released = lambda function=btn.when_released: callback(function)

                    if btn.when_held:
                        button.when_held = lambda function=btn.when_held: callback(function)
                except Exception as e:
                    log.exception(e)
                    btn.status = Button.Status.ERROR
                    btn.error  = e
                else:
                    btn.status = Button.Status.ACTIVE
                    buttons.append(button)

                btn.save()

            return buttons
        except Exception as e:
            log.debug(e)
            return []
        finally:
            database.close()

    try:
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            buttons = setup_buttons()

            set_kodi_string('_gpio_reload')
            while not monitor.abortRequested():
                if not monitor.waitForAbort(1) and get_kodi_string('_gpio_reload'):
                    break

            for button in buttons:
                button.close()
    finally:
        gpiozero.Device.pin_factory.close()
