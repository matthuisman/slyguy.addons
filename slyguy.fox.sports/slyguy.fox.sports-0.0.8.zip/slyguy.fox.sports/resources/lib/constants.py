HEADERS = {
    'user-agent': 'foxsports-androidtv/3.42.1 (Linux;Android 9.0.0;SHIELD Android TV) ExoPlayerLib/2.12.1',
}

CONFIG_URL = 'https://config.foxdcg.com/foxsports/androidtv-native/3.42/info.json'
NETWORK_LOGO = 'https://config.foxdcg.com/shared/android-ctv/img/network/{network}.png'
