VIDEO_TESTS = [
    {
        'name': 'HLS',
        'type': 'std',
        'url': 'https://storage.googleapis.com/shaka-demo-assets/apple-advanced-stream-ts/master.m3u8',
    },
    {
        'name': 'InputStream Adaptive - HLS',
        'type': 'ia_hls',
        'url': 'https://storage.googleapis.com/shaka-demo-assets/apple-advanced-stream-ts/master.m3u8',
    },
    {
        'name': 'InputStream Adaptive - HLS with Widevine',
        'type': 'ia_widevine_hls',
        'url': 'https://storage.googleapis.com/shaka-demo-assets/angel-one-widevine-hls/hls.m3u8',
        'license_key': 'https://cwip-shaka-proxy.appspot.com/no_auth',
    },
    {
        'name': 'InputStream Adaptive - Dash',
        'type': 'ia_mpd',
        'url': 'https://dash.akamaized.net/dash264/TestCases/5a/nomor/1.mpd',
    },
    {
        'name': 'InputStream Adaptive - Dash with Widevine',
        'type': 'ia_widevine',
        'url': 'https://storage.googleapis.com/wvmedia/cbcs/h264/tears/tears_aes_cbcs.mpd',
        'license_key': 'https://proxy.uat.widevine.com/proxy?provider=widevine_test',
    },
]