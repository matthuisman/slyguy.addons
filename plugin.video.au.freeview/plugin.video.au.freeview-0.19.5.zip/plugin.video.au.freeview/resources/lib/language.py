from .constants import REGION_ALL
from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    REGION  =           30000,
    REGIONS = {
        'Sydney':       30001,
        'Melbourne':    30002,
        'Brisbane':     30003,
        'Perth':        30004,
        'Adelaide':     30005,
        'Darwin':       30006,
        'Hobart':       30007,
        'Canberra':     30008,
        REGION_ALL:     30018,
    }
    LIVE_TV =           30009
    USE_NEW =           30010
    SHOW_MINI_EPG =     30011
    SHOW_CHNOS    =     30012
    LIVE_CHNO     =     30013
    HIDE_FAST     =     30014

_ = Language()
