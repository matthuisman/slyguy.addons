HEADERS = {
    'x-api-key': 'eca673f3-11cb-4716-8c75-1d1bd024aee2',
    'realm': 'dce.skynz',
    'x-app-var': '5.0.1 (5117)',
    'user-agent': 'okhttp/4.9.2',
}

BUFFER_SECONDS = 21600 # 6hours
API_URL = 'https://dce-frontoffice.imggaming.com/api{}'
DEVICE_CODE_URL = 'https://www.skysportnow.co.nz/tv-login'
EPG_URL = 'https://i.mjh.nz/SkySportNow/epg.xml.gz'
SEARCH_URL = 'https://h99xldr8mj-dsn.algolia.net/1/indexes/prod-dce.skynz-livestreaming-events/query'
