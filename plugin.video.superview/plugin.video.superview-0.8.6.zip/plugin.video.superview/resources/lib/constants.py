HEADERS = {
    'User-Agent': 'okhttp/4.9.2',
}

API_KEY = 'AIzaSyD03FKEKThDFl99ffyYh1bX56VjeL9yr_c'
BRIGHTCOVE_ACCOUNT = '2178772919001'
BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM3Dyn1_vgnP05Nq8fiXYD4Pp9GKnFUihsFEkee8Hw6lMlVhBHyFj4Nuh6TjQG0cCBxx76_Rv4b-icR1VMzKV0DJNRMwwRw_hvsifuJblEHioBpWWcgVVxJQp1YzglvwNpMsRr3KP2YRPeGLfFobWOjpYGAx8XejU86a2SsFTiox1iCBsxo'
LIVE_ID = 6135549356001
