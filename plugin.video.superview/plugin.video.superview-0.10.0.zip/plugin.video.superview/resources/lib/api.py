import io
import re

import arrow

from kodi_six import xbmc
from slyguy import plugin, userdata, util
from slyguy.exceptions import Error
from slyguy.session import Session

from .constants import *


class APIError(Error):
    pass


def _names_match(label, *values):
    label = (label or '').lower()

    return bool(label) and any(label in (value or '').lower() for value in values)


class API(object):
    def new_session(self):
        self._session = Session(HEADERS)
        self._events = None
        self._landing_page = None
        self._live_event_row = None
        self._season_events = {}
        self.logged_in = userdata.get('access_token', None) is not None

    def login(self, username, password):
        payload = {
            'returnSecureToken': True,
            'email': username,
            'password': password,
            'clientType': 'CLIENT_TYPE_WEB',
        }

        data = self._session.post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword', params={'key': API_KEY}, json=payload).json()
        if 'error' in data:
            raise APIError(data['error']['message'])

        userdata.set('access_token', data['idToken'])
        self.new_session()

    def events(self):
        if self._events is None:
            now = arrow.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
            data = self._contentful(CONTENTFUL_QUERY, {'now': now})

            self._events = []
            seen = set()
            for row in data['superviewVideosLandingPageCollection']['items']:
                if self._landing_page is None:
                    self._landing_page = {
                        'video': row.get('brightcoveVideo'),
                        'starting_time': row.get('startingTime'),
                    }

                for section in row['brightcovePlaylistSectionsCollection']['items']:
                    playlist_id = section.get('brightcovePlaylist')
                    if not playlist_id or playlist_id in seen:
                        continue

                    seen.add(playlist_id)
                    name = re.sub(r'\s*-\s*superview$', '', section['title'].strip(), flags=re.IGNORECASE)
                    year = re.search(r'20\d{2}', name)

                    self._events.append({
                        'id': playlist_id,
                        'name': name,
                        'year': int(year.group(0)) if year else None,
                    })

            self._live_event_row = (data['eventCollection']['items'] or [None])[0]

        return self._events

    def season_events(self, year):
        if year not in self._season_events:
            variables = {
                'from': '{}-01-01T00:00:00Z'.format(year),
                'to': '{}-12-31T23:59:59Z'.format(year),
            }
            data = self._contentful(CONTENTFUL_EVENTS_QUERY, variables)

            self._season_events[year] = [self._parse_event(x) for x in data['eventCollection']['items']]

        return self._season_events[year]

    def event_info(self, name, events=None):
        # "Gold Coast 2026" => the event whose title/slug contains "gold coast"
        year = re.search(r'20\d{2}', name or '')
        if not year:
            return None

        if events is None:
            events = self.season_events(int(year.group(0)))

        label = re.sub(r'\s*20\d{2}$', '', name)
        for event in events:
            if _names_match(label, event.get('name'), (event.get('slug') or '').replace('-', ' ')):
                return event

        return None

    def live(self):
        # Contentful names the event and points at the current live video; Brightcove serves the stream
        self.events()

        event = None
        if self._live_event_row:
            row = self._live_event_row
            entry_title = (row.get('liveFeed') or {}).get('entryTitle') or ''

            event = self._parse_event(row)
            event['id'] = self._match_event(row)
            event['session'] = entry_title.split(' - ')[-1] if entry_title else None

        return {'video': self._live_video(), 'event': event}


    def playlist(self, id):
        data = self._session.get(BRIGHTCOVE_PLAYLIST_URL.format(BRIGHTCOVE_ACCOUNT, id), headers=BRIGHTCOVE_HEADERS).json()
        data['videos'] = sorted(data.get('videos', []), key=lambda x: x.get('published_at') or '', reverse=True)
        return data

    def play(self, id):
        headers = {
            'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36',
            'Origin': 'https://www.supercars.com',
            'X-Forwarded-For': '18.233.21.73',
            'BCOV-POLICY': BRIGHTCOVE_KEY,
        }

        data = self._session.get(BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, id), headers=headers).json()

        if isinstance(data, dict):
            item = self._playlist_item(id, data, headers)
            if item:
                item.headers = headers
                return item

        item = util.process_brightcove(data)
        item.headers = headers
        return item

    def logout(self):
        userdata.delete('access_token')

    def _live_video(self):
        video_id = (self._landing_page or {}).get('video')

        if video_id:
            data = self._session.get(BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, video_id), headers=BRIGHTCOVE_HEADERS).json()
            if isinstance(data, dict) and data.get('id'):
                return data

        # the landing page should always point at it, this is only a fallback
        params = {
            'q': '+name:Superview',
            'limit': 1,
            'offset': 0,
            'sort': '-published_at',
        }

        data = self._session.get(BRIGHTCOVE_SEARCH_URL.format(BRIGHTCOVE_ACCOUNT), params=params, headers=BRIGHTCOVE_HEADERS)
        return data.json()['videos'][0]

    def _contentful(self, query, variables=None):
        data = self._session.post(CONTENTFUL_URL, json={'query': query, 'variables': variables}, headers=CONTENTFUL_HEADERS).json()
        if data.get('errors'):
            raise APIError(data['errors'][0].get('message', 'Unknown error'))

        return data['data']

    def _race_date(self, races, fallback):
        # the folder date is the feature race, i.e. the longest one of the weekend
        best = None
        for race in races:
            try:
                length = (arrow.get(race['endDate']) - arrow.get(race['startDate'])).total_seconds()
            except Exception:
                continue

            if best is None or length > best[0]:
                best = (length, race.get('startDate'))

        start = best[1] if best else (races[0].get('startDate') if races else fallback)
        return (start or '')[:10] or None

    def _parse_event(self, row):
        internal_name = (row.get('internalName') or '').split(' - ')[0].strip()
        track = row.get('track') or {}
        hero = row.get('heroMedia') or {}
        poster = row.get('calendarPosterImage') or {}
        season = row.get('season') or {}
        portrait = (poster.get('height') or 0) > (poster.get('width') or 0)
        races = (row.get('raceSessionsCollection') or {}).get('items') or []

        return {
            'name': row.get('title'),
            'slug': row.get('slug'),
            'round': int(internal_name) if internal_name.isdigit() else None,
            'year': int(season['year']) if (season.get('year') or '').isdigit() else None,
            'date': self._race_date(races, row.get('startDate')),
            'dates': self._dates(row.get('startDate'), row.get('endDate')),
            'location': row.get('location'),
            'track': track.get('title'),
            'laps': track.get('laps'),
            'description': row.get('description'),
            'art': self._image(hero.get('url') or poster.get('url'), 1920, 1080),
            'thumb': self._image(self._thumb_source(poster, hero), 640, 360),
            'poster': self._image(poster.get('url'), 1000, 1500) if portrait else None,
        }

    def _match_event(self, row):
        year = int(row['season']['year']) if row.get('season') else None
        names = [row.get('title'), (row.get('slug') or '').replace('-', ' ')]

        for event in self.events():
            if year and event['year'] != year:
                continue

            if _names_match(re.sub(r'\s*20\d{2}$', '', event['name']), *names):
                return event['id']

        return None

    def _dates(self, start, end):
        if not start or not end:
            return None

        start = arrow.get(start)
        end = arrow.get(end)

        if start.format('YYYYMMDD') == end.format('YYYYMMDD'):
            return start.format('D MMM YYYY')
        elif start.format('YYYYMM') == end.format('YYYYMM'):
            return u'{}\u2013{}'.format(start.format('D'), end.format('D MMM YYYY'))
        else:
            return u'{} \u2013 {}'.format(start.format('D MMM'), end.format('D MMM YYYY'))

    def _thumb_source(self, poster, hero):
        # most event posters are portrait; Kodi lists look best with a landscape still
        if poster.get('url') and (poster.get('width') or 0) >= (poster.get('height') or 0):
            return poster['url']

        return hero.get('url') or poster.get('url')

    def _image(self, url, width, height):
        if not url:
            return None

        return '{}?w={}&h={}&fit=fill&f=center'.format(url, width, height)

    def _sources(self, data, **match):
        return [x for x in data.get('sources', []) if x.get('src') and not x.get('key_systems')
            and all(x.get(key) == value for key, value in match.items())]

    def _playlist_item(self, reference_id, data, headers):
        # Brightcove's MP4 renditions can top out below HLS (2026 archives have no 720p MP4), so
        # hand the proxy one playlist built from both the MP4 renditions and the muxed HLS variants
        hls = self._sources(data, type='application/x-mpegURL')
        mp4 = self._sources(data, container='MP4')

        if not hls or not mp4:
            return None

        # v3 is muxed TS, so a variant can be played on its own. v4 splits audio into an EXT-X-MEDIA group
        hls = min(hls, key=lambda x: int(x.get('ext_x_version') or 0))
        variants, muxed = self._hls_master(hls['src'], headers)

        if max([x.get('height') or 0 for x in mp4]) <= self._max_height(variants):
            return None

        path = self._build_playlist(reference_id, mp4, variants if muxed else [])
        return plugin.Item(path=path, art=False, proxy_data={'custom_quality': True})

    def _build_playlist(self, reference_id, mp4_sources, hls_variants):
        path = 'special://temp/superview_{}.m3u8'.format(reference_id)

        streams = [{
            'bandwidth': x.get('avg_bitrate') or 0,
            'resolution': '{}x{}'.format(x.get('width') or 0, x.get('height') or 0),
            'codecs': 'avc1',
            'url': x['src'],
        } for x in mp4_sources]
        streams.extend(hls_variants)

        unique = {}
        for stream in streams:
            key = (stream['resolution'], stream['bandwidth'])
            if key not in unique or stream['url'].startswith('https://'):
                unique[key] = stream

        lines = ['#EXTM3U', '#EXT-X-VERSION:3']
        for stream in sorted(unique.values(), key=lambda x: x['bandwidth'], reverse=True):
            lines.append('#EXT-X-STREAM-INF:BANDWIDTH={},RESOLUTION={},CODECS="{}"'.format(stream['bandwidth'], stream['resolution'], stream['codecs']))
            lines.append(stream['url'])

        with io.open(xbmc.translatePath(path), 'w', encoding='utf-8') as f:
            f.write(u'\n'.join(lines))

        return path

    def _hls_master(self, url, headers):
        try:
            manifest = self._session.get(url, headers=headers).text
        except Exception:
            return [], False

        variants = []
        stream_inf = None
        for line in manifest.splitlines():
            line = line.strip()

            if line.startswith('#EXT-X-STREAM-INF:'):
                stream_inf = line.split(':', 1)[1]
            elif stream_inf and line and not line.startswith('#'):
                attrs = dict(re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', stream_inf))
                variants.append({
                    'bandwidth': int(attrs.get('BANDWIDTH', '0').strip('"') or 0),
                    'resolution': attrs.get('RESOLUTION', '').strip('"'),
                    'codecs': attrs.get('CODECS', '').strip('"'),
                    'url': line,
                })
                stream_inf = None

        # a separate audio group can't be followed through the proxy redirect
        return variants, '#EXT-X-MEDIA' not in manifest

    def _max_height(self, variants):
        heights = [int(x['resolution'].split('x')[1]) for x in variants if 'x' in x['resolution']]
        return max(heights or [0])