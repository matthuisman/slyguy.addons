from slyguy import plugin, gui, userdata, signals
from slyguy.constants import ROUTE_LIVE_TAG

from .api import API
from .language import _
from .settings import settings


api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False, content='videos')

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.RACES, _bold=True), path=plugin.url_for(races))

        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


def _short_name(name, year=None):
    # drop only the season year, which is redundant inside a year folder. It can be leading
    # ("2026 Repco Bathurst 1000") or trailing ("Gold Coast 2026")
    name = (name or '').strip()
    year = str(year or '')

    if not year:
        return name
    if name.startswith(year + ' '):
        return name[len(year) + 1:].strip()
    if name.endswith(' ' + year):
        return name[:-len(year) - 1].strip()

    return name


def _event_plot(event, session=None):
    heading = [
        _short_name(event.get('name'), event.get('year')),
        'Round {}'.format(event['round']) if event.get('round') else None,
        session,
    ]
    details = [
        event.get('dates'),
        event.get('location') or event.get('track'),
        '{} laps'.format(event['laps']) if event.get('laps') else None,
    ]

    lines = [u' \u00b7 '.join([x for x in line if x]) for line in (heading, details)]
    lines = [x for x in lines if x]

    return '\n\n'.join([x for x in [event.get('description'), u'\n'.join(lines)] if x])


def _event_art(event):
    art = {'thumb': event.get('thumb'), 'fanart': event.get('art')}
    if event.get('poster'):
        art['poster'] = event['poster']

    return art


def _event_info(event):
    info = {'title': _short_name(event.get('name'), event.get('year')), 'plot': _event_plot(event)}
    if event.get('year'):
        info['year'] = event['year']
    if event.get('date'):
        info['aired'] = event['date']

    return info


def _process_live(live):
    row = live['video']
    event = live['event']

    row['is_live'] = True

    if event:
        row['name'] = _(_.LIVE_LABEL, title=_short_name(event['name'], event.get('year')))
        row['title'] = row['name']
        row['long_description'] = _event_plot(event, event.get('session'))
        row['poster'] = event['thumb']
        row['fanart'] = event['art']

    return row


def _process_rows(rows, event=None):
    event_plot = _event_plot(event) if event else None
    rows = [x for x in rows if x['duration'] or x.get('is_live')]
    items = []

    for index, row in enumerate(rows):
        is_live = row.get('is_live', False)
        published = (row.get('published_at') or '')[:10]
        fanart = row.get('fanart') or (event and event['art']) or row.get('poster')

        info = {
            'mediatype': 'video',
            'title': row.get('title') or row['name'],
            'plot': row.get('long_description') or event_plot,
            'aired': published if not is_live else None,
            'year': int(published[:4]) if published and not is_live else None,
            'duration': (row['duration'] // 1000) if not is_live else None,
        }

        if event:
            info['tvshowtitle'] = _short_name(event.get('name'), event.get('year'))
            if event.get('year'):
                info['season'] = event['year']
            if not is_live:
                info['episode'] = len(rows) - index

        items.append(plugin.Item(
            label = row['name'],
            art = {'thumb': row.get('poster'), 'fanart': fanart},
            playable = True,
            path = plugin.url_for(play, id=row['id'], _is_live=is_live),
            info = info,
        ))

    return items


@plugin.route()
def login(**kwargs):
    username = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not username:
        return

    userdata.set('username', username)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login(username=username, password=password)
    gui.refresh()


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def races(year=None, **kwargs):
    if year is None:
        folder = plugin.Folder(_.RACES, cacheToDisc=False, content='videos')

        live = api.live()
        folder.add_items(_process_rows([_process_live(live)], live['event']))

        rows = api.events()
        years = set([row['year'] for row in rows if row['year']])

        for i in sorted(years, reverse=True):
            folder.add_item(label=str(i), path=plugin.url_for(races, year=i))

        return folder

    year = int(year)
    events = api.season_events(year)
    live = api.live()
    live_id = live['event']['id'] if live['event'] else None

    folder = plugin.Folder(str(year), cacheToDisc=False, content='videos', no_items_label=_.NO_RACES)
    for row in api.events():
        if row['year'] != year:
            continue

        info = api.event_info(row['name'], events)
        label = _short_name(row['name'], year)

        folder.add_item(
            label = _(_.LIVE_LABEL, title=label) if row['id'] == live_id else label,
            art = _event_art(info) if info else None,
            info = _event_info(info) if info else None,
            path = plugin.url_for(event, id=row['id'], name=row['name'])
        )

    return folder


@plugin.route()
@plugin.login_required()
def event(id, name=None, **kwargs):
    info = api.event_info(name) if name else None
    title = _short_name(name, info.get('year') if info else None)

    folder = plugin.Folder(title, cacheToDisc=False, content='episodes', no_items_label=_.NO_RACES,
        thumb = info['thumb'] if info else None,
        fanart = info['art'] if info else None,
    )

    folder.add_items(_process_rows(api.playlist(id)['videos'], info))
    return folder


@plugin.route()
@plugin.login_required()
def play(id, **kwargs):
    item = api.play(id)

    if ROUTE_LIVE_TAG in kwargs and item.inputstream:
        item.inputstream.live = True

    return item