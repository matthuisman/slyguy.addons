import arrow
import codecs

from slyguy import plugin, signals, inputstream, gui, monitor

from .api import API
from .language import _
from .settings import settings
from .constants import *

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)


    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))

        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    options = [
        [_.DEVICE_CODE, _device_code],
    ]

    index = 0 if len(options) == 1 else gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    gui.refresh()


def _device_code():
    expires = 300
    data = api.device_code()
    with gui.progress_qr(data['qr'], _(_.DEVICE_LINK_STEPS, code=data['token'], url=ACTIVATE_URL), heading=_.DEVICE_CODE) as progress:
        for i in range(expires):
            if progress.iscanceled() or monitor.waitForAbort(1):
                return

            progress.update(int((i / float(expires)) * 100))
            if i % data['polling_interval_seconds'] == 0 and api.device_login(data['token']):
                return True


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    channels = api.available_channels()

    for channel in channels:
        channel = channel['node']
        if settings.HIDE_LOCKED.value and not channel.get('isInPlan'):
            continue
        label = channel['displayName']
        if not channel.get('isInPlan'):
            label = _(_.LOCKED, label=label)
        folder.add_item(
            label=label,
            path=plugin.url_for(play, channel_id=channel['id'], _is_live=True),
            art={'thumb': channel.get('images', {}).get('large') or channel.get('images', {}).get('small')},
            playable=True,
        )

    return folder


@plugin.route()
def play(channel_id, **kwargs):
    data = api.play(channel_id)

    headers = {}
    headers.update(HEADERS)
    headers['x-dt-auth-token'] = data['drmProvider']['authToken']

    return plugin.Item(
        path = data['dashURL'],
        inputstream=inputstream.Widevine(
            license_key = data['drmProvider']['drmSystems'][0]['licenseURL'],
        ),
        headers=headers,
    )


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for row in api.available_channels():
            channel = row['node']
            if not channel.get('isInPlan'):
                continue

            logo = channel.get('images', {}).get('large') or channel.get('images', {}).get('small') or ''
            f.write(u'\n#EXTINF:-1 tvg-id="{id}" tvg-name="{name}" tvg-logo="{logo}",{name}\n{url}'.format(
                id=channel['id'], name=channel['displayName'], logo=logo,
                url=plugin.url_for(play, channel_id=channel['id'], _is_live=True),
            ))



@plugin.route()
@plugin.merge()
@plugin.login_required()
def epg(output, **kwargs):
    raise Exception('EPG not implemented yet')
