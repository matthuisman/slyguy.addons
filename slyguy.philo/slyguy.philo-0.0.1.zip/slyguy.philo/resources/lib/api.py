import uuid

from slyguy import userdata, mem_cache
from slyguy.session import Session
from slyguy.exceptions import Error

from .constants import *
from .language import _
from .settings import settings


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(headers=HEADERS)
        if userdata.get('user_cookies'):
            self._session.cookies.update(userdata.get('user_cookies'))
            self.logged_in = True

    def device_code(self):
        self.logout()

        self._session.cookies.set('ajs_anonymous_id', str(uuid.uuid4()))
        self._session.get(PLAYER_URL, stream=True).close()  # get cookies
        payload = {
            "device": "androidtv",
            "device_ident": settings.DEVICE_ID.value,
        }
        data = self._session.post('https://www.philo.com/auth/init/activate', json=payload).json()
        payload['is_signup'] = False
        data['qr'] = self._session.post('https://www.philo.com/auth/init/link_device?smart_tv=true&install_source=com.google', json=payload).json()['png_url'].replace('/auth/link/qrcode/', '/player/link/')
        return data

    def device_login(self, token):
        payload = {
            'token': token,
        }
        data = self._session.post('https://www.philo.com/auth/poll/activate', json=payload).json()
        if data['status'].upper() != 'SUCCESS':
            data = self._session.get('https://www.philo.com/auth/poll/link_device?smart_tv=true&install_source=com.google', json={}).json()
            if data['status'].upper() != 'SUCCESS':
                return False

        userdata.set('user_cookies', self._session.cookies.get_dict())
        return True

    def _check_for_error(self, data):
        if 'errors' in data:
            error = data['errors'][0]
            extensions = error.get('extensions', {})
            code = extensions.get('philoCode', extensions.get('code', ''))
            raise APIError("{} ({})" .format(error.get('message', 'Unknown error'), code))

    @mem_cache.cached(60*5)
    def _get_player_id(self):
        payload = [{
            "operationName": "registerPlayerV2",
            "variables": {
                "captionsEnabled": True,
                "deviceIcon": "TV",
                "deviceName": "android",
                "deviceType": "ANDROID_TV",
                "deviceModel": "SHIELD Android TV",
                "deviceManufacturer": "NVIDIA",
                "deviceIdent": settings.DEVICE_ID.value,
                "volume": 0,
                "applicationVersion": "10.6.0",
                "osVersion": "11.0.0",
                "properties": [{
                    "name": "supportsChunkLoading",
                    "value": "true"
                }]
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "8312f5c234270aa2de0f199e79667ca23e41ac6e23d8f4bc31d3007702fbe9a9"
                }
            }
        }]
        data = self._session.post(GRAPH_URL, json=payload).json()[0]
        self._check_for_error(data)
        return data['data']['registerPlayerV2']['player']['id']

    def play(self, channel_id):
        payload = [{
            "operationName": "createPlaybackSessionV2",
            "variables": {
                "id": channel_id,
                "playerId": self._get_player_id(),
                "lat": False,
            #	"idfa": "....", # hard-coded
            #	"givn": "....", # generated in JS script
            #	"tileGroupId": "....", # in json response
                "broadcastAt": None,
                "startAtOverride": "LIVE",
                "isPreload": False
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "2ef315fa06929d36f1a1b332f3a46fe4edf296ad5f13491eb0329b55c06ac432"
                }
            }
        }]

        data = self._session.post(GRAPH_URL, json=payload).json()[0]
        self._check_for_error(data)
        return data['data']['createPlaybackSessionV2']

    def available_channels(self):
        payload = [{
            "operationName": "availableChannels",
            "variables": {
                "numChannels": 200,
                "order": "ALPHABETICAL"
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "d9028bd4d1c3b13d0fdef6a56d82887f32ab08f942b132b4c588709cd41e7633"
                }
            }
        }]

        data = self._session.post(GRAPH_URL, json=payload).json()[0]
        self._check_for_error(data)
        return data['data']['availableChannels']['edges']

    def logout(self):
        userdata.delete('user_cookies')
        try: self._session.get('https://www.philo.com/user/logout', json={})
        except: pass
        self.new_session()
