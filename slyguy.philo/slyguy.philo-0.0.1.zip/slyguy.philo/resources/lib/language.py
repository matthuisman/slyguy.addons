from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    HIDE_LOCKED     = 30001
    CLEAR_DEVICE_ID   = 30002
    DEVICE_ID         = 30003
    LOCKED            = 30004

_ = Language()
