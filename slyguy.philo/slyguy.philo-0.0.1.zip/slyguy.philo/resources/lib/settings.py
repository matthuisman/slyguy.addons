import uuid

from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool, AutoText
from slyguy.constants import *

from .language import _


class Settings(CommonSettings):
    HIDE_LOCKED = Bool('hide_locked', _.HIDE_LOCKED, default=False)
    DEVICE_ID = AutoText('device_id', _.DEVICE_ID, generator=uuid.uuid4, confirm_clear=_.CLEAR_DEVICE_ID)


settings = Settings()
