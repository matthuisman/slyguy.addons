GRAPH_URL = "https://www.philo.com/graphql"
PLAYER_URL = 'https://www.philo.com/player/android?version=10.6.0&deviceType=androidtv'
ACTIVATE_URL = 'https://www.philo.com/activate'

HEADERS = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 11; SHIELD Android TV Build/RQ1A.210105.003) (Philo TV Android/10.6.8-1448888-tv-google)',
    'X-Requested-With': 'com.philo.philo.google',
    'Referer': PLAYER_URL,
}
