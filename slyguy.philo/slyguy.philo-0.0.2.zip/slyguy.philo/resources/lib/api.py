import uuid

import arrow

from slyguy import userdata, mem_cache
from slyguy.session import Session
from slyguy.exceptions import Error

from .constants import *
from .language import _
from .settings import settings


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(headers=HEADERS)
        if userdata.get('user_cookies'):
            self._session.cookies.update(userdata.get('user_cookies'))
            self.logged_in = True

    def device_code(self):
        self.logout()

        self._session.cookies.set('ajs_anonymous_id', str(uuid.uuid4()))
        self._session.get(PLAYER_URL, stream=True).close()  # get cookies
        payload = {
            "device": "androidtv",
            "device_ident": settings.DEVICE_ID.value,
        }
        data = self._session.post('https://www.philo.com/auth/init/activate', json=payload).json()
        payload['is_signup'] = False
        data['qr'] = self._session.post('https://www.philo.com/auth/init/link_device?smart_tv=true&install_source=com.google', json=payload).json()['png_url'].replace('/auth/link/qrcode/', '/player/link/')
        return data

    def device_login(self, token):
        payload = {
            'token': token,
        }
        data = self._session.post('https://www.philo.com/auth/poll/activate', json=payload).json()
        if data['status'].upper() != 'SUCCESS':
            data = self._session.get('https://www.philo.com/auth/poll/link_device?smart_tv=true&install_source=com.google', json={}).json()
            if data['status'].upper() != 'SUCCESS':
                return False

        userdata.set('user_cookies', self._session.cookies.get_dict())
        return True

    def _check_for_error(self, data):
        if 'errors' in data:
            error = data['errors'][0]
            extensions = error.get('extensions', {})
            code = extensions.get('philoCode', extensions.get('code', ''))
            raise APIError("{} ({})" .format(error.get('message', 'Unknown error'), code))

    @mem_cache.cached(60*5)
    def _get_player_id(self):
        payload = [{
            "operationName": "registerPlayerV2",
            "variables": {
                "captionsEnabled": True,
                "deviceIcon": "TV",
                "deviceName": "android",
                "deviceType": "ANDROID_TV",
                "deviceModel": "SHIELD Android TV",
                "deviceManufacturer": "NVIDIA",
                "deviceIdent": settings.DEVICE_ID.value,
                "volume": 0,
                "applicationVersion": "10.6.0",
                "osVersion": "11.0.0",
                "properties": [{
                    "name": "supportsChunkLoading",
                    "value": "true"
                }]
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "8312f5c234270aa2de0f199e79667ca23e41ac6e23d8f4bc31d3007702fbe9a9"
                }
            }
        }]
        data = self._session.post(GRAPH_URL, json=payload).json()[0]
        self._check_for_error(data)
        return data['data']['registerPlayerV2']['player']['id']

    def play(self, channel_id):
        payload = [{
            "operationName": "createPlaybackSessionV2",
            "variables": {
                "id": channel_id,
                "playerId": self._get_player_id(),
                "lat": False,
            #	"idfa": "....", # hard-coded
            #	"givn": "....", # generated in JS script
            #	"tileGroupId": "....", # in json response
                "broadcastAt": None,
                "startAtOverride": "LIVE",
                "isPreload": False
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "2ef315fa06929d36f1a1b332f3a46fe4edf296ad5f13491eb0329b55c06ac432"
                }
            }
        }]

        data = self._session.post(GRAPH_URL, json=payload).json()[0]
        self._check_for_error(data)
        return data['data']['createPlaybackSessionV2']

    @mem_cache.cached(60*10)
    def available_channels(self):
        channels = []
        seen = set()
        cursor = None

        for _ in range(10):
            capabilities = [
                "COLLECTION_TILE_GROUPS", "HERO_PROMOTION", "MOVIE_SHOWINGS",
                "GUIDE_FILTERS", "SEARCH_PAGE_RECS", "UNIFIED_SHOWS_MOVIES_SEARCH_RESULTS",
                "EXTERNAL_CONTENT", "COLLECTION_GROUPS", "CHANNEL_TILE_GROUPS_V2", "OUT_OF_PLAN_CONTENT",
            ]
            payload = [{
                "operationName": "page",
                "variables": {
                    "pageType": "GUIDE",
                    "typeId": None,
                    "filterId": None,
                    "filter": None,
                    "sorterId": None,
                    "endCursor": cursor,
                    "startCursor": None,
                    "firstGroups": 60,
                    "initialTiles": 3,
                    "lastGroups": None,
                    "numSparseGroups": 400,
                    "includeTileDescription": False,
                    "includeTileChannel": True,
                    "iconFormat": "SVG",
                    "capabilities": capabilities,
                    "startTime": None,
                    "endTime": None,
                },
                "extensions": {
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "5a3975c00b8c834d29af0bd311f7c7c5b7983bc92cedf0ba8e08598c6dac3c01"
                    }
                }
            }]

            data = self._session.post(GRAPH_URL, json=payload).json()[0]
            self._check_for_error(data)

            groups = data['data']['page'].get('groups', {})
            for edge in groups.get('edges', []):
                node = edge.get('node') or {}
                ch = node.get('channel') or {}
                cid = ch.get('channelId')
                if not cid or cid in seen:
                    continue
                seen.add(cid)

                white = ch.get('whiteLogo') or {}
                dark = ch.get('darkLogo') or {}
                logo = None
                for src in (dark.get('largeD') if isinstance(dark, dict) else None,
                            white.get('largeWhite') if isinstance(white, dict) else None,
                            white.get('smallWhite') if isinstance(white, dict) else None):
                    if src:
                        logo = src
                        break

                is_in_plan = False
                tile_edges = (node.get('tiles') or {}).get('edges') or []
                if tile_edges:
                    is_in_plan = bool((tile_edges[0].get('node') or {}).get('isInPlan', False))

                programs = []
                for tile_edge in tile_edges:
                    tile = tile_edge.get('node') or {}
                    title = tile.get('title')
                    start_str = tile.get('availabilityStartsAt') or tile.get('airingTime')
                    end_str = tile.get('availabilityEndsAt')
                    if not title or not start_str:
                        continue
                    end = arrow.get(end_str).timestamp if end_str else None
                    programs.append([arrow.get(start_str).timestamp, end, title])

                channels.append({'node': {
                    'id': cid,
                    'displayName': ch.get('displayName') or 'Unknown',
                    'images': {'large': logo, 'small': logo},
                    'isInPlan': is_in_plan,
                    'programs': programs,
                }})

            page_info = groups.get('pageInfo') or {}
            if not page_info.get('hasNextPage'):
                break
            cursor = page_info.get('endCursor')

        return channels

    # @mem_cache.cached(60*15)
    # def guide_data(self, end_time=None):
    #     """Fetch the guide/EPG data with all channel schedules (cached)"""
    #     # This mimics the guide page request from the web client
    #     payload = [{
    #         "operationName": "page",
    #         "variables": {
    #             "pageType": "GUIDE",
    #             "typeId": None,
    #             "filterId": None,
    #             "filter": None,
    #             "sorterId": None,
    #             "endCursor": None,
    #             "startCursor": None,
    #             "firstGroups": 200,
    #             "initialTiles": 12,  # Get first 12 tiles per channel
    #             "lastGroups": None,
    #             "numSparseGroups": 400,
    #             "includeTileDescription": False,
    #             "includeTileChannel": True,
    #             "iconFormat": "SVG",
    #             "capabilities": ["COLLECTION_TILE_GROUPS", "HERO_PROMOTION", "MOVIE_SHOWINGS",
    #                              "GUIDE_FILTERS", "SEARCH_PAGE_RECS", "UNIFIED_SHOWS_MOVIES_SEARCH_RESULTS",
    #                              "EXTERNAL_CONTENT", "COLLECTION_GROUPS", "OUT_OF_PLAN_CONTENT", "CHANNEL_TILE_GROUPS_V2"],
    #             "startTime": None,
    #             "endTime": None,
    #         },
    #         "extensions": {
    #             "persistedQuery": {
    #                 "version": 1,
    #                 "sha256Hash": "5a3975c00b8c834d29af0bd311f7c7c5b7983bc92cedf0ba8e08598c6dac3c01"
    #             }
    #         }
    #     }]

    #     data = self._session.post(GRAPH_URL, json=payload).json()[0]
    #     self._check_for_error(data)
    #     return data['data']['page']

    def logout(self):
        userdata.delete('user_cookies')
        try: self._session.get('https://www.philo.com/user/logout', json={})
        except: pass
        self.new_session()
