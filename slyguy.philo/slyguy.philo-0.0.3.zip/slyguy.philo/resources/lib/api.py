import uuid

import arrow

from slyguy import userdata, mem_cache
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.util import async_tasks

from .constants import *
from .settings import settings


GUIDE_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S.000Z'
GUIDE_WINDOW_HOURS = 12
GUIDE_WINDOW_MAX_HOURS = 24
GUIDE_PAGE_SIZE = 200
GUIDE_TIMEOUT = 120
GUIDE_IMAGE_WIDTH = '400'
GUIDE_WORKERS = 3

# Gracenote crew roles (show.crew[].role) that map onto an XMLTV <credits> element
GUIDE_CREW_ROLES = {
    'Director': 'director',
    'Screenwriter': 'writer',
    'Writer': 'writer',
    'Writer (Original Screenplay)': 'writer',
    'Producer': 'producer',
    'Executive Producer': 'producer',
}

# episode artwork first, then show artwork - the show variants that carry the show title
# (banner, title logo) come before the ones that are just key art
GUIDE_EPISODE_IMAGES = ('horizontalIconicImage',)
GUIDE_SHOW_IMAGES = (
    'bannerImage', 'titleImage', 'neutralTitleImage', 'horizontalIconicImage',
    'squareBannerImage', 'squareIconicImage', 'posterImage', 'backdropImage',
)


class APIError(Error):
    def __init__(self, message='', code=None):
        super(APIError, self).__init__(message)
        self.code = code


def _image_url(image):
    url = (image or {}).get('url')
    if not url:
        return None

    # Kodi < 19 has no webp support, the CDN serves jpg/png without auto=webp
    return url.replace('${width}', GUIDE_IMAGE_WIDTH).replace('&auto=webp', '')


def _tile_image(show, episode):
    for source, keys in ((episode, GUIDE_EPISODE_IMAGES), (show, GUIDE_SHOW_IMAGES)):
        for key in keys:
            url = _image_url(source.get(key))
            if url:
                return url

    return None


def _person_name(person):
    name = (person or {}).get('name') or {}
    return ' '.join(part for part in (name.get('first'), name.get('last')) if part)


def _air_date(*values):
    for value in values:
        if not value:
            continue
        try:
            return arrow.get(value)
        except Exception:
            pass

    return None


def _credits(show):
    credits = {'director': [], 'writer': [], 'producer': [], 'actor': []}

    for person in show.get('crew') or []:
        role = GUIDE_CREW_ROLES.get(person.get('role'))
        name = _person_name(person)
        if role and name and name not in credits[role]:
            credits[role].append(name)

    for person in show.get('cast') or []:
        name = _person_name(person)
        if name and name not in credits['actor']:
            credits['actor'].append(name)

    return dict((role, names) for role, names in credits.items() if names)


def _parse_tile(tile):
    title = tile.get('title')
    start = tile.get('availabilityStartsAt') or tile.get('airingTime')
    if not title or not start:
        return None

    try:
        start = arrow.get(start)
        if tile.get('availabilityEndsAt'):
            stop = arrow.get(tile.get('availabilityEndsAt'))
        else:
            stop = start.shift(seconds=tile.get('durationInSeconds') or 1800)
    except Exception:
        return None

    rating = None
    star_rating = None
    for row in tile.get('ratings') or []:
        system = (row.get('classification') or '').upper()
        if not row.get('value'):
            continue
        if not rating and system in ('VCHIP', 'MPAA'):
            rating = [system, row['value']]
        elif not star_rating and system == 'TMS':
            star_rating = row['value']  # Gracenote quality rating, 0-4 stars

    episode = tile.get('episode') or {}
    show = tile.get('show') or {}
    is_movie = (show.get('type') or '').upper() == 'MOVIE'

    # a series' originalAirDate is the launch date of the strand (BBC News: 2008), which
    # must not be stamped on today's bulletin - only episodes carry a real air date
    first_aired = _air_date(episode.get('originalAirDate'))
    if not first_aired and is_movie:
        first_aired = _air_date(show.get('originalAirDate'))

    image = _tile_image(show, episode)

    return {
        'title': title,
        'subtitle': tile.get('subtitle'),
        'description': tile.get('description'),
        'image': image,
        'start': start,
        'stop': stop,
        'rating': rating,
        'star_rating': star_rating,
        'categories': [row['name'] for row in (tile.get('genres') or []) if row.get('name')],
        'is_movie': is_movie,
        'year': (show.get('movieReleaseYear') if is_movie else None) or (first_aired.year if first_aired else None),
        'first_aired': first_aired,
        'credits': _credits(show),
        'season': episode.get('seasonNum'),
        'episode': episode.get('episodeNum'),
    }


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(headers=HEADERS)
        if userdata.get('user_cookies'):
            self._session.cookies.update(userdata.get('user_cookies'))
            self.logged_in = True

    def device_code(self):
        self.logout()

        self._session.cookies.set('ajs_anonymous_id', str(uuid.uuid4()))
        self._session.get(PLAYER_URL, stream=True).close()  # get cookies
        payload = {
            "device": "androidtv",
            "device_ident": settings.DEVICE_ID.value,
        }
        data = self._session.post('https://www.philo.com/auth/init/activate', json=payload).json()
        payload['is_signup'] = False
        data['qr'] = self._session.post('https://www.philo.com/auth/init/link_device?smart_tv=true&install_source=com.google', json=payload).json()['png_url'].replace('/auth/link/qrcode/', '/player/link/')
        return data

    def device_login(self, token):
        payload = {
            'token': token,
        }
        data = self._session.post('https://www.philo.com/auth/poll/activate', json=payload).json()
        if data['status'].upper() != 'SUCCESS':
            data = self._session.get('https://www.philo.com/auth/poll/link_device?smart_tv=true&install_source=com.google', json={}).json()
            if data['status'].upper() != 'SUCCESS':
                return False

        userdata.set('user_cookies', self._session.cookies.get_dict())
        return True

    def _check_for_error(self, data):
        if 'errors' in data:
            error = data['errors'][0]
            extensions = error.get('extensions', {})
            code = extensions.get('philoCode', extensions.get('code', ''))
            raise APIError("{} ({})".format(error.get('message', 'Unknown error'), code), code)

    def _graph(self, payload, timeout=None):
        """POST one operation and return its `data` payload."""
        kwargs = {'timeout': timeout} if timeout else {}
        data = self._session.post(GRAPH_URL, json=[payload], **kwargs).json()[0]
        self._check_for_error(data)
        return data.get('data') or {}

    @mem_cache.cached(60*5)
    def _get_player_id(self):
        data = self._graph({
            "operationName": "registerPlayerV2",
            "variables": {
                "captionsEnabled": True,
                "deviceIcon": "TV",
                "deviceName": "android",
                "deviceType": "ANDROID_TV",
                "deviceModel": "SHIELD Android TV",
                "deviceManufacturer": "NVIDIA",
                "deviceIdent": settings.DEVICE_ID.value,
                "volume": 0,
                "applicationVersion": "10.6.0",
                "osVersion": "11.0.0",
                "properties": [{
                    "name": "supportsChunkLoading",
                    "value": "true"
                }]
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "8312f5c234270aa2de0f199e79667ca23e41ac6e23d8f4bc31d3007702fbe9a9"
                }
            }
        })
        return data['registerPlayerV2']['player']['id']

    def play(self, channel_id):
        data = self._graph({
            "operationName": "createPlaybackSessionV2",
            "variables": {
                "id": channel_id,
                "playerId": self._get_player_id(),
                "lat": False,
                "broadcastAt": None,
                "startAtOverride": "LIVE",
                "isPreload": False,
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "2ef315fa06929d36f1a1b332f3a46fe4edf296ad5f13491eb0329b55c06ac432"
                }
            }
        })
        return data['createPlaybackSessionV2']

    @mem_cache.cached(60*10)
    def available_channels(self):
        capabilities = [
            "COLLECTION_TILE_GROUPS", "HERO_PROMOTION", "MOVIE_SHOWINGS",
            "GUIDE_FILTERS", "SEARCH_PAGE_RECS", "UNIFIED_SHOWS_MOVIES_SEARCH_RESULTS",
            "EXTERNAL_CONTENT", "COLLECTION_GROUPS", "CHANNEL_TILE_GROUPS_V2", "OUT_OF_PLAN_CONTENT",
        ]

        channels = []
        seen = set()
        cursor = None

        for _ in range(10):
            data = self._graph({
                "operationName": "page",
                "variables": {
                    "pageType": "GUIDE",
                    "typeId": None,
                    "filterId": None,
                    "filter": None,
                    "sorterId": None,
                    "endCursor": cursor,
                    "startCursor": None,
                    "firstGroups": 60,
                    "initialTiles": 3,
                    "lastGroups": None,
                    "numSparseGroups": 400,
                    "includeTileDescription": False,
                    "includeTileChannel": True,
                    "iconFormat": "SVG",
                    "capabilities": capabilities,
                    "startTime": None,
                    "endTime": None,
                },
                "extensions": {
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "5a3975c00b8c834d29af0bd311f7c7c5b7983bc92cedf0ba8e08598c6dac3c01"
                    }
                }
            })

            groups = data['page'].get('groups', {})
            for edge in groups.get('edges', []):
                node = edge.get('node') or {}
                ch = node.get('channel') or {}
                cid = ch.get('channelId')
                if not cid or cid in seen:
                    continue
                seen.add(cid)

                white = ch.get('whiteLogo') or {}
                dark = ch.get('darkLogo') or {}
                logo = None
                for src in (dark.get('largeD') if isinstance(dark, dict) else None,
                            white.get('largeWhite') if isinstance(white, dict) else None,
                            white.get('smallWhite') if isinstance(white, dict) else None):
                    if src:
                        logo = src
                        break

                is_in_plan = False
                tile_edges = (node.get('tiles') or {}).get('edges') or []
                if tile_edges:
                    is_in_plan = bool((tile_edges[0].get('node') or {}).get('isInPlan', False))

                programs = []
                for tile_edge in tile_edges:
                    tile = tile_edge.get('node') or {}
                    title = tile.get('title')
                    start_str = tile.get('availabilityStartsAt') or tile.get('airingTime')
                    end_str = tile.get('availabilityEndsAt')
                    if not title or not start_str:
                        continue
                    end = arrow.get(end_str).timestamp if end_str else None
                    programs.append([arrow.get(start_str).timestamp, end, title])

                channels.append({'node': {
                    'id': cid,
                    'displayName': ch.get('displayName') or 'Unknown',
                    'images': {'large': logo, 'small': logo},
                    'isInPlan': is_in_plan,
                    'programs': programs,
                }})

            page_info = groups.get('pageInfo') or {}
            if not page_info.get('hasNextPage'):
                break
            cursor = page_info.get('endCursor')

        return channels

    @mem_cache.cached(60*10)
    def guide(self, days=3):
        """Guide data for the next X days.

        Returns {channel_id: {'name': str, 'programs': []}} for every in plan channel
        in the guide. The guide page already returns the tiles for the requested
        window, so a single query per window covers channels and programmes; windows
        are fetched in parallel because the server takes seconds to build each page.
        Programmes include `description` - `GUIDE_DOCUMENT` drops the app's
        @ifTileGroups directives so the server returns a plot for every tile.
        """
        start = arrow.utcnow().shift(hours=-6).floor('hour')
        end = arrow.utcnow().shift(days=days)

        windows = []
        window_start = start
        while window_start < end:
            window_end = window_start.shift(hours=GUIDE_WINDOW_HOURS)
            if window_end > end:
                window_end = end
            windows.append([window_start, window_end])
            window_start = window_end

        # a short trailing window costs a whole request, fold it into the previous one.
        # the server returns at most ~24 hours of tiles per request.
        if len(windows) > 1:
            tail_hours = (windows[-1][1] - windows[-1][0]).total_seconds() / 3600.0
            prev_hours = (windows[-2][1] - windows[-2][0]).total_seconds() / 3600.0
            if tail_hours < GUIDE_WINDOW_HOURS and prev_hours + tail_hours <= GUIDE_WINDOW_MAX_HOURS:
                windows[-2][1] = windows[-1][1]
                windows.pop()

        channels = {}
        tasks = [lambda w=window: self._guide_window(w) for window in windows]
        for window_channels in async_tasks(tasks, workers=GUIDE_WORKERS):
            for channel_id, row in window_channels.items():
                channel = channels.setdefault(channel_id, {
                    'name': row['name'],
                    'in_plan': False,
                    'programs': {},
                })
                channel['in_plan'] = channel['in_plan'] or row['in_plan']
                channel['programs'].update(row['programs'])

        has_plan_data = any(row['in_plan'] for row in channels.values())

        result = {}
        for channel_id, row in channels.items():
            if has_plan_data and not row['in_plan']:
                continue
            result[channel_id] = {
                'name': row['name'],
                'programs': sorted(row['programs'].values(), key=lambda x: x['start']),
            }

        return result

    def _guide_window(self, window):
        start, end = window

        channels = {}
        for node in self._guide_groups(start, end):
            channel = node.get('channel') or {}
            channel_id = channel.get('channelId')
            if not channel_id:
                continue

            row = channels.setdefault(channel_id, {
                'name': channel.get('displayName') or channel_id,
                'in_plan': False,
                'programs': {},
            })

            for edge in (node.get('tiles') or {}).get('edges') or []:
                tile = edge.get('node') or {}
                if tile.get('isInPlan'):
                    row['in_plan'] = True

                program = _parse_tile(tile)
                if program:
                    row['programs'][(int(program['start'].timestamp), program['title'])] = program

        return channels

    def _guide_groups(self, start, end):
        nodes = []
        seen = set()
        cursor = None

        for _ in range(10):
            variables = {
                'pageType': 'GUIDE',
                'firstGroups': GUIDE_PAGE_SIZE,
                'endCursor': cursor,
                'startTime': start.strftime(GUIDE_TIME_FORMAT),
                'endTime': end.strftime(GUIDE_TIME_FORMAT),
            }

            data = self._guide_request(variables)
            groups = (data.get('page') or {}).get('groups') or {}

            page_nodes = []
            for edge in groups.get('edges') or []:
                node = edge.get('node') or {}
                channel_id = (node.get('channel') or {}).get('channelId')
                if not channel_id or channel_id in seen:
                    continue
                seen.add(channel_id)
                page_nodes.append(node)

            nodes.extend(page_nodes)

            page_info = groups.get('pageInfo') or {}
            if not page_info.get('hasNextPage') or not page_info.get('endCursor'):
                break
            if not self._page_may_have_plan_channels(page_nodes):
                break
            cursor = page_info.get('endCursor')

        return nodes

    @staticmethod
    def _page_may_have_plan_channels(nodes):
        """Guide pages list every in plan channel first, then a not_in_plan_channels
        section, so once that section starts the remaining pages are all out of plan."""
        seen_plan = False
        for node in nodes:
            tiles = (node.get('tiles') or {}).get('edges') or []
            if any((edge.get('node') or {}).get('isInPlan') for edge in tiles):
                seen_plan = True
            elif seen_plan:
                return False

        return True

    def _guide_request(self, variables):
        return self._graph({
            'operationName': 'page',
            'query': GUIDE_DOCUMENT,
            'variables': variables,
        }, timeout=GUIDE_TIMEOUT)

    def logout(self):
        userdata.delete('user_cookies')
        try: self._session.get('https://www.philo.com/user/logout', json={})
        except: pass
        self.new_session()
