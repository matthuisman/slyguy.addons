GRAPH_URL = "https://www.philo.com/graphql"
PLAYER_URL = 'https://www.philo.com/player/android?version=10.6.0&deviceType=androidtv'
ACTIVATE_URL = 'https://www.philo.com/activate'

# Trimmed copy of the app's own `page`/GUIDE document (operation page, id
# f55c5e3c92cb390b7e06ffcd630f52e3102788b36d907f14cf9698c95f3316b2). The app nests
# description behind @ifTileGroups(types: [HERO,PLAYABLE,...]) so guide tiles never carry
# a plot; without those client side directives the server returns one for every tile.
# Sent as a normal (non persisted) query, which keeps the payload small: only the fields
# the EPG uses are selected.
GUIDE_DOCUMENT = u"""
query page($pageType: PageType!, $firstGroups: Int, $endCursor: String, $startTime: DateTime, $endTime: DateTime) {
  page(type: $pageType) {
    groups(first: $firstGroups, after: $endCursor) {
      pageInfo {
        hasNextPage
        endCursor
      }
      edges {
        node {
          channel {
            channelId
            displayName
          }
          tiles(startTime: $startTime, endTime: $endTime) {
            edges {
              node {
                title
                subtitle
                description
                isInPlan
                airingTime
                availabilityStartsAt
                availabilityEndsAt
                durationInSeconds
                ratings {
                  classification
                  value
                }
                genres {
                  name
                }
                episode {
                  seasonNum
                  episodeNum
                  originalAirDate
                  horizontalIconicImage: image(maxSize: TEMPLATE, orientation: HORIZONTAL, preferredType: ICONIC) {
                    url
                  }
                }
                show {
                  type
                  movieReleaseYear
                  originalAirDate
                  cast(first: 3) {
                    name {
                      first
                      last
                    }
                  }
                  crew(first: 3) {
                    name {
                      first
                      last
                    }
                    role
                  }
                  titleImage(trimmed: true, variant: DARK, alignment: TEMPLATE, size: TEMPLATE) {
                    url
                  }
                  neutralTitleImage: titleImage(trimmed: true, variant: NEUTRAL, alignment: TEMPLATE, size: TEMPLATE) {
                    url
                  }
                  horizontalIconicImage: image(maxSize: TEMPLATE, orientation: HORIZONTAL, preferredType: ICONIC, strictMatch: false) {
                    url
                  }
                  squareIconicImage: image(maxSize: TEMPLATE, orientation: SQUARE, preferredType: ICONIC, strictMatch: false) {
                    url
                  }
                  posterImage: image(maxSize: TEMPLATE, orientation: VERTICAL, preferredType: BANNER, strictMatch: true) {
                    url
                  }
                  squareBannerImage: image(maxSize: TEMPLATE, orientation: SQUARE, preferredType: BANNER, strictMatch: false) {
                    url
                  }
                  bannerImage: image(maxSize: TEMPLATE, orientation: HORIZONTAL, preferredType: BANNER, strictMatch: true) {
                    url
                  }
                  backdropImage: image(maxSize: TEMPLATE, orientation: HORIZONTAL, preferredType: BACKDROP, strictMatch: false) {
                    url
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
"""

HEADERS = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 11; SHIELD Android TV Build/RQ1A.210105.003) (Philo TV Android/10.6.8-1448888-tv-google)',
    'X-Requested-With': 'com.philo.philo.google',
    'Referer': PLAYER_URL,
}
