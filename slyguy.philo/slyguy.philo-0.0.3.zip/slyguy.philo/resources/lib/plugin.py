﻿import arrow
import codecs
from xml.sax.saxutils import escape, quoteattr

from slyguy import plugin, signals, inputstream, gui, monitor

from .api import API
from .language import _
from .settings import settings
from .constants import *

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))

        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    if _device_code():
        gui.refresh()


def _device_code():
    expires = 300
    data = api.device_code()
    with gui.progress_qr(data['qr'], _(_.DEVICE_LINK_STEPS, code=data['token'], url=ACTIVATE_URL), heading=_.DEVICE_CODE) as progress:
        for i in range(expires):
            if progress.iscanceled() or monitor.waitForAbort(1):
                return

            progress.update(int((i / float(expires)) * 100))
            if i % data['polling_interval_seconds'] == 0 and api.device_login(data['token']):
                return True


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    channels = api.available_channels()

    for channel in channels:
        channel = channel['node']
        if settings.HIDE_LOCKED.value and not channel.get('isInPlan'):
            continue

        label = channel['displayName']
        if not channel.get('isInPlan'):
            label = _(_.LOCKED, label=label)

        # Build plot from the programs fetched with the channels
        now = arrow.now()
        plot = u''
        for prog in channel.get('programs') or []:
            start = arrow.get(prog[0])
            if prog[1] and arrow.get(prog[1]) <= now:
                continue
            plot += u'[{}] {}\n'.format(start.to('local').format('h:mma'), prog[2])

        folder.add_item(
            label=label,
            path=plugin.url_for(play, channel_id=channel['id'], _is_live=True),
            art={'thumb': channel.get('images', {}).get('large') or channel.get('images', {}).get('small')},
            info={'plot': plot},
            playable=True,
        )

    return folder


@plugin.route()
def play(channel_id, **kwargs):
    data = api.play(channel_id)

    headers = dict(HEADERS)
    headers['x-dt-auth-token'] = data['drmProvider']['authToken']

    return plugin.Item(
        path = data['dashURL'],
        inputstream=inputstream.Widevine(
            license_key = data['drmProvider']['drmSystems'][0]['licenseURL'],
        ),
        headers=headers,
    )


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for row in api.available_channels():
            channel = row['node']
            if not channel.get('isInPlan'):
                continue

            logo = channel.get('images', {}).get('large') or channel.get('images', {}).get('small') or ''
            f.write(u'\n#EXTINF:-1 tvg-id="{id}" tvg-name="{name}" tvg-logo="{logo}",{name}\n{url}'.format(
                id=channel['id'], name=channel['displayName'], logo=logo,
                url=plugin.url_for(play, channel_id=channel['id'], _is_live=True),
            ))


@plugin.route()
@plugin.merge()
@plugin.login_required()
def epg(output, **kwargs):
    channels = api.guide(settings.getInt('epg_days', 3))

    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'<?xml version="1.0" encoding="utf-8" ?><tv>')

        for channel_id in channels:
            f.write(u'<channel id={}><display-name>{}</display-name></channel>'.format(
                quoteattr(channel_id), escape(channels[channel_id]['name'])))

        for channel_id in channels:
            for prog in channels[channel_id]['programs']:
                f.write(u'<programme channel={} start="{}" stop="{}">'.format(
                    quoteattr(channel_id), prog['start'].format('YYYYMMDDHHmmss Z'), prog['stop'].format('YYYYMMDDHHmmss Z'),
                ))
                f.write(u'<title>{}</title>'.format(escape(prog['title'])))

                if prog['subtitle']:
                    f.write(u'<sub-title>{}</sub-title>'.format(escape(prog['subtitle'])))
                if prog['description']:
                    f.write(u'<desc>{}</desc>'.format(escape(prog['description'])))

                credits = prog.get('credits') or {}
                if credits:
                    f.write(u'<credits>')
                    for role in ('director', 'writer', 'producer', 'actor'):
                        for name in credits.get(role) or []:
                            f.write(u'<{0}>{1}</{0}>'.format(role, escape(name)))
                    f.write(u'</credits>')

                if prog.get('year'):
                    f.write(u'<date>{}</date>'.format(prog['year']))

                for category in prog['categories']:
                    f.write(u'<category>{}</category>'.format(escape(category)))
                if prog.get('is_movie') and u'Movie' not in prog['categories']:
                    f.write(u'<category>Movie</category>')

                if prog.get('image'):
                    f.write(u'<icon src={}/>'.format(quoteattr(prog['image'])))

                if prog['season'] and prog['episode']:
                    f.write(u'<episode-num system="xmltv_ns">{}.{}.0/0</episode-num>'.format(prog['season'] - 1, prog['episode'] - 1))
                    f.write(u'<episode-num system="onscreen">S{:02d}E{:02d}</episode-num>'.format(prog['season'], prog['episode']))

                # a repeat: the episode first aired more than a day before this airing
                first_aired = prog.get('first_aired')
                if first_aired and first_aired < prog['start'].shift(days=-1):
                    f.write(u'<previously-shown start="{}"/>'.format(first_aired.format('YYYYMMDDHHmmss Z')))

                if prog['rating']:
                    f.write(u'<rating system={}><value>{}</value></rating>'.format(quoteattr(prog['rating'][0]), escape(prog['rating'][1])))
                if prog.get('star_rating'):
                    f.write(u'<star-rating system="TMS"><value>{}/4</value></star-rating>'.format(escape(prog['star_rating'])))

                f.write(u'</programme>')

        f.write(u'</tv>')
