DATA_URL = 'https://i.mjh.nz/Plex/.app.json.gz'
PLAY_URL = 'https://epg.provider.plex.tv/library/parts/{id}'
ALL = 'all'
MY_CHANNELS = 'my_channels'
