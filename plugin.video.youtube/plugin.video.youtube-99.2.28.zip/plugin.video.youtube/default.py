import sys
import xbmc

url = sys.argv[0] + sys.argv[2]
xbmc.executebuiltin('RunScript(slyguy.trailers,{})'.format(url))
