import xbmc
xbmc.executebuiltin('RunScript(slyguy.trailers)')
