from resources.lib import plugin

plugin.service()