from slyguy import gui

gui.ok('Stremium service has been shut down and this addon no longer works.')
