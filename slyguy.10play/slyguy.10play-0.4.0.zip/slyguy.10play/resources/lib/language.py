from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    STATE           = 30000
    AUTO            = 30001
    NSW             = 30002
    VIC             = 30003
    QLD             = 30004
    WA              = 30005
    SA              = 30006
    LIVE_TV         = 30007
    ALL             = 30008
    SHOWS_LETTER    = 30009
    ZERO_NINE       = 30010
    SHOWS           = 30011
    FLATTEN_SEASONS = 30012
    HIDE_EXTRAS     = 30013
    CATEGORIES      = 30014
    FEATURED        = 30015
    MY_SHOWS        = 30016
    DEL_MY_SHOW     = 30017
    ADD_MY_SHOW     = 30018
    NT              = 30019
    TAS             = 30020
    ACT             = 30021
    HD_1080P_HACK   = 30022


_ = Language()
