APP_VERSION = '6.28.0'

HEADERS = {
    'user-agent': 'Mozilla/5.0 (Linux; Android 11; SHIELD Android TV; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/136.0.7103.125 Mobile Safari/537.36 10play/{} UAP'.format(APP_VERSION),
}

DAI_USER_AGENT = 'otg/1.5.1 (AppleTv Apple TV 4; tvOS16.0; appletv.client) libcurl/7.58.0 OpenSSL/1.0.2o zlib/1.2.11 clib/1.8.56'

HEX_KEY = 'b918ff793563080c5821c89ee6c415c363cb36d369db1020369ac4b405a0211d'
ACTIVATE_URL = 'https://10.com.au/activate'
CONFIG_URL = 'https://10.com.au/api/v1/config'
LEGACY_VIDEO_URL = 'https://vod.ten.com.au/api/videos/bcquery'
