HEADERS = {
    'user-agent': 'Mozilla/5.0 (Linux; Android 11; SHIELD Android TV; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/136.0.7103.125 Mobile Safari/537.36 10play/6.28.0 UAP',
}

HEX_KEY = 'b918ff793563080c5821c89ee6c415c363cb36d369db1020369ac4b405a0211d'
ACTIVATE_URL = 'https://10play.com.au/activate'
CONFIG_URL = 'https://10play.com.au/api/v1/config'
LEGACY_VIDEO_URL = 'https://vod.ten.com.au/api/videos/bcquery'
