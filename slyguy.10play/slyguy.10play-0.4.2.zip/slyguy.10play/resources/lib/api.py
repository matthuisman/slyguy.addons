import time
import hmac
import hashlib
import binascii
from base64 import b64encode

from slyguy import mem_cache, userdata, log, keep_alive
from slyguy.session import Session
from slyguy.exceptions import Error


import arrow
import requests

from .constants import *
from .language import _
from .settings import settings


class APIError(Error):
    pass


def generate_x_n10_sig(url):
    timestamp = int(time.time())
    message = "{}:{}".format(timestamp, url).encode('utf-8')
    signature = hmac.new(binascii.unhexlify(HEX_KEY), message, hashlib.sha256).hexdigest()
    return "{}_{}".format(timestamp, signature)


def generate_network_ten_auth():
    return b64encode(arrow.utcnow().format('YYYYMMDDHHmmss').encode('utf-8')).decode()


class API(object):
    def new_session(self):
        self.logged_in = True if userdata.get('access_token') else False
        self._session = Session(headers=HEADERS)
        keep_alive.register(self._refresh_token, hours=12, enable=self.logged_in)

    def _config(self):
        params = {
            'SystemName': 'android',
            'manufacturer': 'nvidia',
        }
        return self.get_json(CONFIG_URL, params=params)

    def _request(self, url, method='GET', **kwargs):
        req = requests.Request(method, url, params=kwargs.pop('params', None))
        url = req.prepare().url

        headers = {
            'tp-acceptfeature': 'v1/fw;v1/drm;v2/live',
            'tp-platform': 'UAP',
        }
        headers.update(kwargs.pop('headers', {}))
        if method.upper() == 'GET':
            headers['X-N10-SIG'] = generate_x_n10_sig(url)
        elif method.upper() == 'POST':
            headers['X-Network-Ten-Auth'] = generate_network_ten_auth()

        return self._session.request(method, url, headers=headers, **kwargs)

    @mem_cache.cached(60*5)
    def get_json(self, url, **kwargs):
        return self._request(url, method='GET', **kwargs).json()

    def featured(self):
        self._refresh_token()
        url = '{}/{}'.format(self._config()['homePageApiEndpoint'], self._get_state())
        return self.get_json(url)

    def live_channels(self, schedule_limit=4, **kwargs):
        url = '{}/{}'.format(self._config()['liveTvEndpoint'], self._get_state())
        # TODO: could generate xml from larger limit?
        data = self.get_json(url, params={'limit': schedule_limit}, **kwargs)
        return data

    def search(self, query):
        url = '{}{}'.format(self._config()['searchApiEndpoint'], query)
        return self.get_json(url)

    def show_categories(self):
        config = self._config()
        for row in config['menuConfig']['primary']:
            if row['type'] == 'Shows':
                return row['subItems']
        return []

    def show(self, id):
        url = '{}/{}'.format(self._config()['showsApiEndpoint'], id)
        return self.get_json(url, params={'includeAllSubNavs': 'true'})[0]

    def state(self):
        return self.get_json(self._config()['geoLocationEndpoint'])

    def _get_state(self):
        state = settings.STATE.value
        if not state:
            state = self.state()['state']
        return state

    def season(self, show_id, season_id):
        url = '{}/{}/episodes/{}'.format(self._config()['videosApiEndpoint'], show_id, season_id)
        return self.get_json(url)

    def play(self, id=None, url=None):
        self._refresh_token()

        params = {
            'device': 'Tv',
            'platform': 'lg',
            'appVersion': 'v1',
        }
        if url is None:
            url = '{}/playback/{}'.format(self._config()['videosApiEndpoint'], id)

        headers = {
            'authorization': 'Bearer {}'.format(userdata.get('access_token')),
        }

        resp = self._request(url, params=params, headers=headers)
        data = resp.json()

        if not resp.ok:
            raise APIError("error playing '{}': {}".format(id, data.get('title')))

        auth = resp.headers.get('X-DAI-AUTH')

        payload = {}
        if auth:
            payload = {'auth-token': auth}  # enables upto 720p

        if 'assetKey' in data['dai']:
            data = self._session.post('https://dai.google.com/ssai/event/{}/streams'.format(data['dai']['assetKey']), data=payload,
                    headers={'user-agent': DAI_USER_AGENT}).json()

            data['stream_manifest'] = data['id3_events_url'].replace('id3-events.json', 'master.m3u8')
            is_live = True
        else:
            data = self._session.post('https://dai.google.com/ondemand/hls/content/{}/vid/{}/streams'.format(data['dai']['contentSourceId'], data['dai']['videoId']), data=payload,
                    headers={'user-agent': DAI_USER_AGENT}).json()
            is_live = False

        return data['stream_manifest'], is_live

    def device_code(self):
        self.logout()

        payload = {
            'deviceIdentifier': settings.DEVICE_ID.value,
            'machine': 'Android',
            'system': 'android',
            'systemVersion': '11',
            'platform': 'android',
            'appVersion': APP_VERSION,
            'ipAddress': 'string'
        }
        data = self._request(self._config()['authConfig']['generateCode'], method='POST', json=payload).json()
        return {
            'code': data['code'],
            'url': ACTIVATE_URL,
            'expires_in': int(data['expiry'] - time.time() - 10),
            'expiry': data['expiry'],
            'interval': 5,
        }

    def my_shows(self):
        self._refresh_token()
        url = '{}/shows'.format(self._config()['userEndpoints']['favouriteApiEndpoint'])
        data = self._request(url, headers={'authorization': 'Bearer {}'.format(userdata.get('access_token'))}).json() or {}
        return data.get('items', [])

    def edit_my_show(self, show_id, add=True):
        self._refresh_token()
        url = '{}/shows/{}'.format(self._config()['userEndpoints']['favouriteApiEndpoint'], show_id)
        return self._request(url, method='POST' if add else 'DELETE', json={'type': 'show'}, headers={'authorization': 'Bearer {}'.format(userdata.get('access_token'))}).ok

    def device_login(self, code, expiry):
        payload = {
            'code': code,
            'deviceIdentifier': settings.DEVICE_ID.value,
            'expiry': expiry,
        }
        data = self._request(self._config()['authConfig']['validateCode'], method='POST', json=payload).json()
        if 'jwt' not in data:
            return False

        self._save_jwt(data['jwt'])
        return True

    def _refresh_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('token_expires', 0) > time.time()):
            return

        log.debug('Refreshing token')
        payload = {
            'alternativeToken': userdata.get('access_token'),
            'refreshToken': userdata.get('refresh_token'),
        }
        data = self._request(self._config()['authConfig']['refreshToken'], method='POST', json=payload).json()
        self._save_jwt(data)

    def _save_jwt(self, data):
        if 'alternativeToken' not in data:
            raise APIError(_("Failed to refresh token: {}".format(data)))
        userdata.set('access_token', data['alternativeToken'])
        userdata.set('refresh_token', data['refreshToken'])
        userdata.set('token_expires', int(time.time()) + data['expiresIn'] - 30)

    def logout(self):
        userdata.delete('access_token')
        userdata.delete('refresh_token')
        userdata.delete('token_expires')
        self.new_session()
