from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    LIVE    = 30000
    HOME    = 30001
    BROWSE  = 30002


_ = Language()
