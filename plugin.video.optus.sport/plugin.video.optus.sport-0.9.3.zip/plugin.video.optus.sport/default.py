from slyguy import gui

gui.ok('Optus Sport was discontinued 1st August 2025. You can now use SlyGuy Stan add-on instead')
