DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/.channels.json.gz'
ALL = 'all'
MY_CHANNELS = 'my_channels'
PLAYBACK_URL = 'https://jmp2.uk/{slug}'
