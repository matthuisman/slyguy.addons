HEADERS = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 8.1.0; MI 5 Build/OPM7.181205.001)', 
    'x-api-version': 'v3',
    'x-platform': 'android',
    'x-client-version': 'v2.8.0-57-g17f658392',
}

API_URL = 'https://api.curiositystream.com{}'

PREVIEW_LENGTH = (2*60)
CACHE_TIME     = 60*2