HEADERS = {
    'user-agent': '7plus/5.25.1 (Linux;Android 8.1.0) ExoPlayerLib/2.11.7',
    'x-swm-apikey': 'kGcrNnuPClrkynfnKwG8IA/NhVG6ut5nPEdWF2jscvE=',
}

IMAGE_URL = 'https://images.swm.digital/image?u={url}&q=70&w={width}'
LIVE_TV_SLUG = 'live-tv'
SHOWS_SLUG = 'shows-a-z'
IMAGE_WIDTH = 400
PLATFORM_ID = 'androidtv'
PLATFORM_VERSION = '5.25.0.0'
API_VERSION = '5.9.0.0'
