HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; SHIELD Android TV Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.5.2.582 U3/0.8.0 Mobile Safari/534.30',
}

MD5_KEY = '35a131404c264f36ca4031500143e4acf0682cd5'
LOGIN_URL = 'https://www.willow.tv/EventMgmt/webservices/mobi_auth.asp'
PLAYBACK_URL = 'http://www.willow.tv/iptvws/v1/playlist.asp'
UPCOMING_URL = 'http://appfeeds.willow.tv/RokuUpcoming.json'
ARCHIVE_URL = 'http://appfeeds.willow.tv/iptv/RokuSeriesList.json'
ARCHIVES_MATCH_URL = 'http://appfeeds.willow.tv/iptv/RokuMatchVODList_{match_id}.json'
TEAMS_IMAGE_URL = 'https://aimages.willow.tv/AppleTvLogos/{team1}_{team2}.png'
EXPLORE_URL = 'https://static.willow.tv/apps/explore.json.gz'

DEV_TYPE = 'androidtv'
SERVICE_TIME = 300
