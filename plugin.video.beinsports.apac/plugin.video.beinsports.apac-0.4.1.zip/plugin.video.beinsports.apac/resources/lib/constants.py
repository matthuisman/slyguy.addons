HEADERS = {
    'User-Agent': 'okhttp/3.13.1',
}

APP_VERSION_URL  = 'https://i.mjh.nz/bein/apac.version'
TOKEN_COOKIE_KEY = 'm'
API_BASE         = 'https://v3-mobileservice.apac.beiniz.biz{}'
WV_LICENSE_URL   = 'https://castleblack.digiturk.com.tr/api/widevine/licenseraw?version=1'
PAGESIZE         = 100
