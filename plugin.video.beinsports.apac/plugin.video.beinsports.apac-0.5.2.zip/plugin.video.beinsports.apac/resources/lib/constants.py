HEADERS = {
    'User-Agent': 'okhttp/4.12.0',
}

APP_VERSION_URL = 'https://i.mjh.nz/.apk/apac.version'
TOKEN_COOKIE_KEY = 'm'
API_BASE = 'https://tvservice.apac.beiniz.biz{}'
WV_LICENSE_URL = 'https://castleblack.digiturk.com.tr/api/widevine/licenseraw?version=1'
PAGESIZE = 100
