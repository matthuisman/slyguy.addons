from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    LIVE               = 30000
    PROVIDER_LOGIN_STEPS = 30001
    NOT_ENTITLED       = 30002
    GEO_ERROR          = 30003
    API_ERROR          = 30004
    ESPN_UNLIMITED     = 30005
    TV_PROVIDER        = 30007
    NO_SOURCE          = 30010
    SELECT_BROADCAST   = 30011
    RESET_HIDDEN       = 30012
    RESET_HIDDEN_OK    = 30013
    HIDE_CHANNEL       = 30014
    UPCOMING           = 30015
    SHOW_LIVE_SCORES   = 30016
    HIDE_ALT_LAN       = 30017
    STARTS             = 30018
    STARTED            = 30019
    EVENT_WHITELIST    = 30020
    ESPN_LOGIN_STEPS   = 30021
    LIVE_EVENT         = 30022
    REPLAY_EVENT       = 30023


_ = Language()
