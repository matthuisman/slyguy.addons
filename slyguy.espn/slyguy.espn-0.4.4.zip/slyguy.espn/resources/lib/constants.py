LIVE_BUCKET_ID = 8894
UPCOMING_BUCKET_ID = 30601
PROVIDER_LOGIN_URL = 'https://f.mjh.nz/espn/'
ESPN_LOGIN_URL = 'https://www.espn.com/activate'
