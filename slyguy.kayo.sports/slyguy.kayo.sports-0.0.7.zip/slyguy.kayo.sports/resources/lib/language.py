from slyguy.language import BaseLanguage


class Language(BaseLanguage):
    API_ERROR           = 30001
    QR_ERROR            = 30002
    DEVICE_CODE_EXPIRED = 30003
    LOGIN_SUCCESS       = 30004
    QR_HELP             = 30005
    CONFIG_ERROR        = 30006
    GEO_BLOCK           = 30007
    PLAYBACK_ERROR      = 30008
    NOT_STARTED         = 30009
    LIVE                = 30010
    HOME                = 30011
    ALL_SPORTS          = 30012
    SHOWS               = 30013
    LIVE_TV             = 30014
    PROFILE_ERROR       = 30015
    NO_DATA             = 30019
    REFRESH_ERROR       = 30020
    FOUR_K              = 30021
    NO_4K               = 30022
    CONCURRENCY_ERROR   = 30023
    LICENSE_ERROR       = 30024
    DEVICE_ID           = 30025
    SYNC_PLAYBACK       = 30026
    MFA_PROMPT          = 30027
    MFA_PROMPT_NO_EMAIL = 30028
    MFA_INVALID_CODE    = 30029
    MFA_FAILED          = 30030
    MFA_CODE_EXPIRED    = 30031
    MFA_RESEND          = 30032
    MFA_NEEDED          = 30033
    CLEAR_DEVICE_ID     = 30034


_ = Language()
