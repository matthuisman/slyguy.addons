BRAND = 'kayo'
BRAND_HEADER = 'KAYO'
LANGUAGE = 'en'
COUNTRY = 'au'
PLATFORM = 'androidtv'
MANUFACTURER = 'NVIDIA'
MODEL = 'SHIELD Android TV'

# The app is a WebView around tv.kayosports.com.au, a plain Kayo/x.x.x UA is blocked by the WAF
USER_AGENT = 'Mozilla/5.0 (Linux; Android 11; SHIELD Android TV Build/RQ1A.210105.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 DAZN_HTML_ANDROIDTV'

HEADERS = {
    'User-Agent': USER_AGENT,
    'X-BRAND': BRAND,
    'Accept': '*/*',
    'Content-Type': 'application/json',
    'Accept-Language': LANGUAGE,
    'Origin': 'https://tv.kayosports.com.au',
    'X-Requested-With': 'au.com.kayosports.tv',
    'Referer': 'https://tv.kayosports.com.au/',
}

# The app resolves its service urls from this bootstrap response at runtime
CONFIG_URL = 'https://startup.core.indazn.com/v2/main/lrd'
CONFIG_PARAMS = {
    'Version': 2,
    'Languages': LANGUAGE,
    'Platform': PLATFORM,
    'Manufacturer': MANUFACTURER,
    'Brand': BRAND,
}
CONFIG_TTL = 60 * 60 * 6

SERVICE_RAILS = 'Rails'
SERVICE_RAILS_VERSION = 'v9'
SERVICE_RAIL = 'Rail'
SERVICE_RAIL_VERSION = 'v11'

RAILS_URL = 'https://rails.discovery.indazn.com/jp/v9/rails'
RAIL_URL = 'https://rail-router.discovery.indazn.com/jp/v11/Rail'
RULESET_RAIL_URL = 'https://ruleset-rail-router.discovery.indazn.com/jp/v1/Rail'
SEARCH_URL = 'https://search.discovery.indazn.com/v1/search'

QR_URL = 'https://second-screen.ar.indazn.com/v2/subscribe/qr'
QR_STATUS_URL = 'https://second-screen.ar.indazn.com/v1/subscribed/'
REFRESH_URL = 'https://ott-authz-bff-prod.ar.indazn.com/v5/RefreshAccessToken'
SIGNOUT_URL = 'https://ott-authz-bff-prod.ar.indazn.com/v1/SignOut'
USER_PROFILE_URL = 'https://user-profile.ar.indazn.com/v4/UserProfile'
SWITCH_PROFILE_URL = 'https://authentication-prod.ar.indazn.com/v1/SwitchProfile'

PLAYBACK_URL = 'https://api.playback.indazn.com/v5/Playback'
LOCK_URL = 'https://concurrency-v2.playback.indazn.com/v3/concurrency/lock/'
RESUME_URL = 'https://resume-points-v3.playback.indazn.com/v1/resumepoints'

# New devices must be verified with a code Kayo emails before playback (odata error 10400)
MFA_INITIATE_URL = 'https://mfa-service.ar.indazn.com/v1/mfa/initiate'
MFA_VERIFY_URL = 'https://mfa-service.ar.indazn.com/v1/mfa/verify'
MFA_USE_TYPE = 'trust-service'
MFA_MAX_ATTEMPTS = 3

SIGNIN_URL = 'https://kayosports.com.au/signin/device/{}'
SIGNIN_API_URL = 'https://authentication-prod.ar.indazn.com/v5/SignIn'
SHORTEN_URL = 'https://is.gd/create.php?format=simple&url={}'

# Namespace for the device id generated from the device_id setting
UUID_NAMESPACE = '0191cb11-0c1e-4829-9dfe-770d94536475'

HOME_GROUP = 'home'
SHOWS_GROUP = 'Shows'
LIVE_RAIL = 'Livetvschedule'
SPORT_RAIL = 'Sport'

HOME_PARAMS = 'PageType:Home;ContentType:None'
SHOWS_PARAMS = 'PageType:Shows;ContentType:None'

IMAGE_URL = 'https://image.discovery.indazn.com/jp/v3/{folder}/none/{id}/fill/none/top/none/80/{width}/{height}/{ext}/image?brand=kayo'
# Only used when all we have is the avatar id
AVATAR_URL = 'https://image.discovery.indazn.com/eu/v4/user-profile/none/{id}/fill/none/top/none/100/400/400/webp/image'
# Channel logos (LogoImage) only resolve from this folder
LINEAR_IMAGES = 'linear-channel'

# The TV profile is what the app uses, but its licence server rejects L3 CDMs (10802)
PLAYER_PARAMS_WEB = {
    'AppVersion': '0.150.3',
    'DrmType': 'WIDEVINE',
    'Format': 'MPEG-DASH',
    'PlayerId': '@dazn/peng-html5-core/web/web',
    'Platform': 'web',
    'Model': 'unknown',
    'Secure': 'true',
    'Manufacturer': 'unknown',
    'LanguageCode': LANGUAGE,
}

# 4K needs a secure CDM, everyone else is capped at 1080p
MAX_HEIGHT_L1 = 2160
MAX_HEIGHT_L3 = 1080

# ResumePoints reports a few seconds of drift on a stream you never watched, don't prompt for those
RESUME_MIN_POSITION = 60

# Kayo leaves LinearSchedule.ChannelNumber empty, so use the Foxtel numbers
CHANNEL_NUMBERS = {
    'fox sports news': 500,
    'fox cricket': 501,
    'fox league': 502,
    'fox sports 503': 503,
    'fox footy': 504,
    'fox sports 505': 505,
    'fox sports 506': 506,
    'fox sports 507': 507,
    'espn': 509,
    'espn2': 510,
    'racing.com': 529,
}

POLL_INTERVAL = 5
QR_TIMEOUT = 600
TOKEN_TTL = 3600
