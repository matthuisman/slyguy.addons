import uuid

from slyguy.settings import CommonSettings
from slyguy.settings.types import AutoText, Bool

from .language import _


class Settings(CommonSettings):
    DEVICE_ID = AutoText('device_id', _.DEVICE_ID, generator=uuid.uuid4, confirm_clear=_.CLEAR_DEVICE_ID)
    SYNC_PLAYBACK = Bool('sync_playback', _.SYNC_PLAYBACK, default=False)


settings = Settings()
