from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool, Text

from .language import _


class Settings(CommonSettings):
    DEVICE_ID = Text('device_id', _.DEVICE_ID, default='{mac_address}')
    SYNC_PLAYBACK = Bool('sync_playback', _.SYNC_PLAYBACK, default=False)


settings = Settings()
