import base64
import json
import uuid
from time import time

from slyguy import userdata, mem_cache, log, keep_alive
from slyguy.session import Session
from slyguy.exceptions import Error
from six.moves.urllib_parse import quote

from .constants import *
from .language import _
from .settings import settings


class APIError(Error):
    pass


class MFARequired(APIError):
    def __init__(self, message='', pending=False):
        super(MFARequired, self).__init__(message)
        self.pending = pending


class MFAExpired(APIError):
    pass


def supports_4k():
    return False


def _first(data, *keys):
    if not isinstance(data, dict):
        return None

    for key in keys:
        value = data.get(key)
        if value:
            return value

    return None


def _json_or_empty(response):
    try:
        return response.json()
    except Exception:
        return {}


def _jwt(token):
    try:
        payload = token.split('.')[1]
        payload += '=' * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:
        return {}


def _error_message(data):
    try:
        error = data['odata.error']
        return '{} ({})'.format(error['message']['value'], error['code'])
    except (KeyError, TypeError):
        pass

    if isinstance(data, dict):
        return data.get('message') or data.get('code')

    return None


def _error_code(data):
    try:
        return data['odata.error']['code']
    except (KeyError, TypeError):
        return None


def _error_limit(data, key):
    try:
        return data['odata.error']['meta']['limits'][key]
    except (KeyError, TypeError):
        return None


def avatar_url(avatar_id):
    if not avatar_id:
        return None

    return AVATAR_URL.format(id=avatar_id)


def shorten_url(url):
    try:
        response = Session({'User-Agent': USER_AGENT}, timeout=15).get(SHORTEN_URL.format(quote(url, safe='')))
        short = (response.text or '').strip()
        if response.status_code == 200 and short.startswith('http') and ' ' not in short:
            return short
    except Exception as e:
        log.debug('could not shorten sign in url: {}'.format(e))

    return url


def _is_uuid(value):
    try:
        uuid.UUID(value)
        return True
    except (ValueError, TypeError, AttributeError):
        return False


def device_id():
    value = str(settings.DEVICE_ID.value or '')
    if not _is_uuid(value):
        settings.DEVICE_ID.clear()
        value = str(settings.DEVICE_ID.value or '')

    return value


class API(object):
    def new_session(self):
        self._session = Session(HEADERS, timeout=30)
        self._device_id = device_id()
        log.debug('device id {}'.format(self._device_id))

        self._set_authentication(userdata.get('access_token'))
        keep_alive.register(self.refresh, hours=6, enable=self.logged_in)

    def _set_authentication(self, token):
        self.logged_in = False
        self._session.headers.pop('Authorization', None)

        if not token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
        self.logged_in = True

    def _request_headers(self, extra=None):
        headers = {}
        dazn_id = userdata.get('dazn_id')
        if dazn_id:
            headers['x-daznid'] = dazn_id

        if extra:
            headers.update(extra)

        return headers

    def _auth_params(self, personalised=False):
        params = {}
        entitlements = userdata.get('entitlements') or []
        if entitlements:
            params['userEntitlements'] = ','.join(entitlements)

        viewer_id = userdata.get('viewer_id')
        if personalised and viewer_id:
            params['viewerId'] = viewer_id

        return params

    def _request(self, url, params=None, method='GET', json=None, headers=None, raise_error=True, retry=True):
        if self.logged_in and userdata.get('expires', 0) <= time():
            self.refresh()

        try:
            response = self._session.request(method, url, params=params, json=json,
                headers=self._request_headers(headers), timeout=30)
        except Exception as e:
            if raise_error:
                raise APIError(_.API_ERROR.format(msg=str(e)[:200]))
            log.warning('request failed: {}'.format(e))
            return None

        try:
            data = response.json()
        except Exception:
            data = None

        if response.status_code == 401 and retry and self.logged_in:
            if self.refresh(force=True):
                return self._request(url, params=params, method=method, json=json, headers=headers,
                    raise_error=raise_error, retry=False)

            raise APIError(_.REFRESH_ERROR)

        if response.status_code >= 400:
            code = _error_code(data)
            message = _error_message(data) or response.text[:200]

            log.warning('{} {} -> {}: {}'.format(method, url, response.status_code, message))

            if raise_error:
                if not isinstance(data, dict) and response.status_code == 403:
                    raise APIError(_.GEO_BLOCK)
                elif code == 10801:
                    raise APIError(_.CONCURRENCY_ERROR.format(max=_error_limit(data, 'maxDevices') or 2))
                elif code == 10802:
                    raise APIError(_.LICENSE_ERROR)
                elif str(code) in ('10400', '10401'):
                    raise MFARequired(message, pending=str(code) == '10401')
                elif str(code) == '10049':
                    raise APIError(_.LOGIN_ERROR)

                raise APIError(_.API_ERROR.format(msg=message))

            return None

        return data if data is not None else {}

    def get_config(self, force=False):
        cached = userdata.get('service_dict')
        expires = userdata.get('service_dict_expires', 0)

        if cached and not force and expires > time():
            return cached

        try:
            response = self._session.get(CONFIG_URL, params=CONFIG_PARAMS, timeout=30)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            if cached:
                log.warning('using cached service dictionary ({})'.format(e))
                return cached
            raise APIError(_.CONFIG_ERROR.format(msg=str(e)[:200]))

        if not isinstance(data, dict) or not data.get('ServiceDictionary'):
            if cached:
                return cached
            raise APIError(_.CONFIG_ERROR.format(msg=_.NO_DATA))

        userdata.set('service_dict', data)
        userdata.set('service_dict_expires', int(time() + CONFIG_TTL))
        return data

    def service_url(self, name, version=None, default=None):
        services = self.get_config().get('ServiceDictionary') or {}
        versions = (services.get(name) or {}).get('Versions') or {}

        if version:
            if versions.get(version):
                return versions[version].get('ServicePath')

            if default:
                log.warning('service {} version {} missing, using default'.format(name, version))
                return default
        elif versions:
            return versions[sorted(versions)[-1]].get('ServicePath')

        if default:
            log.warning('service {} missing, using default'.format(name))
            return default

        raise APIError(_.CONFIG_ERROR.format(msg='Missing service {}'.format(name)))

    @property
    def country(self):
        return COUNTRY

    def _save_token(self, token):
        claims = _jwt(token)
        expires = int(claims.get('exp') or 0) or int(time() + TOKEN_TTL)
        entitlements = (claims.get('entitlements') or {}).get('entitlementSets') or []

        userdata.set('access_token', token)
        userdata.set('expires', expires - 60)
        userdata.set('dazn_id', claims.get('user') or userdata.get('dazn_id'))
        userdata.set('viewer_id', claims.get('viewerId') or userdata.get('viewer_id'))
        userdata.set('entitlements', [x['id'] for x in entitlements if x.get('id')])
        userdata.set('allow_4k', any(x.get('allow4k') for x in entitlements))
        self._set_authentication(token)

    def start_device_login(self):
        payload = {
            'brand': BRAND,
            'signIn': True,
            'country': self.country.upper(),
            'language': LANGUAGE,
            'deviceId': self._device_id,
            'qrOptions': {
                'width': 345,
                'margin': 0,
                'color': {'dark': '#F9FAFAFF', 'light': '#00000000'},
                'errorCorrectionLevel': 'H',
            },
            'oemTrackingDetails': {
                'platform': PLATFORM,
                'manufacturer': MANUFACTURER,
                'partnerID': MANUFACTURER,
                'isSignUpDisabled': True,
                'productGroup': BRAND_HEADER,
                'content': BRAND_HEADER,
                'isFreemium': False,
                'sourceRef': 'landing-page',
                'store': 'GOOGLE_TV',
            },
        }

        data = self._request(QR_URL, method='POST', json=payload)
        session_id = _first(data, 'secondScreenId', 'secondScreenID', 'sessionId', 'id')
        if not session_id:
            raise APIError(_.QR_ERROR.format(msg=_error_message(data) or _.NO_DATA))

        return {
            'id': session_id,
            'url': shorten_url(SIGNIN_URL.format(session_id)),
        }

    def poll_device_login(self, session_id):
        response = self._session.get(QR_STATUS_URL + session_id, headers=self._request_headers(), timeout=30)
        if response.status_code in (202, 204, 404):
            return None

        try:
            data = response.json()
        except Exception:
            return None

        token = _first(data, 'token', 'accessToken', 'access_token', 'jwt')
        if not token:
            code = data.get('code') if isinstance(data, dict) else None
            if code:
                log.debug('device login pending ({})'.format(code))
            return None

        return {'access_token': token}

    def login(self, tokens):
        token = tokens.get('access_token')
        if not token:
            raise APIError(_.QR_ERROR.format(msg=_.NO_DATA))

        mem_cache.empty()
        self._save_token(token)

    def login_with_password(self, email, password):
        payload = {
            'brand': BRAND,
            'Email': email,
            'Password': password,
            'DeviceId': self._device_id,
            'Platform': PLATFORM,
        }

        data = self._request(SIGNIN_API_URL, method='POST', json=payload,
            headers={'X-DAZN-DEVICE': self._device_id}, retry=False)

        auth = data.get('AuthToken') if isinstance(data, dict) else None
        token = _first(auth or {}, 'Token')
        if not token:
            raise APIError(_.LOGIN_ERROR)

        mem_cache.empty()
        self._save_token(token)

    def refresh(self, force=False):
        if not self.logged_in:
            return False

        if not force and userdata.get('expires', 0) > time():
            return True

        payload = {
            'DeviceId': self._device_id,
            'brand': BRAND,
            'appLaunch': False,
        }

        headers = self._request_headers({
            'X-BRAND': BRAND_HEADER,
            'Content-Type': 'application/json',
            'X-Session-Id': str(uuid.uuid4()),
        })

        try:
            response = self._session.post(REFRESH_URL, json=payload, headers=headers, timeout=30)
        except Exception as e:
            log.warning('token refresh failed: {}'.format(e))
            return False

        data = _json_or_empty(response)
        token = _first(data, 'token', 'accessToken', 'access_token') or _first(data.get('AuthToken') or {}, 'Token')

        if not token:
            log.warning('token refresh returned {}'.format(response.status_code))
            return False

        self._save_token(token)
        log.debug('access token refreshed')
        return True

    def profile(self):
        return userdata.get('profile') or {}

    def profiles(self, force=False):
        data = self._request(USER_PROFILE_URL, params={'_': int(time())} if force else None)
        return data.get('profiles') or []

    def switch_profile(self, profile_id):
        data = self._request(SWITCH_PROFILE_URL, method='POST', json={'brand': BRAND, 'profileId': profile_id})
        token = _first(data.get('AuthToken') or {}, 'Token')
        if not token:
            raise APIError(_.PROFILE_ERROR)

        self._save_token(token)
        userdata.set('profile', self.profile_details(profile_id))
        return userdata.get('profile')

    def profile_details(self, profile_id):
        profile = {'id': profile_id, 'name': profile_id, 'viewer_id': userdata.get('viewer_id')}
        try:
            for row in self.profiles(force=True):
                if row.get('profileId') != profile_id:
                    continue

                profile = {
                    'id': profile_id,
                    'name': row.get('profileName'),
                    'viewer_id': row.get('viewerId'),
                    'avatar': row.get('avatar') or avatar_url(row.get('avatarImageId')),
                }
                break
        except Exception as e:
            log.warning('could not load profile details: {}'.format(e))

        return profile

    @mem_cache.cached(60*5)
    def rails(self, group, params=''):
        url = self.service_url(SERVICE_RAILS, version=SERVICE_RAILS_VERSION, default=RAILS_URL)

        query = {
            'brand': BRAND,
            'platform': PLATFORM,
            'country': self.country,
            'groupId': group,
        }
        if params and group != HOME_GROUP:
            query['params'] = params

        query.update(self._auth_params())

        data = self._request(url, params=query)
        if not isinstance(data, dict) or 'Rails' not in data:
            raise APIError(_error_message(data) or _.NO_DATA)

        return data['Rails']

    @mem_cache.cached(60*2)
    def rail(self, id, params='', service='Rail', personalised=False):
        if service == 'RulesetRail':
            url = RULESET_RAIL_URL
        else:
            url = self.service_url(SERVICE_RAIL, version=SERVICE_RAIL_VERSION, default=RAIL_URL)

        query = {
            'platform': PLATFORM,
            'id': id,
            'country': self.country,
            'languageCode': LANGUAGE,
            'brand': BRAND,
        }
        if params:
            query['params'] = params

        query.update(self._auth_params(personalised))

        data = self._request(url, params=query, raise_error=False)
        if not isinstance(data, dict) or 'Tiles' not in data:
            return {'Id': id, 'Title': None, 'Tiles': []}

        return data

    @mem_cache.cached(60*2)
    def live_channels(self):
        return [x for x in self.rail(LIVE_RAIL).get('Tiles') or [] if x.get('AssetId')]

    @mem_cache.cached(60*5)
    def search(self, query):
        params = {
            'brand': BRAND,
            'searchTerm': query,
            'langCode': LANGUAGE,
            'country': self.country,
            'openBrowse': 'false',
        }

        data = self._request(SEARCH_URL, params=params)
        results = []
        for row in data.get('Results') or []:
            results.extend(row.get('Tiles') or [])

        return results

    def _capabilities(self, secure):
        capabilities = []

        capabilities.append('mta')

        if settings.H265.value:
            capabilities.append('hevc')

            if userdata.get('allow_4k') and secure:
                capabilities.append('4k')

        if secure and settings.HDR10.value:
            capabilities.append('hdr')

        if settings.AC3.value:
            capabilities.append('dd')

        if settings.EC3.value:
            capabilities.append('ddp')

        return ','.join(sorted(capabilities))

    def _player_params(self):
        secure = supports_4k()
        params = dict(PLAYER_PARAMS_WEB)

        capabilities = self._capabilities(secure)
        if capabilities:
            params['Capabilities'] = capabilities

        log.debug('playback profile {} secure={} client_secure={} allow_4k={} capabilities={}'.format(
            params.get('PlayerId'), secure, params.get('Secure'), bool(userdata.get('allow_4k')), params.get('Capabilities')))

        return params

    def _cdn_works(self, detail):
        token = detail.get('CdnToken') or {}
        params = {token['Name']: token['Value']} if token.get('Name') else {}
        try:
            resp = self._session.get(detail['ManifestUrl'], params=params,
                headers={'Range': 'bytes=0-0'}, timeout=15)
            return resp.status_code < 400
        except Exception as e:
            log.debug('CDN {} probe failed: {}'.format(detail.get('CdnName'), e))
            return False

    def play(self, asset_id):
        self.refresh()

        self.release_lock()

        params = self._player_params()
        params['AssetId'] = asset_id
        params['SessionId'] = '{}-{}-{}-{}'.format(int(time() * 1000), userdata.get('viewer_id') or '',
            asset_id, uuid.uuid4().hex[:6].upper())

        headers = {
            'X-BRAND': BRAND_HEADER,
            'x-dazn-device': self._device_id,
            'x-correlation-id': str(uuid.uuid4()),
        }

        data = self._request(PLAYBACK_URL, params=params, method='POST', json={}, headers=headers)
        if not data.get('PlaybackDetails'):
            raise APIError(_.PLAYBACK_ERROR.format(error=_error_message(data) or _.NO_DATA))

        details = data['PlaybackDetails']
        if len(details) > 1:
            for detail in details:
                if self._cdn_works(detail):
                    details = [detail]
                    break
            else:
                log.warning('no CDN responded, trying {} anyway'.format(details[0].get('CdnName')))

            data['PlaybackDetails'] = details

        lock = data.get('PlaybackLock') or {}
        if lock.get('LockId'):
            self.release_lock(lock['LockId'])

        return data

    def release_lock(self, lock_id=None):
        lock_id = lock_id or userdata.get('lock_id')
        if not lock_id:
            return

        userdata.delete('lock_id')
        try:
            self._session.delete(LOCK_URL + lock_id, headers=self._request_headers(), timeout=30)
        except Exception as e:
            log.debug('lock release failed: {}'.format(e))

    def start_trust_verification(self):
        claims = _jwt(userdata.get('access_token') or '')
        profile = {}
        try:
            profile = self._request(USER_PROFILE_URL, params={'_': int(time())}, raise_error=False) or {}
        except Exception as e:
            log.warning('could not load account for device verification: {}'.format(e))

        payload = {
            'locale': '{}_{}'.format(LANGUAGE, self.country.upper()),
            'deviceId': self._device_id,
            'providerName': claims.get('providerName') or BRAND,
            'useType': MFA_USE_TYPE,
            'verificationMethod': 'Email',
        }
        customer_id = claims.get('providerCustomerId') or userdata.get('dazn_id')
        if customer_id:
            payload['providerCustomerId'] = customer_id

        first_name = _first(profile, 'FirstName', 'firstName')
        if first_name:
            payload['firstName'] = first_name

        data = self._request(MFA_INITIATE_URL, method='POST', json=payload,
            headers={'x-dazn-device': self._device_id})
        return _first(data, 'emailAddress', 'email', 'Email')

    def mfa_challenge(self, pending=False, force=False):
        cached = userdata.get('mfa_pending')
        if not force and isinstance(cached, dict) and cached.get('expires', 0) > time():
            return cached.get('email')

        try:
            email = self.start_trust_verification()
        except APIError as e:
            if not pending:
                raise

            log.warning('could not start device verification: {}'.format(e))
            return (cached if isinstance(cached, dict) else {}).get('email')

        userdata.set('mfa_pending', {'email': email, 'expires': int(time() + MFA_CHALLENGE_TTL)})
        return email

    def clear_mfa_challenge(self):
        userdata.delete('mfa_pending')

    def verify_trust(self, pin):
        self.refresh()

        for retry in range(2):
            response = self._session.post(MFA_VERIFY_URL, json={
                'deviceId': self._device_id,
                'useType': MFA_USE_TYPE,
                'pin': int(pin),
            }, headers=self._request_headers({'x-dazn-device': self._device_id}), timeout=30)

            if response.status_code == 401 and not retry and self.refresh(force=True):
                continue
            break

        if response.status_code == 410:
            self.clear_mfa_challenge()
            raise MFAExpired(_.MFA_CODE_EXPIRED)

        if response.status_code in (403, 429):
            self.clear_mfa_challenge()
            raise APIError(_.MFA_FAILED)

        if response.status_code in (400, 401, 422):
            return False

        data = _json_or_empty(response)
        if response.status_code >= 400:
            raise APIError(_error_message(data) or _.MFA_FAILED)

        if data.get('isUserVerified'):
            self.clear_mfa_challenge()
            return True

        return False

    def resume_point(self, asset_id, position, length, video_type='VOD', article_type_id=None, event_id=None):
        if not self.logged_in:
            return

        payload = {
            'assetId': asset_id,
            'position': int(position),
            'contentLength': int(length),
            'videoType': video_type,
        }
        if article_type_id:
            payload['articleTypeId'] = article_type_id
        if event_id:
            payload['eventId'] = event_id

        try:
            self._session.post(RESUME_URL, json=payload, headers=self._request_headers(), timeout=30)
        except Exception as e:
            log.debug('resume point failed: {}'.format(e))

    def logout(self):
        if userdata.get('access_token'):
            try:
                self._session.post(SIGNOUT_URL, json={'DeviceId': self._device_id},
                    headers=self._request_headers({'X-BRAND': BRAND_HEADER}), timeout=30)
            except Exception as e:
                log.debug('sign out failed: {}'.format(e))

        for key in ('access_token', 'expires', 'dazn_id', 'viewer_id', 'entitlements', 'profile', 'lock_id',
                'mfa_pending'):
            userdata.delete(key)

        mem_cache.empty()
        self._set_authentication(None)
