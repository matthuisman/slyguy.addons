import codecs
import json
import re
import sys
from time import time
from xml.sax.saxutils import escape, quoteattr

import arrow
from six.moves.urllib_parse import parse_qsl, urlencode, urlparse, urlunparse
from slyguy import gui, inputstream, log, monitor, plugin, signals, userdata
from slyguy.constants import LIVE_HEAD, PLAY_FROM_ASK, PLAY_FROM_START, ROUTE_LIVE_TAG
from slyguy.exceptions import PluginError
from slyguy.util import async_tasks, get_system_arch

from .api import API, APIError, MFAExpired, MFARequired, avatar_url, supports_4k
from .constants import *
from .language import _
from .settings import settings

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def index(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.HOME, _bold=True), path=plugin.url_for(home))
        folder.add_item(label=_(_.ALL_SPORTS, _bold=True), path=plugin.url_for(all_sports))
        folder.add_item(label=_(_.SHOWS, _bold=True), path=plugin.url_for(page, group=SHOWS_GROUP,
            params=SHOWS_PARAMS, title=_.SHOWS))
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live))

        if supports_4k():
            folder.add_item(label=_(_.FOUR_K, _bold=True), path=plugin.url_for(four_k))

        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))

        if settings.BOOKMARKS.value:
            folder.add_item(label=_(_.BOOKMARKS, _bold=True),
                path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)

        profile = api.profile()
        folder.add_item(label=_.SELECT_PROFILE, art={'thumb': profile.get('avatar')},
            info={'plot': profile.get('name')}, path=plugin.url_for(select_profile),
            _kiosk=False, bookmark=False)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS),
        _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    options = [
        [_.DEVICE_CODE, _device_code],
        [_.EMAIL_PASSWORD, _email_password],
    ]

    index = 0 if len(options) == 1 else gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    gui.notification(_.LOGIN_SUCCESS)

    try:
        _select_profile()
    except Exception as e:
        log.warning('could not load profiles: {}'.format(e))

    gui.refresh()


def _device_code():
    data = api.start_device_login()

    tokens = None
    start = time()

    with gui.progress_qr(data['url'], _(_.QR_HELP, url=data['url']), heading=_.DEVICE_CODE) as progress:
        while time() - start < QR_TIMEOUT:
            if progress.iscanceled() or monitor.waitForAbort(POLL_INTERVAL):
                return

            progress.update(int(((time() - start) / float(QR_TIMEOUT)) * 100))

            tokens = api.poll_device_login(data['id'])
            if tokens:
                break

    if not tokens:
        raise PluginError(_.DEVICE_CODE_EXPIRED)

    api.login(tokens)
    return True


def _email_password():
    email = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not email:
        return

    userdata.set('username', email)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login_with_password(email, password)
    return True


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()


@plugin.route()
@plugin.login_required()
def home(**kwargs):
    return _page(HOME_GROUP, HOME_PARAMS, _.HOME)


@plugin.route()
@plugin.login_required()
def all_sports(**kwargs):
    data = api.rail(SPORT_RAIL, params=HOME_PARAMS + ';OpenBrowse:True')
    folder = plugin.Folder(_.ALL_SPORTS)
    folder.add_items(_parse_tiles(data.get('Tiles')))
    return folder


@plugin.route()
@plugin.login_required()
def live(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    folder.add_items(_parse_tiles(api.live_channels()))
    return folder


@plugin.route()
@plugin.login_required()
def four_k(**kwargs):
    tiles = []
    for group, params in ((HOME_GROUP, HOME_PARAMS), (SHOWS_GROUP, SHOWS_PARAMS)):
        for data in async_tasks(_rail_tasks(api.rails(group, params)), raise_on_error=False):
            if isinstance(data, Exception) or not data:
                continue
            tiles.extend(data.get('Tiles') or [])

    tiles.extend(api.live_channels())

    four_k_tiles = [x for x in tiles if (x.get('HeEventTypeConfig') or {}).get('is4k')
        or (x.get('HeEventTypeConfig') or {}).get('is4kUpscaled')]
    log.debug('4K scan - {} of {} tiles'.format(len(four_k_tiles), len(tiles)))

    folder = plugin.Folder(_.FOUR_K, content='videos', no_items_label=_.NO_4K)
    folder.add_items(_parse_tiles(four_k_tiles))
    return folder


@plugin.route()
@plugin.login_required()
def page(group, params='', title=None, **kwargs):
    return _page(group, params, title)


def _page(group, params, title):
    folder = plugin.Folder(title, content='videos')

    rows = api.rails(group, params)
    results = async_tasks(_rail_tasks(rows), raise_on_error=False)

    for row, data in zip(rows, results):
        if isinstance(data, Exception) or not data or not data.get('Tiles'):
            continue

        if data.get('Type') == 'Hero':
            folder.add_items(_parse_tiles(data['Tiles']))
            continue

        extra = {'personalised': 1} if row.get('IsPersonalization') else {}
        folder.add_item(
            label = data.get('Title') or row['Id'],
            art = _rail_art(data),
            path = plugin.url_for(rail, id=row['Id'], params=row.get('Params') or '', service=row.get('Service'),
                title=data.get('Title'), **extra),
        )

    return folder


@plugin.route()
@plugin.login_required()
def rail(id, params='', service='Rail', personalised=0, title=None, **kwargs):
    data = api.rail(id, params=params, service=service, personalised=bool(int(personalised or 0)))
    folder = plugin.Folder(title or data.get('Title'), content='videos')
    folder.add_items(_parse_tiles(data.get('Tiles')))
    return folder


@plugin.route()
@plugin.search()
@plugin.login_required()
def search(query, page, **kwargs):
    return _parse_tiles(api.search(query)), False


@plugin.route()
@plugin.login_required()
def select_profile(**kwargs):
    if _select_profile():
        gui.refresh()


def _select_profile():
    try:
        profiles = api.profiles()
    except Exception as e:
        log.warning('could not load profiles: {}'.format(e))
        raise PluginError(_.PROFILE_ERROR)

    if not profiles:
        raise PluginError(_.PROFILE_ERROR)

    current = api.profile()
    options = []
    values = []
    preselect = 0

    for index, profile in enumerate(profiles):
        values.append(profile)
        label = profile.get('profileName') or profile.get('profileId')
        avatar = profile.get('avatar') or avatar_url(profile.get('avatarImageId'))
        options.append(plugin.Item(label=label, art={'thumb': avatar}, info={'plot': label}))
        if profile.get('profileId') == current.get('id'):
            preselect = index

    if len(profiles) > 1:
        index = gui.select(_.SELECT_PROFILE, options=options, preselect=preselect, useDetails=True)
        if index < 0:
            return False
    else:
        index = 0

    profile = api.switch_profile(values[index]['profileId'])
    gui.notification(_.PROFILE_ACTIVATED, heading=profile.get('name'),
        icon=profile.get('avatar') or avatar_url(profile.get('avatarImageId')))
    return True


@plugin.route()
@plugin.merge()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write('#EXTM3U')

        for tile in api.live_channels():
            title = tile.get('Title') or ''
            f.write('\n#EXTINF:-1 tvg-id="{id}" tvg-chno="{chno}" tvg-name="{name}" tvg-logo="{logo}",{name}\n{url}'.format(
                id = tile['AssetId'],
                chno = CHANNEL_NUMBERS.get(title.lower(), ''),
                name = title,
                logo = _channel_logo(tile),
                url = _play_path(asset_id=tile['AssetId'], linear=1, _is_live=True),
            ))


@plugin.route()
@plugin.merge()
def epg(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write('<?xml version="1.0" encoding="utf-8" ?><tv>')

        channels = api.live_channels()
        for tile in channels:
            f.write('<channel id={}><display-name>{}</display-name><icon src={}/></channel>'.format(
                quoteattr(tile['AssetId']), escape(tile.get('Title') or ''), quoteattr(_channel_logo(tile))))

        for tile in channels:
            schedule = tile.get('LinearSchedule') or {}
            for row in [schedule.get('Now'), schedule.get('Next')] + (schedule.get('Later') or []):
                if not row or not row.get('Start') or not row.get('End'):
                    continue

                f.write('<programme channel={} start="{}" stop="{}"><title>{}</title>'.format(
                    quoteattr(tile['AssetId']), _xmltv_time(row['Start']), _xmltv_time(row['End']), escape(row.get('Title') or '')))

                if row.get('EpisodeTitle'):
                    f.write('<sub-title>{}</sub-title>'.format(escape(row['EpisodeTitle'])))
                if row.get('Description'):
                    f.write('<desc>{}</desc>'.format(escape(row['Description'])))
                for genre in row.get('Genre') or []:
                    if genre.get('name'):
                        f.write('<category>{}</category>'.format(escape(genre['name'])))

                icon = _image(row.get('BackgroundImage'), 1280, 720, folder=LINEAR_IMAGES)
                icon = icon or _image(row.get('Image'), 600, 900, folder=LINEAR_IMAGES)
                if icon:
                    f.write('<icon src={}/>'.format(quoteattr(icon)))

                f.write('</programme>')

        f.write('</tv>')


def _xmltv_time(value):
    return arrow.get(value).format('YYYYMMDDHHmmss Z')


def _image(image, width, height, folder='jp'):
    if not image or not image.get('Id'):
        return None

    ext = 'png' if image.get('ImageMimeType') == 'png' else 'jpg'
    return IMAGE_URL.format(folder=folder, id=image['Id'], width=width, height=height, ext=ext)


def _hero_image(tile, width, height):
    hero = tile.get('HeroImage') or {}
    if hero.get('Landscape'):
        hero = {'Id': hero['Landscape'], 'ImageMimeType': hero.get('ImageMimeType')}
    return _image(hero, width, height)


def _channel_logo(tile):
    return _image(tile.get('LogoImage'), 512, 512, folder=LINEAR_IMAGES) or _image(tile.get('Image'), 1280, 720) or ''


def _tile_art(tile):
    art = {}
    thumb = _image(tile.get('Image'), 1280, 720) or _image(tile.get('PortraitImage'), 600, 900)
    fanart = _image(tile.get('BackgroundImage'), 1920, 1080) or _hero_image(tile, 1920, 1080)
    logo = _image(tile.get('LogoImage'), 512, 512)

    if thumb:
        art['thumb'] = thumb
    if fanart:
        art['fanart'] = fanart
    if logo:
        art['clearlogo'] = logo

    return art


def _rail_art(data):
    for tile in data.get('Tiles') or []:
        art = _tile_art(tile)
        if art.get('thumb'):
            return {'thumb': art['thumb'], 'fanart': art.get('fanart') or art['thumb']}

    return {}


def _add_query(url, **params):
    parsed = urlparse(url)
    query = parse_qsl(parsed.query, keep_blank_values=True) + list(params.items())
    return urlunparse(parsed._replace(query=urlencode(query)))


def _manifest_url(url):
    max_height = MAX_HEIGHT_L1 if userdata.get('allow_4k') and supports_4k() else MAX_HEIGHT_L3

    parsed = urlparse(url)
    query = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        if key == 'aws.manifestfilter':
            value = re.sub(r'(video_height:\d+)-\d+', r'\g<1>-{}'.format(max_height), value)
        query.append((key, value))

    return urlunparse(parsed._replace(query=urlencode(query)))


def _rail_tasks(rows):
    return [lambda x=x: api.rail(x['Id'], params=x.get('Params') or '', service=x.get('Service'),
        personalised=x.get('IsPersonalization', False)) for x in rows]


def _epg_plot(tile):
    schedule = tile.get('LinearSchedule') or {}
    rows = [schedule.get('Now'), schedule.get('Next')] + (schedule.get('Later') or [])

    lines = []
    for row in rows:
        if len(lines) == 6:
            break
        if not row or not row.get('Start'):
            continue

        title = row.get('Title') or ''
        if row.get('EpisodeTitle') and row['EpisodeTitle'].lower() != title.lower():
            title += ' - {}'.format(row['EpisodeTitle'])

        lines.append('[{}] {}'.format(arrow.get(row['Start']).to('local').format('h:mma'), title))

    return '\n'.join(lines)


def _play_path(**kwargs):
    profile_id = api.profile().get('id')
    if profile_id:
        kwargs['profile_id'] = profile_id

    return plugin.url_for(play, **kwargs)


def _parse_tiles(tiles):
    return [x for x in (_parse_tile(tile) for tile in tiles or []) if x]


def _parse_tile(tile):
    title = tile.get('Title') or ''
    art = _tile_art(tile)

    if tile.get('Type') == 'Navigation':
        nav_params = tile.get('NavParams')
        if not nav_params:
            return None

        group = dict(x.split(':', 1) for x in nav_params.split(';') if ':' in x).get('PageType')
        if not group:
            return None

        return plugin.Item(
            label = title,
            art = art,
            info = {'plot': tile.get('Description'), 'mediatype': 'video'},
            path = plugin.url_for(page, group=group, params=nav_params, title=title),
        )

    if not tile.get('AssetId'):
        return None

    is_live = tile.get('Type') == 'Live'
    is_upcoming = tile.get('Type') == 'UpComing'
    start = arrow.get(tile['Start']) if tile.get('Start') else None

    if tile.get('IsLinear'):
        play_start = ((tile.get('LinearSchedule') or {}).get('Now') or {}).get('Start')
    elif is_upcoming or is_live:
        play_start = tile.get('Start')
    else:
        play_start = None

    label = title
    if is_live and not tile.get('IsLinear'):
        label = _(_.LIVE, label=label)
    elif is_upcoming and start:
        label += ' [B][{}][/B]'.format(start.to('local').format('ddd D MMM h:mma'))

    plot = tile.get('Description') or ''
    if tile.get('IsLinear'):
        plot = _epg_plot(tile) or plot

    if tile.get('Label'):
        plot = '[B]{}[/B]\n{}'.format(tile['Label'], plot)

    if supports_4k():
        he = tile.get('HeEventTypeConfig') or {}
        if he.get('is4k') or he.get('is4kUpscaled'):
            label += ' [COLOR gold][B][4K][/B][/COLOR]'
            plot = '[B][COLOR gold]4K UHD[/COLOR][/B]\n' + plot
        elif he.get('isHdr'):
            label += ' [COLOR gold][B][HDR][/B][/COLOR]'

    total = int((tile.get('DurationInMillis') or 0) / 1000)
    duration = total
    if is_live and start and not tile.get('IsLinear') and start < arrow.utcnow():
        duration = int((arrow.utcnow() - start).total_seconds())

    info = {'plot': plot, 'mediatype': 'video'}
    if duration and not is_upcoming:
        info['duration'] = duration
    if start and not tile.get('IsLinear'):
        info['aired'] = start.to('local').format('YYYY-MM-DD')

    video_type = (tile.get('VideoType') or ('LIVE' if is_live else 'VOD')).upper()

    return plugin.Item(
        label = label,
        art = art,
        info = info,
        no_resume = None if tile.get('IsLinear') else False,
        playable = True,
        path = _play_path(
            asset_id = tile['AssetId'],
            start = play_start,
            linear = 1 if tile.get('IsLinear') else None,
            event_id = tile.get('EventId'),
            asset_type_id = tile.get('AssetTypeId'),
            duration = duration,
            total = total if total != duration else None,
            video_type = video_type,
            _is_live = is_live,
        ),
    )


def _resume_position(data):
    points = data.get('ResumePoints') or {}
    position = int(points.get('ResumeFrom') or 0)
    if position > 24 * 60 * 60:
        position -= int(points.get('StartFrom') or 0)

    return position if 0 < position < 12 * 60 * 60 else 0


def _verify_trust(pending=False):
    email = api.mfa_challenge(pending=pending)

    while True:
        message = _(_.MFA_PROMPT, email=email) if email else _.MFA_PROMPT_NO_EMAIL

        for _attempt in range(MFA_MAX_ATTEMPTS):
            pin = gui.numeric(message)
            if pin is None:
                gui.notification(_.MFA_NEEDED)
                return False

            try:
                if api.verify_trust(pin):
                    return True
            except MFAExpired:
                email = api.mfa_challenge(force=True)
                gui.notification(_.MFA_CODE_EXPIRED)
                break

            gui.notification(_.MFA_INVALID_CODE)
        else:
            if not gui.yes_no(_.MFA_RESEND):
                raise PluginError(_.MFA_FAILED)

            email = api.mfa_challenge(force=True)


@plugin.route()
@plugin.login_required()
def play(asset_id, start=None, linear=0, event_id=None, asset_type_id=None, duration=None, video_type='VOD', **kwargs):
    if start and arrow.get(start) > arrow.utcnow():
        gui.ok(_(_.NOT_STARTED, start=arrow.get(start).to('local').humanize()))
        return

    try:
        data = api.play(asset_id)
    except MFARequired as e:
        try:
            if not _verify_trust(pending=e.pending):
                return
        except APIError:
            raise PluginError(_.MFA_FAILED)

        try:
            data = api.play(asset_id)
        except MFARequired:
            raise PluginError(_.MFA_FAILED)

    details = data['PlaybackDetails'][0]

    resume_arg = sys.argv[3].lower() if len(sys.argv) > 3 else ''

    resume_pos = _resume_position(data)
    resume_from = None
    is_linear = bool(int(linear or 0))

    if start and kwargs.get(ROUTE_LIVE_TAG):
        play_type = settings.LIVE_PLAY_TYPE.value
        elapsed = int((arrow.utcnow() - arrow.get(start)).total_seconds())
        start_pos = 1 if not is_linear else (-elapsed if elapsed > 0 else LIVE_HEAD)

        if play_type == PLAY_FROM_ASK:
            if resume_pos and resume_pos >= RESUME_MIN_POSITION and not is_linear:
                resume_from = plugin.resume_from(resume_pos, include_live=True)
                if resume_from == -1:
                    return
                resume_from = resume_from or start_pos
            else:
                position = plugin.live_or_start()
                if position == -1:
                    return
                resume_from = start_pos if position else LIVE_HEAD
        elif play_type == PLAY_FROM_START:
            resume_from = start_pos
        else:
            resume_from = LIVE_HEAD

    elif (resume_pos and resume_arg != 'resume:false'
            and (not duration or resume_pos < int(duration) - RESUME_MIN_POSITION)):
        resume_from = resume_pos

    if kwargs.get(ROUTE_LIVE_TAG) and not resume_from:
        resume_from = LIVE_HEAD

    log.debug('playing {} -> {} ({}) {}'.format(asset_id, details.get('Resolution') or '?',
        details.get('VideoDynamicRange') or 'sdr', details.get('CdnName') or ''))

    token = details.get('CdnToken') or {}
    token_param = urlencode({token['Name']: token['Value']}) if token.get('Name') else ''

    manifest_url = _manifest_url(details['ManifestUrl'])
    if token_param:
        manifest_url = _add_query(manifest_url, **{token['Name']: token['Value']})

    log.debug('manifest filter {}'.format(
        dict(parse_qsl(urlparse(manifest_url).query)).get('aws.manifestfilter') or 'none'))

    properties = {}
    if token_param:
        properties['stream_params'] = token_param

    stream_length = int(duration or 0)
    if kwargs.get('total'):
        stream_length = max(stream_length, int(kwargs['total']))

    if kwargs.get(ROUTE_LIVE_TAG) and not is_linear and stream_length > 4 * 60 * 60:
        properties['manifest_config'] = json.dumps({'timeshift_bufferlimit': stream_length})

    callback = None
    if settings.SYNC_PLAYBACK.value:
        callback = {
            'type': 'interval',
            'interval': int((data.get('ResumePoints') or {}).get('UpdateInterval') or 30),
            'callback': plugin.url_for(resume_callback, asset_id=asset_id, start=start, linear=linear,
                event_id=event_id, asset_type_id=asset_type_id, duration=duration, video_type=video_type),
        }

    license_headers = license_request_headers(*get_system_arch())
    license_headers['X-BRAND'] = BRAND_HEADER
    license_headers['X-DAZNID'] = userdata.get('dazn_id') or ''

    item = plugin.Item(
        path = manifest_url,
        headers = {'User-Agent': USER_AGENT},
        inputstream = inputstream.Widevine(
            license_key = details['LaUrl'],
            license_headers = license_headers,
            properties = properties,
        ),
        callback = callback,
        use_proxy = True,
    )

    if resume_from is not None:
        item.resume_from = resume_from
        item.force_resume = True
        if kwargs.get(ROUTE_LIVE_TAG):
            item.no_resume = False

    return item


@plugin.route()
@plugin.no_error_gui()
def resume_callback(asset_id, _time, video_type='VOD', start=None, linear=0, event_id=None, asset_type_id=None, duration=None, **kwargs):
    _time = int(_time or 0)
    if _time <= 0:
        return

    if video_type == 'LIVE':
        if start and not int(linear or 0):
            position = int(arrow.get(start).timestamp) + _time
        else:
            position = int(time())
        length = position + 5
    else:
        position = _time
        length = max(int(duration or 0), position)

    api.resume_point(asset_id, position, length, video_type=video_type,
        article_type_id=asset_type_id, event_id=event_id)
