DATA_URL = 'https://i.mjh.nz/PBS/.app.json.gz'
