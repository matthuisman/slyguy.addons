from slyguy import gui

gui.ok('This addon no longer works and has been discontinued.')
