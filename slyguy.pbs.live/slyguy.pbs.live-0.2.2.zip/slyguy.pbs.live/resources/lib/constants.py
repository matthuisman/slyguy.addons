DATA_URL = 'https://i.mjh.nz/PBS/.app.json.gz'
EPG_URL = 'https://i.mjh.nz/PBS/all.xml.gz'
